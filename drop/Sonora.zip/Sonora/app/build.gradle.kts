plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.sonora.player"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.sonora.player"
        minSdk = 26
        targetSdk = 36
        versionCode = System.getenv("VERSION_CODE")?.trim()?.toIntOrNull()
            ?: System.getenv("GITHUB_RUN_NUMBER")?.trim()?.toIntOrNull()
            ?: 1
        versionName = System.getenv("VERSION_NAME").orEmpty().trim().ifEmpty { "1.0.0" }
        buildConfigField(
            "String",
            "UPDATE_REPO",
            "\"${System.getenv("UPDATE_REPO").orEmpty().trim().ifEmpty { System.getenv("GITHUB_REPOSITORY").orEmpty().trim() }}\""
        )
        buildConfigField("String", "ACOUSTID_KEY", "\"${System.getenv("ACOUSTID_KEY").orEmpty().trim().ifEmpty { "EsgOwBPZ6f" }}\"")
    }

    val keystorePath = System.getenv("KEYSTORE_PATH")
    val hasKeystore = keystorePath != null && file(keystorePath).exists()
    val buildsRelease = gradle.startParameter.taskNames.any { it.contains("release", ignoreCase = true) }
    if (buildsRelease && !hasKeystore) {
        throw GradleException("Release signing keystore not found. Set KEYSTORE_PATH, KEYSTORE_PASSWORD, KEY_ALIAS and KEY_PASSWORD.")
    }

    signingConfigs {
        if (hasKeystore) {
            create("sonora") {
                storeFile = file(keystorePath!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    val appSigning = if (hasKeystore) signingConfigs.getByName("sonora") else signingConfigs.getByName("debug")

    buildTypes {
        debug {
            signingConfig = appSigning
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = appSigning
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi",
            "-opt-in=androidx.compose.animation.ExperimentalAnimationApi",
            "-opt-in=androidx.compose.ui.ExperimentalComposeUiApi",
            "-opt-in=androidx.media3.common.util.UnstableApi"
        )
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
    implementation("androidx.media3:media3-common:1.5.1")

    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("com.google.zxing:core:3.5.3")
    implementation("com.github.AdrienPoupa:jaudiotagger:2.2.3")
    implementation("androidx.palette:palette-ktx:1.0.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
