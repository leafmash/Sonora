package com.sonora.player

import android.content.Context
import android.os.Build
import java.io.File

object CrashReporter {

    private const val FILE = "last_crash.txt"

    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                val report = buildString {
                    append("Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
                    append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
                    append("Thread: ").append(thread.name).append("\n\n")
                    append(android.util.Log.getStackTraceString(error))
                }
                File(app.filesDir, FILE).writeText(report)
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun pending(context: Context): String? {
        val file = File(context.filesDir, FILE)
        return if (file.exists()) runCatching { file.readText() }.getOrNull() else null
    }

    fun clear(context: Context) {
        runCatching { File(context.filesDir, FILE).delete() }
    }
}
