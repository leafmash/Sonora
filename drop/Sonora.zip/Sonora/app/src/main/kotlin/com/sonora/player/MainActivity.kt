package com.sonora.player

import android.Manifest
import android.media.AudioManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.result.IntentSenderRequest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.scaleOut
import com.sonora.player.ui.SplashScreen
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.getValue
import androidx.compose.ui.draw.clip
import com.sonora.player.ui.theme.auroraBackdrop
import com.sonora.player.ui.theme.brandBrush
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.TextButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.data.Route
import com.sonora.player.data.Track
import com.sonora.player.ui.AboutScreen
import com.sonora.player.ui.AlbumScreen
import com.sonora.player.ui.CrashDialog
import com.sonora.player.ui.ArtistScreen
import com.sonora.player.ui.EqualizerScreen
import com.sonora.player.ui.LibraryScreen
import com.sonora.player.ui.MiniPlayer
import com.sonora.player.ui.NowPlayingScreen
import com.sonora.player.ui.FolderScreen
import com.sonora.player.ui.PlaylistScreen
import com.sonora.player.ui.PlaylistsScreen
import com.sonora.player.ui.SearchScreen
import com.sonora.player.ui.SettingsScreen
import com.sonora.player.ui.VolumeController
import com.sonora.player.ui.VolumeOverlay
import com.sonora.player.ui.TrackCollectionScreen
import com.sonora.player.ui.components.AddToPlaylistDialog
import com.sonora.player.ui.components.EmptyState
import com.sonora.player.ui.theme.SonoraTheme

class MainActivity : ComponentActivity() {

    private val vm: PlayerViewModel by viewModels()
    private lateinit var volume: VolumeController

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        volume = VolumeController(getSystemService(AudioManager::class.java))
        volumeControlStream = AudioManager.STREAM_MUSIC
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        )
        if (savedInstanceState == null) openFrom(intent)
        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            var splashDone by rememberSaveable { mutableStateOf(false) }
            SonoraTheme(mode = settings.themeMode, dynamic = settings.dynamicColor) {
                Box(Modifier.fillMaxSize()) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background,
                        contentColor = MaterialTheme.colorScheme.onBackground
                    ) {
                        SonoraRoot(vm, splashDone)
                    }
                    CrashDialog()
                    AnimatedVisibility(
                        visible = !splashDone,
                        enter = EnterTransition.None,
                        exit = fadeOut(tween(450)) + scaleOut(tween(450), targetScale = 1.06f)
                    ) {
                        SplashScreen(onFinished = { splashDone = true })
                    }
                    VolumeOverlay(volume)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openFrom(intent)
    }

    private fun openFrom(intent: Intent?) {
        if (intent?.action != Intent.ACTION_VIEW) return
        intent.data?.let(vm::openExternal)
    }

    override fun onResume() {
        super.onResume()
        volume.refresh()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean = when (keyCode) {
        KeyEvent.KEYCODE_VOLUME_UP -> {
            volume.step(1)
            true
        }
        KeyEvent.KEYCODE_VOLUME_DOWN -> {
            volume.step(-1)
            true
        }
        else -> super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean = when (keyCode) {
        KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN -> true
        else -> super.onKeyUp(keyCode, event)
    }
}

private data class Tab(val label: String, val icon: ImageVector)

private val Tabs = listOf(
    Tab("Library", Icons.Rounded.LibraryMusic),
    Tab("Search", Icons.Rounded.Search),
    Tab("Playlists", Icons.Rounded.QueueMusic),
    Tab("Settings", Icons.Rounded.Settings)
)

@Composable
private fun SonoraRoot(vm: PlayerViewModel, ready: Boolean) {
    val audioPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    var granted by remember { mutableStateOf<Boolean?>(null) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { result ->
        granted = result
        if (result) vm.onAccessGranted()
    }
    val appSettings by vm.settings.collectAsStateWithLifecycle()
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val systemRequest by vm.systemRequest.collectAsStateWithLifecycle()
    val systemLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        vm.onSystemRequestHandled(result.resultCode == android.app.Activity.RESULT_OK)
    }
    LaunchedEffect(systemRequest) {
        systemRequest?.let { sender ->
            systemLauncher.launch(IntentSenderRequest.Builder(sender).build())
            vm.consumeSystemRequest()
        }
    }

    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) {
        val has = androidx.core.content.ContextCompat.checkSelfPermission(context, audioPermission) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        if (has) {
            granted = true
            vm.onAccessGranted()
        }
    }
    LaunchedEffect(ready) {
        if (!ready) return@LaunchedEffect
        if (granted != true) permissionLauncher.launch(audioPermission)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    if (granted == false) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            EmptyState(
                icon = Icons.Rounded.LibraryMusic,
                title = "Allow music access",
                message = "Sonora needs permission to read the audio files on your device.",
                modifier = Modifier.weight(1f),
                useMark = true
            )
            Button(onClick = { permissionLauncher.launch(audioPermission) }) {
                Text("Grant access", textAlign = TextAlign.Center)
            }
        }
        return
    }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    val settingsScroll = rememberScrollState()
    var expanded by rememberSaveable { mutableStateOf(false) }
    var playlistTarget by remember { mutableStateOf<List<Track>?>(null) }

    val routes by vm.routes.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val route = routes.lastOrNull()
    val addToPlaylist: (Track) -> Unit = { playlistTarget = listOf(it) }

    BackHandler(enabled = expanded) { expanded = false }
    BackHandler(enabled = !expanded && routes.isNotEmpty()) { vm.back() }
    BackHandler(enabled = !expanded && routes.isEmpty() && tab != 0) { tab = 0 }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                AnimatedContent(
                    targetState = route,
                    transitionSpec = {
                        if (targetState != null && initialState == null) {
                            (slideInHorizontally(tween(280)) { it / 4 } + fadeIn(tween(280))) togetherWith
                                fadeOut(tween(160))
                        } else {
                            fadeIn(tween(200)) togetherWith
                                (slideOutHorizontally(tween(280)) { it / 4 } + fadeOut(tween(200)))
                        }
                    },
                    label = "routes"
                ) { target ->
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background,
                        contentColor = MaterialTheme.colorScheme.onBackground
                    ) {
                        Box(Modifier.fillMaxSize().auroraBackdrop()) {
                            if (target == null) {
                                when (tab) {
                                    0 -> LibraryScreen(vm, addToPlaylist)
                                    1 -> SearchScreen(vm, addToPlaylist)
                                    2 -> PlaylistsScreen(vm)
                                    else -> SettingsScreen(vm, settingsScroll)
                                }
                            } else {
                                RouteContent(target, vm, addToPlaylist)
                            }
                        }
                    }
                }
            }
            if (now.track != null) {
                MiniPlayer(vm) { expanded = true }
            }
            SonoraNavBar(selected = if (routes.isEmpty()) tab else -1) { index ->
                tab = index
                vm.clearRoutes()
            }
        }

        AnimatedVisibility(
            visible = expanded && now.track != null,
            enter = slideInVertically(tween(320)) { it } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(280)) { it } + fadeOut(tween(200))
        ) {
            NowPlayingScreen(
                vm = vm,
                onCollapse = { expanded = false },
                onAddToPlaylist = addToPlaylist,
                onOpenEqualizer = {
                    expanded = false
                    vm.open(Route.EqualizerRoute)
                }
            )
        }
    }

    if (ready && granted == true && !appSettings.onlineAsked) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Find lyrics and covers online?") },
            text = {
                Text(
                    "Sonora can look up lyrics and missing cover art in the background. " +
                        "This sends song titles and artist names to lrclib.net, iTunes and Deezer. " +
                        "You can change this anytime in Settings."
                )
            },
            confirmButton = { TextButton(onClick = { vm.answerOnlineConsent(true) }) { Text("Allow") } },
            dismissButton = { TextButton(onClick = { vm.answerOnlineConsent(false) }) { Text("Not now") } }
        )
    }

    playlistTarget?.let { targets ->
        AddToPlaylistDialog(vm = vm, tracks = targets, onDismiss = { playlistTarget = null })
    }
}

@Composable
private fun SonoraNavBar(selected: Int, onSelect: (Int) -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(30.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.94f),
        tonalElevation = 3.dp,
        shadowElevation = 10.dp
    ) {
        Row(
            Modifier.padding(6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Tabs.forEachIndexed { index, item ->
                NavItem(item, index == selected) { onSelect(index) }
            }
        }
    }
}

@Composable
private fun NavItem(item: Tab, selected: Boolean, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val brush = brandBrush()
    val fill by animateFloatAsState(if (selected) 1f else 0f, tween(260), label = "navFill")
    val tint by animateColorAsState(
        if (selected) scheme.onPrimary else scheme.onSurfaceVariant,
        tween(260),
        label = "navTint"
    )
    Row(
        Modifier
            .animateContentSize(tween(260))
            .clip(RoundedCornerShape(24.dp))
            .background(brush, RoundedCornerShape(24.dp), alpha = fill)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(item.icon, contentDescription = item.label, tint = tint, modifier = Modifier.size(24.dp))
        if (selected) {
            Spacer(Modifier.width(8.dp))
            Text(text = item.label, color = tint, style = MaterialTheme.typography.labelLarge, maxLines = 1)
        }
    }
}

@Composable
private fun RouteContent(route: Route, vm: PlayerViewModel, onAddToPlaylist: (Track) -> Unit) {
    val library by vm.library.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val playCounts by vm.playCounts.collectAsStateWithLifecycle()

    when (route) {
        is Route.AlbumRoute -> {
            val album = library.albums.firstOrNull { it.id == route.albumId }
            if (album != null) {
                AlbumScreen(album, vm, vm::back, onAddToPlaylist)
            } else {
                LaunchedEffect(route) { vm.back() }
            }
        }
        is Route.ArtistRoute -> {
            val artist = library.artists.firstOrNull { it.name == route.name }
            if (artist != null) {
                val albums = library.albums.filter { album -> album.tracks.any { it.artist == artist.name } }
                ArtistScreen(artist, albums, vm, vm::back, onAddToPlaylist)
            } else {
                LaunchedEffect(route) { vm.back() }
            }
        }
        is Route.FolderRoute -> {
            val folder = library.folders.firstOrNull { it.path == route.path }
            if (folder != null) {
                FolderScreen(folder, vm, vm::back, onAddToPlaylist)
            } else {
                LaunchedEffect(route) { vm.back() }
            }
        }
        is Route.PlaylistRoute -> {
            val playlist = playlists.firstOrNull { it.id == route.id }
            if (playlist != null) {
                val tracks = playlist.trackIds.mapNotNull { library.track(it) }
                PlaylistScreen(playlist, tracks, vm, vm::back, onAddToPlaylist)
            }
        }
        Route.FavoritesRoute -> {
            val tracks = favorites.mapNotNull { library.track(it) }
            TrackCollectionScreen(
                title = "Favorites",
                subtitle = "${tracks.size} songs",
                tracks = tracks,
                cover = tracks.firstOrNull(),
                vm = vm,
                onBack = vm::back,
                onAddToPlaylist = onAddToPlaylist
            )
        }
        Route.RecentRoute -> {
            val tracks = library.tracks.sortedByDescending { it.dateAdded }.take(50)
            TrackCollectionScreen(
                title = "Recently added",
                subtitle = "${tracks.size} songs",
                tracks = tracks,
                cover = tracks.firstOrNull(),
                vm = vm,
                onBack = vm::back,
                onAddToPlaylist = onAddToPlaylist
            )
        }
        Route.MostPlayedRoute -> {
            val tracks = library.tracks
                .filter { (playCounts[it.id] ?: 0) > 0 }
                .sortedByDescending { playCounts[it.id] ?: 0 }
                .take(50)
            TrackCollectionScreen(
                title = "Most played",
                subtitle = "${tracks.size} songs",
                tracks = tracks,
                cover = tracks.firstOrNull(),
                vm = vm,
                onBack = vm::back,
                onAddToPlaylist = onAddToPlaylist
            )
        }
        Route.EqualizerRoute -> EqualizerScreen(onBack = vm::back)
        Route.AboutRoute -> AboutScreen(onBack = vm::back)
    }
}
