package com.sonora.player

import android.app.Application
import android.app.RecoverableSecurityException
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.IntentSender
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.sonora.player.data.AppSettings
import com.sonora.player.data.Library
import com.sonora.player.data.LibraryStore
import com.sonora.player.data.LyricsCandidate
import com.sonora.player.data.LyricsRepository
import com.sonora.player.data.LyricsSearchState
import com.sonora.player.data.LyricsState
import com.sonora.player.data.MusicRepository
import com.sonora.player.data.Playlist
import com.sonora.player.data.Route
import com.sonora.player.data.SavedSession
import com.sonora.player.data.Track
import com.sonora.player.data.TrackEdit
import com.sonora.player.playback.PlaybackService
import com.sonora.player.playback.SleepTimer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

data class NowPlaying(
    val track: Track? = null,
    val isPlaying: Boolean = false,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val speed: Float = 1f,
    val queue: List<Track> = emptyList(),
    val queueIndex: Int = -1
)

fun Track.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId))
                .build()
        )
        .build()

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    private val context: Context = app
    private val repository = MusicRepository(app)
    private val store = LibraryStore(app)
    private val lyricsRepository = LyricsRepository(app)

    private var controller: MediaController? = null
    private var queueCache: List<Track> = emptyList()
    private var restored = false
    private var hasAccess = false
    private var refreshJob: Job? = null
    private var lyricsJob: Job? = null
    private var searchJob: Job? = null
    private var lyricsTrackId: Long? = null
    private var countedThisPlay = false
    private var seekHoldUntil = 0L
    private var errorStreak = 0
    private var pendingDelete: List<Track> = emptyList()
    private val deletedBuffer = ArrayList<Track>()

    private val mutableLibrary = MutableStateFlow(Library())
    private val mutableLoading = MutableStateFlow(false)
    private val mutableLoadError = MutableStateFlow<String?>(null)
    private val mutableNow = MutableStateFlow(NowPlaying())
    private val mutablePosition = MutableStateFlow(0L)
    private val mutableFavorites = MutableStateFlow(store.favorites())
    private val mutablePlaylists = MutableStateFlow(store.playlists())
    private val mutableSettings = MutableStateFlow(store.settings())
    private val mutableRoutes = MutableStateFlow<List<Route>>(emptyList())
    private val mutableLyrics = MutableStateFlow<LyricsState>(LyricsState.Idle)
    private val mutableLyricsSearch = MutableStateFlow<LyricsSearchState>(LyricsSearchState.Idle)
    private val mutableEdits = MutableStateFlow(store.trackEdits())
    private val mutablePlayCounts = MutableStateFlow(store.playCounts())
    private val mutableRequest = MutableStateFlow<IntentSender?>(null)

    val library: StateFlow<Library> = mutableLibrary.asStateFlow()
    val loading: StateFlow<Boolean> = mutableLoading.asStateFlow()
    val loadError: StateFlow<String?> = mutableLoadError.asStateFlow()
    val now: StateFlow<NowPlaying> = mutableNow.asStateFlow()
    val position: StateFlow<Long> = mutablePosition.asStateFlow()
    val favorites: StateFlow<Set<Long>> = mutableFavorites.asStateFlow()
    val playlists: StateFlow<List<Playlist>> = mutablePlaylists.asStateFlow()
    val settings: StateFlow<AppSettings> = mutableSettings.asStateFlow()
    val routes: StateFlow<List<Route>> = mutableRoutes.asStateFlow()
    val lyrics: StateFlow<LyricsState> = mutableLyrics.asStateFlow()
    val lyricsSearch: StateFlow<LyricsSearchState> = mutableLyricsSearch.asStateFlow()
    val sleepRemaining: StateFlow<Long?> = SleepTimer.remaining
    val edits: StateFlow<Map<Long, TrackEdit>> = mutableEdits.asStateFlow()
    val playCounts: StateFlow<Map<Long, Int>> = mutablePlayCounts.asStateFlow()
    val systemRequest: StateFlow<IntentSender?> = mutableRequest.asStateFlow()

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            if (hasAccess) scheduleRefresh()
        }
    }

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync(events.contains(Player.EVENT_TIMELINE_CHANGED))
            if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)) countedThisPlay = false
            if (events.contains(Player.EVENT_IS_PLAYING_CHANGED) && player.isPlaying) errorStreak = 0
            if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION) ||
                (events.contains(Player.EVENT_IS_PLAYING_CHANGED) && !player.isPlaying)
            ) {
                saveSession()
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            handlePlayerError()
        }
    }

    init {
        app.contentResolver.registerContentObserver(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, observer)
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            runCatching { future.get() }.getOrNull()?.let { connected ->
                controller = connected
                connected.addListener(listener)
                sync(true)
                restoreSession()
            }
        }, ContextCompat.getMainExecutor(app))
        viewModelScope.launch { tick() }
    }

    fun onAccessGranted() {
        hasAccess = true
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            mutableLoading.value = true
            runCatching { repository.load(mutableSettings.value.hideShort, mutableEdits.value) }
                .onSuccess {
                    mutableLibrary.value = it
                    mutableLoadError.value = null
                }
                .onFailure { mutableLoadError.value = "${it::class.java.simpleName}: ${it.message}" }
            mutableLoading.value = false
            sync(true)
            restoreSession()
        }
    }

    private fun scheduleRefresh() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            delay(1500)
            refresh()
        }
    }

    private suspend fun tick() {
        var elapsed = 0L
        while (true) {
            val c = controller
            if (c != null) {
                if (System.currentTimeMillis() >= seekHoldUntil) {
                    mutablePosition.value = c.currentPosition.coerceAtLeast(0L)
                }
                countPlayIfNeeded(c)
                if (c.isPlaying) {
                    elapsed += 250
                    if (elapsed >= 5000) {
                        elapsed = 0
                        saveSession()
                    }
                }
            }
            delay(250)
        }
    }

    private fun toast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    private fun handlePlayerError() {
        val c = controller ?: return
        errorStreak++
        val name = mutableNow.value.track?.title
        if (errorStreak > c.mediaItemCount.coerceAtLeast(1)) {
            errorStreak = 0
            toast("These songs can't be played")
            return
        }
        toast(if (name != null) "Can't play \"$name\"" else "Can't play this song")
        if (c.hasNextMediaItem()) {
            c.seekToNextMediaItem()
            c.prepare()
            c.play()
        }
    }

    private fun countPlayIfNeeded(c: MediaController) {
        if (countedThisPlay || !c.isPlaying) return
        val id = c.currentMediaItem?.mediaId?.toLongOrNull() ?: return
        val duration = c.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: return
        if (c.currentPosition < minOf(30_000L, duration / 2)) return
        countedThisPlay = true
        val counts = mutablePlayCounts.value
        val updated = counts + (id to ((counts[id] ?: 0) + 1))
        mutablePlayCounts.value = updated
        store.savePlayCounts(updated)
    }

    private fun sync(rebuildQueue: Boolean = false) {
        val c = controller ?: return
        val lib = mutableLibrary.value
        if (rebuildQueue) {
            queueCache = (0 until c.mediaItemCount).mapNotNull { index ->
                c.getMediaItemAt(index).mediaId.toLongOrNull()?.let { lib.track(it) }
            }
        }
        val current = c.currentMediaItem?.mediaId?.toLongOrNull()?.let { lib.track(it) }
        if (current?.id != lyricsTrackId) loadLyrics(current)
        val duration = c.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: current?.durationMs ?: 0L
        mutableNow.value = NowPlaying(
            track = current,
            isPlaying = c.isPlaying,
            durationMs = duration,
            shuffle = c.shuffleModeEnabled,
            repeat = c.repeatMode,
            speed = c.playbackParameters.speed,
            queue = queueCache,
            queueIndex = c.currentMediaItemIndex
        )
    }

    private fun restoreSession() {
        val c = controller ?: return
        val lib = mutableLibrary.value
        if (restored || lib.tracks.isEmpty()) return
        restored = true
        if (c.mediaItemCount > 0) return
        val saved = store.session() ?: return
        val tracks = saved.ids.mapNotNull { lib.track(it) }
        if (tracks.isEmpty()) return
        c.setMediaItems(tracks.map { it.toMediaItem() }, saved.index.coerceIn(tracks.indices), saved.positionMs)
        c.prepare()
    }

    private fun saveSession() {
        val c = controller ?: return
        if (queueCache.isEmpty()) return
        store.saveSession(SavedSession(queueCache.map { it.id }, c.currentMediaItemIndex, c.currentPosition))
    }

    fun playTracks(tracks: List<Track>, startIndex: Int, shuffle: Boolean = false) {
        val c = controller ?: return
        if (tracks.isEmpty()) return
        val index = startIndex.coerceIn(tracks.indices)
        val target = tracks[index]
        val currentId = c.currentMediaItem?.mediaId?.toLongOrNull()
        c.shuffleModeEnabled = shuffle
        if (currentId == target.id && c.mediaItemCount > 0) {
            val sameQueue = queueCache.map { it.id } == tracks.map { it.id }
            if (!sameQueue) {
                c.setMediaItems(tracks.map { it.toMediaItem() }, index, c.currentPosition.coerceAtLeast(0L))
                c.prepare()
            }
            if (!c.isPlaying) {
                if (c.playbackState == Player.STATE_ENDED) c.seekToDefaultPosition()
                c.play()
            }
            return
        }
        c.setMediaItems(tracks.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun shufflePlay(tracks: List<Track>) {
        if (tracks.isEmpty()) return
        playTracks(tracks, Random.nextInt(tracks.size), shuffle = true)
    }

    fun togglePlay() {
        val c = controller ?: return
        when {
            c.isPlaying -> c.pause()
            c.playbackState == Player.STATE_ENDED -> {
                c.seekToDefaultPosition()
                c.play()
            }
            else -> {
                if (c.playbackState == Player.STATE_IDLE) c.prepare()
                c.play()
            }
        }
    }

    fun next() {
        controller?.seekToNext()
    }

    fun previous() {
        controller?.seekToPrevious()
    }

    fun livePosition(): Long = controller?.currentPosition?.coerceAtLeast(0L) ?: mutablePosition.value

    fun isPlayingNow(): Boolean = controller?.isPlaying == true

    fun seekTo(ms: Long) {
        seekHoldUntil = System.currentTimeMillis() + 600L
        controller?.seekTo(ms)
        mutablePosition.value = ms
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun setSpeed(speed: Float) {
        controller?.setPlaybackSpeed(speed)
    }

    fun playQueueIndex(index: Int) {
        val c = controller ?: return
        if (index !in 0 until c.mediaItemCount) return
        if (index == c.currentMediaItemIndex) {
            if (!c.isPlaying) c.play()
            return
        }
        c.seekToDefaultPosition(index)
        c.play()
    }

    fun removeFromQueue(index: Int) {
        val c = controller ?: return
        if (index in 0 until c.mediaItemCount) c.removeMediaItem(index)
    }

    fun playNext(track: Track) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            c.setMediaItem(track.toMediaItem())
            c.prepare()
        } else {
            c.addMediaItem(c.currentMediaItemIndex + 1, track.toMediaItem())
        }
    }

    fun enqueue(track: Track) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            c.setMediaItem(track.toMediaItem())
            c.prepare()
        } else {
            c.addMediaItem(track.toMediaItem())
        }
    }

    fun toggleFavorite(track: Track) {
        val updated = mutableFavorites.value.let { if (track.id in it) it - track.id else it + track.id }
        mutableFavorites.value = updated
        store.saveFavorites(updated)
    }

    fun createPlaylist(name: String, initial: List<Long> = emptyList()): Long {
        val id = System.currentTimeMillis()
        val title = name.trim().ifEmpty { "New playlist" }
        updatePlaylists { it + Playlist(id, title, initial.distinct()) }
        return id
    }

    fun renamePlaylist(id: Long, name: String) {
        val title = name.trim()
        if (title.isEmpty()) return
        updatePlaylists { list -> list.map { if (it.id == id) it.copy(name = title) else it } }
    }

    fun deletePlaylist(id: Long) {
        updatePlaylists { list -> list.filterNot { it.id == id } }
    }

    fun addToPlaylist(playlistId: Long, ids: List<Long>) {
        updatePlaylists { list ->
            list.map { if (it.id == playlistId) it.copy(trackIds = (it.trackIds + ids).distinct()) else it }
        }
    }

    fun removeFromPlaylist(playlistId: Long, trackId: Long) {
        updatePlaylists { list ->
            list.map { if (it.id == playlistId) it.copy(trackIds = it.trackIds - trackId) else it }
        }
    }

    private fun updatePlaylists(transform: (List<Playlist>) -> List<Playlist>) {
        val updated = transform(mutablePlaylists.value)
        mutablePlaylists.value = updated
        store.savePlaylists(updated)
    }

    private fun loadLyrics(track: Track?, force: Boolean = false) {
        lyricsTrackId = track?.id
        lyricsJob?.cancel()
        if (track == null) {
            mutableLyrics.value = LyricsState.Idle
            return
        }
        mutableLyrics.value = LyricsState.Loading
        lyricsJob = viewModelScope.launch {
            mutableLyrics.value = try {
                lyricsRepository.load(track, mutableSettings.value.onlineLyrics, force)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                LyricsState.Failed
            }
        }
    }

    fun retryLyrics() {
        loadLyrics(mutableNow.value.track, force = true)
    }

    fun searchLyrics(title: String, artist: String) {
        val cleanTitle = title.trim()
        val cleanArtist = artist.trim()
        if (cleanTitle.isEmpty() && cleanArtist.isEmpty()) return
        searchJob?.cancel()
        mutableLyricsSearch.value = LyricsSearchState.Searching
        searchJob = viewModelScope.launch {
            mutableLyricsSearch.value = lyricsRepository.search(cleanTitle, cleanArtist)
        }
    }

    fun applyLyrics(candidate: LyricsCandidate) {
        val track = mutableNow.value.track ?: return
        viewModelScope.launch {
            val state = lyricsRepository.saveCandidate(track.id, candidate)
            if (lyricsTrackId == track.id) mutableLyrics.value = state
        }
        resetLyricsSearch()
    }

    fun resetLyricsSearch() {
        searchJob?.cancel()
        mutableLyricsSearch.value = LyricsSearchState.Idle
    }

    fun importLyrics(uri: Uri) {
        val track = mutableNow.value.track ?: return
        viewModelScope.launch {
            val text = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                }.getOrNull()
            }
            if (text.isNullOrBlank()) return@launch
            val state = lyricsRepository.saveImported(track.id, text)
            if (lyricsTrackId == track.id) mutableLyrics.value = state
        }
    }

    fun saveTrackEdit(track: Track, title: String, artist: String, album: String) {
        val edit = TrackEdit(
            title = title.trim().ifEmpty { track.title },
            artist = artist.trim().ifEmpty { track.artist },
            album = album.trim().ifEmpty { track.album }
        )
        val updated = mutableEdits.value + (track.id to edit)
        mutableEdits.value = updated
        store.saveTrackEdits(updated)
        refresh()
    }

    fun resetTrackEdit(trackId: Long) {
        val updated = mutableEdits.value - trackId
        mutableEdits.value = updated
        store.saveTrackEdits(updated)
        refresh()
    }

    fun deleteTracks(tracks: List<Track>) {
        if (tracks.isEmpty()) return
        pendingDelete = tracks
        deletedBuffer.clear()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val sender = runCatching {
                MediaStore.createDeleteRequest(context.contentResolver, tracks.map { it.uri }).intentSender
            }.getOrNull()
            if (sender == null) {
                pendingDelete = emptyList()
                toast("Couldn't delete")
            } else {
                mutableRequest.value = sender
            }
        } else {
            viewModelScope.launch { deleteLegacy() }
        }
    }

    private suspend fun deleteLegacy() {
        val remaining = pendingDelete.toMutableList()
        var failed = 0
        while (remaining.isNotEmpty()) {
            val track = remaining.first()
            val problem = withContext(Dispatchers.IO) {
                try {
                    if (context.contentResolver.delete(track.uri, null, null) > 0) null else SecurityException()
                } catch (error: SecurityException) {
                    error
                }
            }
            if (problem == null) {
                deletedBuffer += track
                remaining.removeAt(0)
                continue
            }
            val sender = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && problem is RecoverableSecurityException) {
                problem.userAction.actionIntent.intentSender
            } else {
                null
            }
            if (sender != null) {
                pendingDelete = remaining
                mutableRequest.value = sender
                return
            }
            failed++
            remaining.removeAt(0)
        }
        pendingDelete = emptyList()
        finishDelete(failed)
    }

    private fun finishDelete(failed: Int) {
        val done = deletedBuffer.toList()
        deletedBuffer.clear()
        if (done.isNotEmpty()) afterDeleted(done)
        if (failed > 0) toast("Couldn't delete $failed song(s)")
    }

    fun consumeSystemRequest() {
        mutableRequest.value = null
    }

    fun onSystemRequestHandled(granted: Boolean) {
        val tracks = pendingDelete
        if (tracks.isEmpty()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            pendingDelete = emptyList()
            if (granted) afterDeleted(tracks)
            return
        }
        if (granted) {
            viewModelScope.launch { deleteLegacy() }
        } else {
            pendingDelete = emptyList()
            finishDelete(0)
        }
    }

    private fun afterDeleted(tracks: List<Track>) {
        val ids = tracks.map { it.id }.toSet()
        controller?.let { c ->
            for (index in c.mediaItemCount - 1 downTo 0) {
                val id = c.getMediaItemAt(index).mediaId.toLongOrNull()
                if (id != null && id in ids) c.removeMediaItem(index)
            }
        }
        val favorites = mutableFavorites.value - ids
        mutableFavorites.value = favorites
        store.saveFavorites(favorites)
        updatePlaylists { list -> list.map { playlist -> playlist.copy(trackIds = playlist.trackIds.filterNot { it in ids }) } }
        val counts = mutablePlayCounts.value - ids
        mutablePlayCounts.value = counts
        store.savePlayCounts(counts)
        val edits = mutableEdits.value - ids
        mutableEdits.value = edits
        store.saveTrackEdits(edits)
        toast(if (tracks.size == 1) "Song deleted" else "${tracks.size} songs deleted")
        refresh()
    }

    fun startSleepTimer(minutes: Int) {
        SleepTimer.start(minutes)
    }

    fun cancelSleepTimer() {
        SleepTimer.cancel()
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val old = mutableSettings.value
        val updated = transform(old)
        mutableSettings.value = updated
        store.saveSettings(updated)
        if (old.hideShort != updated.hideShort && hasAccess) refresh()
    }

    fun open(route: Route) {
        mutableRoutes.value = mutableRoutes.value + route
    }

    fun back() {
        val current = mutableRoutes.value
        if (current.isNotEmpty()) mutableRoutes.value = current.dropLast(1)
    }

    fun clearRoutes() {
        mutableRoutes.value = emptyList()
    }

    override fun onCleared() {
        saveSession()
        context.contentResolver.unregisterContentObserver(observer)
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
