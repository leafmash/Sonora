package com.sonora.player

import android.app.Application
import android.app.RecoverableSecurityException
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.IntentSender
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.sonora.player.data.AppSettings
import com.sonora.player.data.BackupCodec
import com.sonora.player.data.BackupData
import com.sonora.player.data.CoverFinder
import com.sonora.player.data.CoverOption
import com.sonora.player.data.CoverSearchState
import com.sonora.player.data.CoverStore
import com.sonora.player.data.BatchIdentify
import com.sonora.player.data.IdentifyMatch
import com.sonora.player.data.IdentifyState
import com.sonora.player.data.Library
import com.sonora.player.data.LibraryStore
import com.sonora.player.data.LrcParser
import com.sonora.player.data.LyricsCandidate
import com.sonora.player.data.LyricsLoad
import com.sonora.player.data.LyricsName
import com.sonora.player.data.LyricsRepository
import com.sonora.player.data.LyricsSearchState
import com.sonora.player.data.LyricsState
import com.sonora.player.data.MusicRepository
import com.sonora.player.data.NetworkMonitor
import com.sonora.player.data.Playlist
import com.sonora.player.data.Route
import com.sonora.player.data.Track
import com.sonora.player.data.TrackEdit
import com.sonora.player.data.TrackIdentifier
import com.sonora.player.data.TrackNameCleaner
import com.sonora.player.data.isUnidentified
import com.sonora.player.playback.ArtBitmapLoader
import com.sonora.player.playback.NotificationLyrics
import com.sonora.player.playback.PlaybackService
import com.sonora.player.playback.SessionResume
import com.sonora.player.playback.SleepTimer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.random.Random
import com.sonora.player.party.PartySession
import com.sonora.player.party.PartyUi

data class NowPlaying(
    val track: Track? = null,
    val isPlaying: Boolean = false,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val speed: Float = 1f,
    val queue: List<Track> = emptyList(),
    val queueIndex: Int = -1
)

private const val SYNC_GAP_MS = 400L
private const val SYNC_RETRY_MS = 60_000L
private const val SYNC_BATCH = 5
private const val BATCH_GAP_MS = 400L
private const val BATCH_MIN_SCORE = 0.85
private const val BATCH_MAX_FAILURES = 3
private const val NOTIFICATION_LEAD_MS = 300L
private const val TITLE_ACCEPT = 0.8
private const val ARTIST_ACCEPT = 0.7
private const val COVER_MAX_SIDE = 1000

fun Track.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(ArtBitmapLoader.uriFor(id, mediaId, albumId, uri.takeIf { id < 0 }))
                .build()
        )
        .build()

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    private val context: Context = app
    private val repository = MusicRepository(app)
    private val store = LibraryStore(app)
    private val lyricsRepository = LyricsRepository(app)
    private val network = NetworkMonitor(app)
    private val coverFinder = CoverFinder(app)
    private val trackIdentifier = TrackIdentifier(app)

    private var controller: MediaController? = null
    private val partyDelegate = lazy { PartySession(this, context) }
    private val partySession by partyDelegate
    private var queueCache: List<Track> = emptyList()
    private var restored = false
    private var pendingExternal: Uri? = null
    private val externalTracks = HashMap<Long, Track>()
    private var hasAccess = false
    private var refreshJob: Job? = null
    private var lyricsJob: Job? = null
    private var searchJob: Job? = null
    private var coverSearchJob: Job? = null
    private var identifyJob: Job? = null
    private var batchJob: Job? = null
    private var lyricsTrackId: Long? = null
    private var countedThisPlay = false
    private var seekHoldUntil = 0L
    private var errorStreak = 0
    private var pendingDelete: List<Track> = emptyList()
    private val deletedBuffer = ArrayList<Track>()

    private val mutableLibrary = MutableStateFlow(Library())
    private val mutableLoading = MutableStateFlow(false)
    private val mutableLoadError = MutableStateFlow<String?>(null)
    private val mutableNow = MutableStateFlow(NowPlaying())
    private val mutablePosition = MutableStateFlow(0L)
    private val mutableFavorites = MutableStateFlow(store.favorites())
    private val mutablePlaylists = MutableStateFlow(store.playlists())
    private val mutableSettings = MutableStateFlow(store.settings())
    private val mutableRoutes = MutableStateFlow<List<Route>>(emptyList())
    private val mutableLyrics = MutableStateFlow<LyricsState>(LyricsState.Idle)
    private val mutableLyricsSearch = MutableStateFlow<LyricsSearchState>(LyricsSearchState.Idle)
    private val mutableCoverSearch = MutableStateFlow<CoverSearchState>(CoverSearchState.Idle)
    private val mutableIdentify = MutableStateFlow<IdentifyState>(IdentifyState.Idle)
    private val mutableBatch = MutableStateFlow(BatchIdentify())
    private val mutableEdits = MutableStateFlow(store.trackEdits())
    private val mutableLyricNames = MutableStateFlow(store.lyricNames())
    private val mutablePlayCounts = MutableStateFlow(store.playCounts())
    private val mutableRequest = MutableStateFlow<IntentSender?>(null)

    val library: StateFlow<Library> = mutableLibrary.asStateFlow()
    val loading: StateFlow<Boolean> = mutableLoading.asStateFlow()
    val loadError: StateFlow<String?> = mutableLoadError.asStateFlow()
    val now: StateFlow<NowPlaying> = mutableNow.asStateFlow()
    val position: StateFlow<Long> = mutablePosition.asStateFlow()
    val favorites: StateFlow<Set<Long>> = mutableFavorites.asStateFlow()
    val playlists: StateFlow<List<Playlist>> = mutablePlaylists.asStateFlow()
    val settings: StateFlow<AppSettings> = mutableSettings.asStateFlow()
    val routes: StateFlow<List<Route>> = mutableRoutes.asStateFlow()
    val lyrics: StateFlow<LyricsState> = mutableLyrics.asStateFlow()
    val lyricsSearch: StateFlow<LyricsSearchState> = mutableLyricsSearch.asStateFlow()
    val coverSearch: StateFlow<CoverSearchState> = mutableCoverSearch.asStateFlow()
    val identify: StateFlow<IdentifyState> = mutableIdentify.asStateFlow()
    val batch: StateFlow<BatchIdentify> = mutableBatch.asStateFlow()
    val sleepRemaining: StateFlow<Long?> = SleepTimer.remaining
    val edits: StateFlow<Map<Long, TrackEdit>> = mutableEdits.asStateFlow()
    val lyricNames: StateFlow<Map<Long, LyricsName>> = mutableLyricNames.asStateFlow()
    val lyricsAvailable: StateFlow<Set<Long>> = lyricsRepository.available
    val playCounts: StateFlow<Map<Long, Int>> = mutablePlayCounts.asStateFlow()
    val systemRequest: StateFlow<IntentSender?> = mutableRequest.asStateFlow()

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            if (hasAccess) scheduleRefresh()
        }
    }

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync(events.contains(Player.EVENT_TIMELINE_CHANGED))
            if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)) countedThisPlay = false
            if (events.contains(Player.EVENT_IS_PLAYING_CHANGED) && player.isPlaying) errorStreak = 0
            if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION) ||
                (events.contains(Player.EVENT_IS_PLAYING_CHANGED) && !player.isPlaying)
            ) {
                saveSession()
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            handlePlayerError()
        }
    }

    init {
        app.contentResolver.registerContentObserver(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, observer)
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            runCatching { future.get() }.getOrNull()?.let { connected ->
                controller = connected
                connected.addListener(listener)
                sync(true)
                playPendingExternal()
                restoreSession()
            }
        }, ContextCompat.getMainExecutor(app))
        viewModelScope.launch { tick() }
        network.start()
        viewModelScope.launch { runLyricsSync() }
        viewModelScope.launch { runCoverSync() }
        viewModelScope.launch { runNotificationLyrics() }
    }

    private suspend fun runNotificationLyrics() {
        val enabled = mutableSettings.map { it.notificationLyrics }.distinctUntilChanged()
        combine(enabled, mutableLyrics) { on, state ->
            if (on) (state as? LyricsState.Synced)?.lines else null
        }.distinctUntilChanged().collectLatest { lines ->
            if (lines.isNullOrEmpty()) {
                NotificationLyrics.line.value = null
                return@collectLatest
            }
            try {
                while (true) {
                    val position = livePosition() + NOTIFICATION_LEAD_MS
                    val index = LrcParser.indexAt(lines, position)
                    NotificationLyrics.line.value = lines.getOrNull(index)?.text?.takeIf { it.isNotBlank() }
                    val wait = if (!isPlayingNow()) {
                        500L
                    } else {
                        val next = lines.getOrNull(index + 1)?.timeMs
                        if (next == null) 1000L else ((next - position) / mutableNow.value.speed).toLong().coerceIn(80L, 1000L)
                    }
                    delay(wait)
                }
            } finally {
                NotificationLyrics.line.value = null
            }
        }
    }

    private fun syncTargets(allowed: Flow<Boolean>): Flow<List<Long>> {
        val trackIds = mutableLibrary
            .map { library -> library.tracks.mapTo(HashSet<Long>()) { it.id } }
            .distinctUntilChanged()
        return combine(trackIds, network.online, allowed.distinctUntilChanged()) { ids, online, enabled ->
            if (online && enabled) ids.sortedDescending() else emptyList()
        }
    }

    private suspend fun runLyricsSync() {
        syncTargets(mutableSettings.map { it.onlineLyrics && it.onlineAsked }).collectLatest { ids ->
            if (ids.isEmpty()) return@collectLatest
            while (!syncPass(ids)) delay(SYNC_RETRY_MS)
        }
    }

    private suspend fun runCoverSync() {
        syncTargets(mutableSettings.map { it.onlineCovers && it.onlineAsked }).collectLatest { ids ->
            if (ids.isEmpty()) return@collectLatest
            while (!coverPass(ids)) delay(SYNC_RETRY_MS)
        }
    }

    private suspend fun coverPass(ids: List<Long>): Boolean {
        for (id in ids) {
            if (!CoverStore.needsLookup(id)) continue
            val track = mutableLibrary.value.track(id) ?: continue
            try {
                coverFinder.ensure(track)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                return false
            }
            delay(SYNC_GAP_MS)
        }
        return true
    }

    private suspend fun syncPass(ids: List<Long>): Boolean {
        val found = HashMap<Long, LyricsName>()
        try {
            for (id in ids) {
                if (!lyricsRepository.needsLookup(id)) continue
                val track = mutableLibrary.value.track(id) ?: continue
                val result = try {
                    lyricsRepository.load(track, true, false)
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    return false
                }
                if (result.state is LyricsState.Failed) return false
                result.name?.let { found[id] = it }
                if (found.size >= SYNC_BATCH) {
                    applyNames(found.toMap())
                    found.clear()
                }
                delay(SYNC_GAP_MS)
            }
            return true
        } finally {
            if (found.isNotEmpty()) applyNames(found.toMap())
        }
    }

    private fun acceptName(track: Track, name: LyricsName): LyricsName? {
        val unknownArtist = TrackNameCleaner.isUnknown(track.artist)
        val local = TrackNameCleaner.clean(track.title, track.artist.takeUnless { unknownArtist })
        val title = name.title.takeIf {
            TrackNameCleaner.sameScript(local.title, it) &&
                TrackNameCleaner.similarity(local.title, it) >= TITLE_ACCEPT
        }.orEmpty()
        val artist = name.artist.takeIf {
            it.isNotBlank() && (
                unknownArtist || (
                    TrackNameCleaner.sameScript(track.artist, it) &&
                        TrackNameCleaner.artistSimilarity(it, listOf(track.artist)) >= ARTIST_ACCEPT
                    )
                )
        }.orEmpty()
        val album = name.album.takeIf {
            it.isNotBlank() && (
                TrackNameCleaner.isUnknown(track.album) ||
                    TrackNameCleaner.sameScript(track.album, it)
                )
        }.orEmpty()
        if (title.isEmpty() && artist.isEmpty() && album.isEmpty()) return null
        return LyricsName(title, artist, album)
    }

    private fun applyNames(incoming: Map<Long, LyricsName>, manual: Boolean = false) {
        val library = mutableLibrary.value
        val accepted = if (manual) {
            incoming
        } else {
            incoming.mapNotNull { (id, name) ->
                library.track(id)?.let { track -> acceptName(track, name)?.let { id to it } }
            }.toMap()
        }
        if (accepted.isEmpty()) return
        val names = mutableLyricNames.value + accepted
        mutableLyricNames.value = names
        store.saveLyricNames(names)
        val edits = mutableEdits.value
        val movedArtists = HashMap<String, String>()
        var changed = false
        val tracks = library.tracks.map { track ->
            val name = accepted[track.id]
            if (name == null || track.id in edits) {
                track
            } else {
                val renamed = track.copy(
                    title = name.title.ifBlank { track.title },
                    artist = name.artist.ifBlank { track.artist },
                    album = name.album.ifBlank { track.album }
                )
                if (renamed != track) changed = true
                if (renamed.artist != track.artist) movedArtists[track.artist] = renamed.artist
                renamed
            }
        }
        if (changed) {
            val rebuilt = Library.build(tracks)
            mutableLibrary.value = rebuilt
            mutableRoutes.value = mutableRoutes.value.map { route ->
                val target = (route as? Route.ArtistRoute)?.let { movedArtists[it.name] }
                if (target != null && rebuilt.artists.none { it.name == (route as Route.ArtistRoute).name }) {
                    Route.ArtistRoute(target)
                } else {
                    route
                }
            }
            sync(true)
        }
    }

    fun onAccessGranted() {
        hasAccess = true
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            mutableLoading.value = true
            runCatching {
                val first = repository.load(mutableSettings.value.hideShort, mutableEdits.value, mutableLyricNames.value, mutableSettings.value.hiddenFolders)
                if (!store.idsMigrated() && first.tracks.isNotEmpty()) {
                    migrateIds(first.tracks.associate { it.mediaId to it.id })
                    repository.load(mutableSettings.value.hideShort, mutableEdits.value, mutableLyricNames.value, mutableSettings.value.hiddenFolders)
                } else {
                    first
                }
            }
                .onSuccess {
                    mutableLibrary.value = it
                    mutableLoadError.value = null
                }
                .onFailure { mutableLoadError.value = "${it::class.java.simpleName}: ${it.message}" }
            mutableLoading.value = false
            sync(true)
            restoreSession()
        }
    }

    private suspend fun migrateIds(map: Map<Long, Long>) {
        store.markIdsMigrated()
        store.saveFavorites(store.favorites().mapNotNull { map[it] }.toSet())
        store.savePlaylists(
            store.playlists().map { playlist ->
                playlist.copy(trackIds = playlist.trackIds.mapNotNull { map[it] }.distinct())
            }
        )
        store.saveTrackEdits(store.trackEdits().mapNotNull { (id, edit) -> map[id]?.let { it to edit } }.toMap())
        store.savePlayCounts(store.playCounts().mapNotNull { (id, count) -> map[id]?.let { it to count } }.toMap())
        store.saveLyricNames(store.lyricNames().mapNotNull { (id, name) -> map[id]?.let { it to name } }.toMap())
        store.session()?.let { session ->
            store.saveSession(session.copy(ids = session.ids.mapNotNull { map[it] }))
        }
        lyricsRepository.migrate(map)
        withContext(Dispatchers.IO) { CoverStore.migrate(map) }
        mutableFavorites.value = store.favorites()
        mutablePlaylists.value = store.playlists()
        mutableEdits.value = store.trackEdits()
        mutablePlayCounts.value = store.playCounts()
        mutableLyricNames.value = store.lyricNames()
    }

    fun answerOnlineConsent(allow: Boolean) {
        updateSettings { it.copy(onlineAsked = true, onlineLyrics = allow, onlineCovers = allow) }
    }

    private fun scheduleRefresh() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            delay(1500)
            refresh()
        }
    }

    private suspend fun tick() {
        var elapsed = 0L
        while (true) {
            val c = controller
            if (c != null) {
                if (System.currentTimeMillis() >= seekHoldUntil) {
                    mutablePosition.value = c.currentPosition.coerceAtLeast(0L)
                }
                countPlayIfNeeded(c)
                if (c.isPlaying) {
                    elapsed += 250
                    if (elapsed >= 5000) {
                        elapsed = 0
                        saveSession()
                    }
                }
            }
            delay(250)
        }
    }

    private fun toast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    private fun handlePlayerError() {
        val c = controller ?: return
        errorStreak++
        val name = mutableNow.value.track?.title
        if (errorStreak > c.mediaItemCount.coerceAtLeast(1)) {
            errorStreak = 0
            toast("These songs can't be played")
            return
        }
        toast(if (name != null) "Can't play \"$name\"" else "Can't play this song")
        if (c.hasNextMediaItem()) {
            c.seekToNextMediaItem()
            c.prepare()
            c.play()
        }
    }

    private fun countPlayIfNeeded(c: MediaController) {
        if (countedThisPlay || !c.isPlaying) return
        val id = c.currentMediaItem?.mediaId?.toLongOrNull() ?: return
        val duration = c.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: return
        if (c.currentPosition < minOf(30_000L, duration / 2)) return
        countedThisPlay = true
        val counts = mutablePlayCounts.value
        val updated = counts + (id to ((counts[id] ?: 0) + 1))
        mutablePlayCounts.value = updated
        store.savePlayCounts(updated)
    }

    private fun sync(rebuildQueue: Boolean = false) {
        val c = controller ?: return
        val lib = mutableLibrary.value
        if (rebuildQueue) {
            queueCache = (0 until c.mediaItemCount).mapNotNull { index ->
                c.getMediaItemAt(index).mediaId.toLongOrNull()?.let { resolveTrack(it) }
            }
        }
        val current = c.currentMediaItem?.mediaId?.toLongOrNull()?.let { resolveTrack(it) }
        if (current?.id != lyricsTrackId) loadLyrics(current)
        val duration = c.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: current?.durationMs ?: 0L
        mutableNow.value = NowPlaying(
            track = current,
            isPlaying = c.isPlaying,
            durationMs = duration,
            shuffle = c.shuffleModeEnabled,
            repeat = c.repeatMode,
            speed = c.playbackParameters.speed,
            queue = queueCache,
            queueIndex = c.currentMediaItemIndex
        )
    }

    private fun restoreSession() {
        val c = controller ?: return
        val lib = mutableLibrary.value
        if (restored || lib.tracks.isEmpty()) return
        restored = true
        if (c.mediaItemCount > 0) return
        val saved = store.session() ?: return
        val point = SessionResume.resolve(saved, lib) ?: return
        c.setMediaItems(point.tracks.map { it.toMediaItem() }, point.index, point.positionMs)
        c.prepare()
    }

    private fun saveSession() {
        val c = controller ?: return
        SessionResume.snapshot(c)?.let { store.saveSession(it) }
    }

    private fun resolveTrack(id: Long): Track? = mutableLibrary.value.track(id) ?: externalTracks[id]

    fun openExternal(uri: Uri) {
        pendingExternal = uri
        restored = true
        playPendingExternal()
    }

    private fun playPendingExternal() {
        val c = controller ?: return
        val uri = pendingExternal ?: return
        pendingExternal = null
        viewModelScope.launch {
            val track = withContext(Dispatchers.IO) { buildExternalTrack(uri) }
            if (track == null) {
                toast("This file can't be played")
                return@launch
            }
            externalTracks[track.id] = track
            c.shuffleModeEnabled = false
            c.setMediaItems(listOf(track.toMediaItem()), 0, 0L)
            c.prepare()
            c.play()
        }
    }

    private fun buildExternalTrack(uri: Uri): Track? {
        val mediaId = uri.takeIf { it.authority == MediaStore.AUTHORITY }?.lastPathSegment?.toLongOrNull()
        mutableLibrary.value.tracks
            .firstOrNull { it.uri == uri || (mediaId != null && it.mediaId == mediaId) }
            ?.let { return it }
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            fun field(key: Int) = retriever.extractMetadata(key)?.takeIf { it.isNotBlank() }
            Track(
                id = -1L - (uri.toString().hashCode().toLong() and 0x7FFFFFFFL),
                mediaId = mediaId ?: 0L,
                title = field(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: displayName(uri) ?: "Unknown title",
                artist = field(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: "Unknown artist",
                album = field(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: "Unknown album",
                albumId = 0L,
                durationMs = field(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L,
                uri = uri,
                dateAdded = System.currentTimeMillis() / 1000,
                folder = ""
            )
        } catch (e: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun displayName(uri: Uri): String? {
        val raw = if (uri.scheme == "content") {
            runCatching {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { if (it.moveToFirst()) it.getString(0) else null }
            }.getOrNull()
        } else {
            uri.lastPathSegment
        }
        return raw?.substringBeforeLast('.')?.takeIf { it.isNotBlank() }
    }

    fun playTracks(tracks: List<Track>, startIndex: Int, shuffle: Boolean = false) {
        val c = controller ?: return
        if (tracks.isEmpty()) return
        val index = startIndex.coerceIn(tracks.indices)
        val target = tracks[index]
        val currentId = c.currentMediaItem?.mediaId?.toLongOrNull()
        c.shuffleModeEnabled = shuffle
        if (currentId == target.id && c.mediaItemCount > 0) {
            val sameQueue = queueCache.map { it.id } == tracks.map { it.id }
            if (!sameQueue) {
                c.setMediaItems(tracks.map { it.toMediaItem() }, index, c.currentPosition.coerceAtLeast(0L))
                c.prepare()
            }
            if (!c.isPlaying) {
                if (c.playbackState == Player.STATE_ENDED) c.seekToDefaultPosition()
                c.play()
            }
            return
        }
        c.setMediaItems(tracks.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun shufflePlay(tracks: List<Track>) {
        if (tracks.isEmpty()) return
        playTracks(tracks, Random.nextInt(tracks.size), shuffle = true)
    }

    fun togglePlay() {
        val c = controller ?: return
        when {
            c.isPlaying -> c.pause()
            c.playbackState == Player.STATE_ENDED -> {
                c.seekToDefaultPosition()
                c.play()
            }
            else -> {
                if (c.playbackState == Player.STATE_IDLE) c.prepare()
                c.play()
            }
        }
    }

    fun next() {
        controller?.seekToNext()
    }

    fun previous() {
        controller?.seekToPrevious()
    }

    fun livePosition(): Long = controller?.currentPosition?.coerceAtLeast(0L) ?: mutablePosition.value

    fun isPlayingNow(): Boolean = controller?.isPlaying == true

    fun seekTo(ms: Long) {
        seekHoldUntil = System.currentTimeMillis() + 600L
        controller?.seekTo(ms)
        mutablePosition.value = ms
    }

    fun seekBy(deltaMs: Long) {
        val c = controller ?: return
        if (c.mediaItemCount == 0 || c.currentMediaItem == null) return
        val duration = c.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: mutableNow.value.durationMs
        val base = if (System.currentTimeMillis() < seekHoldUntil) {
            mutablePosition.value
        } else {
            c.currentPosition.coerceAtLeast(0L)
        }
        val upper = if (duration > 0) duration else Long.MAX_VALUE
        seekTo((base + deltaMs).coerceIn(0L, upper))
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun setSpeed(speed: Float) {
        controller?.setPlaybackSpeed(speed)
    }

    fun playQueueIndex(index: Int) {
        val c = controller ?: return
        if (index !in 0 until c.mediaItemCount) return
        if (index == c.currentMediaItemIndex) {
            if (!c.isPlaying) c.play()
            return
        }
        c.seekToDefaultPosition(index)
        c.play()
    }

    fun removeFromQueue(index: Int) {
        val c = controller ?: return
        if (index in 0 until c.mediaItemCount) c.removeMediaItem(index)
    }

    private fun addToQueue(items: List<MediaItem>, next: Boolean) {
        val c = controller ?: return
        if (items.isEmpty()) return
        if (c.mediaItemCount == 0) {
            c.setMediaItems(items)
            c.prepare()
        } else {
            c.addMediaItems(if (next) c.currentMediaItemIndex + 1 else c.mediaItemCount, items)
        }
    }

    fun playNext(track: Track) = addToQueue(listOf(track.toMediaItem()), true)

    fun enqueue(track: Track) = addToQueue(listOf(track.toMediaItem()), false)

    fun playNext(tracks: List<Track>) {
        if (tracks.isEmpty()) return
        addToQueue(tracks.map { it.toMediaItem() }, true)
        toast(if (tracks.size == 1) "Playing next" else "${tracks.size} songs will play next")
    }

    fun enqueue(tracks: List<Track>) {
        if (tracks.isEmpty()) return
        addToQueue(tracks.map { it.toMediaItem() }, false)
        toast(if (tracks.size == 1) "Added to queue" else "${tracks.size} songs added to queue")
    }

    fun moveQueueItem(from: Int, to: Int) {
        val c = controller ?: return
        val last = c.mediaItemCount - 1
        if (from == to || from !in 0..last || to !in 0..last) return
        c.moveMediaItem(from, to)
    }

    fun clearQueue() {
        val c = controller ?: return
        val keep = c.currentMediaItemIndex
        if (c.mediaItemCount <= 1 || keep < 0) return
        c.removeMediaItems(keep + 1, c.mediaItemCount)
        if (keep > 0) c.removeMediaItems(0, keep)
    }

    fun saveQueueAsPlaylist(name: String) {
        val ids = queueCache.map { it.id }.filter { it > 0 }
        if (ids.isEmpty()) {
            toast("Nothing to save")
            return
        }
        createPlaylist(name, ids)
        toast("Queue saved as playlist")
    }

    fun toggleFavorite(track: Track) {
        val updated = mutableFavorites.value.let { if (track.id in it) it - track.id else it + track.id }
        mutableFavorites.value = updated
        store.saveFavorites(updated)
    }

    fun createPlaylist(name: String, initial: List<Long> = emptyList()): Long {
        val id = System.currentTimeMillis()
        val title = name.trim().ifEmpty { "New playlist" }
        updatePlaylists { it + Playlist(id, title, initial.distinct()) }
        return id
    }

    fun renamePlaylist(id: Long, name: String) {
        val title = name.trim()
        if (title.isEmpty()) return
        updatePlaylists { list -> list.map { if (it.id == id) it.copy(name = title) else it } }
    }

    fun deletePlaylist(id: Long) {
        updatePlaylists { list -> list.filterNot { it.id == id } }
    }

    fun addToPlaylist(playlistId: Long, ids: List<Long>) {
        updatePlaylists { list ->
            list.map { if (it.id == playlistId) it.copy(trackIds = (it.trackIds + ids).distinct()) else it }
        }
    }

    fun removeFromPlaylist(playlistId: Long, trackId: Long) {
        updatePlaylists { list ->
            list.map { if (it.id == playlistId) it.copy(trackIds = it.trackIds - trackId) else it }
        }
    }

    fun moveInPlaylist(playlistId: Long, trackId: Long, targetId: Long) {
        updatePlaylists { list ->
            list.map { playlist ->
                if (playlist.id != playlistId) return@map playlist
                val ids = playlist.trackIds.toMutableList()
                val from = ids.indexOf(trackId)
                val to = ids.indexOf(targetId)
                if (from < 0 || to < 0 || from == to) return@map playlist
                ids.add(to, ids.removeAt(from))
                playlist.copy(trackIds = ids)
            }
        }
    }

    private fun updatePlaylists(transform: (List<Playlist>) -> List<Playlist>) {
        val updated = transform(mutablePlaylists.value)
        mutablePlaylists.value = updated
        store.savePlaylists(updated)
    }

    private fun loadLyrics(track: Track?, force: Boolean = false) {
        lyricsTrackId = track?.id
        lyricsJob?.cancel()
        if (track == null) {
            mutableLyrics.value = LyricsState.Idle
            return
        }
        mutableLyrics.value = LyricsState.Loading
        lyricsJob = viewModelScope.launch {
            val loaded = try {
                lyricsRepository.load(track, mutableSettings.value.let { it.onlineLyrics && it.onlineAsked }, force)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                LyricsLoad(LyricsState.Failed)
            }
            mutableLyrics.value = loaded.state
            loaded.name?.let { applyNames(mapOf(track.id to it)) }
        }
    }

    fun retryLyrics() {
        loadLyrics(mutableNow.value.track, force = true)
    }

    fun searchLyrics(title: String, artist: String) {
        val cleanTitle = title.trim()
        val cleanArtist = artist.trim()
        if (cleanTitle.isEmpty() && cleanArtist.isEmpty()) return
        searchJob?.cancel()
        mutableLyricsSearch.value = LyricsSearchState.Searching
        searchJob = viewModelScope.launch {
            mutableLyricsSearch.value = lyricsRepository.search(cleanTitle, cleanArtist)
        }
    }

    fun applyLyrics(candidate: LyricsCandidate, searchedTitle: String, searchedArtist: String) {
        val track = mutableNow.value.track ?: return
        viewModelScope.launch {
            val state = lyricsRepository.saveCandidate(track.id, candidate)
            if (lyricsTrackId == track.id) mutableLyrics.value = state
            val name = LyricsName(
                title = searchedTitle.trim().ifEmpty { candidate.title },
                artist = searchedArtist.trim().ifEmpty { candidate.artist },
                album = candidate.album
            )
            applyNames(mapOf(track.id to name), manual = true)
        }
        resetLyricsSearch()
    }

    fun resetLyricsSearch() {
        searchJob?.cancel()
        mutableLyricsSearch.value = LyricsSearchState.Idle
    }

    fun importLyrics(uri: Uri) {
        val track = mutableNow.value.track ?: return
        viewModelScope.launch {
            val text = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                }.getOrNull()
            }
            if (text.isNullOrBlank()) return@launch
            val state = lyricsRepository.saveImported(track.id, text)
            if (lyricsTrackId == track.id) mutableLyrics.value = state
        }
    }

    fun saveTrackEdit(track: Track, title: String, artist: String, album: String) {
        val edit = TrackEdit(
            title = title.trim().ifEmpty { track.title },
            artist = artist.trim().ifEmpty { track.artist },
            album = album.trim().ifEmpty { track.album }
        )
        val updated = mutableEdits.value + (track.id to edit)
        mutableEdits.value = updated
        store.saveTrackEdits(updated)
        refresh()
    }

    fun resetTrackEdit(trackId: Long) {
        val updated = mutableEdits.value - trackId
        mutableEdits.value = updated
        store.saveTrackEdits(updated)
        val names = mutableLyricNames.value - trackId
        mutableLyricNames.value = names
        store.saveLyricNames(names)
        refresh()
    }

    fun deleteTracks(tracks: List<Track>) {
        if (tracks.isEmpty()) return
        pendingDelete = tracks
        deletedBuffer.clear()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val sender = runCatching {
                MediaStore.createDeleteRequest(context.contentResolver, tracks.map { it.uri }).intentSender
            }.getOrNull()
            if (sender == null) {
                pendingDelete = emptyList()
                toast("Couldn't delete")
            } else {
                mutableRequest.value = sender
            }
        } else {
            viewModelScope.launch { deleteLegacy() }
        }
    }

    private suspend fun deleteLegacy() {
        val remaining = pendingDelete.toMutableList()
        var failed = 0
        while (remaining.isNotEmpty()) {
            val track = remaining.first()
            val problem = withContext(Dispatchers.IO) {
                try {
                    if (context.contentResolver.delete(track.uri, null, null) > 0) null else SecurityException()
                } catch (error: SecurityException) {
                    error
                }
            }
            if (problem == null) {
                deletedBuffer += track
                remaining.removeAt(0)
                continue
            }
            val sender = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && problem is RecoverableSecurityException) {
                problem.userAction.actionIntent.intentSender
            } else {
                null
            }
            if (sender != null) {
                pendingDelete = remaining
                mutableRequest.value = sender
                return
            }
            failed++
            remaining.removeAt(0)
        }
        pendingDelete = emptyList()
        finishDelete(failed)
    }

    private fun finishDelete(failed: Int) {
        val done = deletedBuffer.toList()
        deletedBuffer.clear()
        if (done.isNotEmpty()) afterDeleted(done)
        if (failed > 0) toast("Couldn't delete $failed song(s)")
    }

    fun consumeSystemRequest() {
        mutableRequest.value = null
    }

    fun onSystemRequestHandled(granted: Boolean) {
        val tracks = pendingDelete
        if (tracks.isEmpty()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            pendingDelete = emptyList()
            if (granted) afterDeleted(tracks)
            return
        }
        if (granted) {
            viewModelScope.launch { deleteLegacy() }
        } else {
            pendingDelete = emptyList()
            finishDelete(0)
        }
    }

    private fun afterDeleted(tracks: List<Track>) {
        val ids = tracks.map { it.id }.toSet()
        controller?.let { c ->
            for (index in c.mediaItemCount - 1 downTo 0) {
                val id = c.getMediaItemAt(index).mediaId.toLongOrNull()
                if (id != null && id in ids) c.removeMediaItem(index)
            }
        }
        val favorites = mutableFavorites.value - ids
        mutableFavorites.value = favorites
        store.saveFavorites(favorites)
        updatePlaylists { list -> list.map { playlist -> playlist.copy(trackIds = playlist.trackIds.filterNot { it in ids }) } }
        val counts = mutablePlayCounts.value - ids
        mutablePlayCounts.value = counts
        store.savePlayCounts(counts)
        val edits = mutableEdits.value - ids
        mutableEdits.value = edits
        store.saveTrackEdits(edits)
        val names = mutableLyricNames.value - ids
        mutableLyricNames.value = names
        store.saveLyricNames(names)
        CoverStore.remove(ids)
        toast(if (tracks.size == 1) "Song deleted" else "${tracks.size} songs deleted")
        refresh()
    }

    fun startSleepTimer(minutes: Int) {
        SleepTimer.start(minutes)
    }

    fun cancelSleepTimer() {
        SleepTimer.cancel()
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val old = mutableSettings.value
        val updated = transform(old)
        mutableSettings.value = updated
        store.saveSettings(updated)
        if ((old.hideShort != updated.hideShort || old.hiddenFolders != updated.hiddenFolders) && hasAccess) refresh()
    }

    fun identifyTrack(track: Track) {
        identifyJob?.cancel()
        mutableIdentify.value = IdentifyState.Decoding
        identifyJob = viewModelScope.launch {
            val outcome = trackIdentifier.identify(track, mutableSettings.value.acoustidKey) { stage ->
                if (isActive) mutableIdentify.value = stage
            }
            mutableIdentify.value = outcome
        }
    }

    fun resetIdentify() {
        identifyJob?.cancel()
        mutableIdentify.value = IdentifyState.Idle
    }

    fun applyIdentified(track: Track, match: IdentifyMatch) {
        saveTrackEdit(track, match.title, match.artist, match.album)
        toast("Song info updated")
    }

    fun identifyUnknown() {
        if (batchJob?.isActive == true) return
        val edited = mutableEdits.value
        val targets = mutableLibrary.value.tracks.filter { it.id !in edited && isUnidentified(it) }
        if (targets.isEmpty()) {
            mutableBatch.value = BatchIdentify(finished = true)
            return
        }
        mutableBatch.value = BatchIdentify(running = true, total = targets.size)
        batchJob = viewModelScope.launch {
            val found = HashMap<Long, TrackEdit>()
            var done = 0
            var failures = 0
            var needsKey = false
            var offline = false
            try {
                for (track in targets) {
                    val outcome = trackIdentifier.identify(track, mutableSettings.value.acoustidKey) { }
                    if (outcome is IdentifyState.NoKey) {
                        needsKey = true
                        break
                    }
                    if (outcome is IdentifyState.Failed) {
                        failures++
                        if (failures >= BATCH_MAX_FAILURES) {
                            offline = true
                            break
                        }
                    } else {
                        failures = 0
                    }
                    if (outcome is IdentifyState.Found) {
                        val best = outcome.matches.first()
                        if (best.score >= BATCH_MIN_SCORE) {
                            found[track.id] = TrackEdit(best.title, best.artist, best.album.ifEmpty { track.album })
                        }
                    }
                    done++
                    mutableBatch.value = BatchIdentify(running = true, total = targets.size, done = done, applied = found.size)
                    delay(BATCH_GAP_MS)
                }
            } finally {
                if (found.isNotEmpty()) {
                    val updated = mutableEdits.value + found
                    mutableEdits.value = updated
                    store.saveTrackEdits(updated)
                    refresh()
                }
                mutableBatch.value = BatchIdentify(
                    total = targets.size,
                    done = done,
                    applied = found.size,
                    finished = true,
                    needsKey = needsKey,
                    offline = offline
                )
            }
        }
    }

    fun cancelBatch() {
        batchJob?.cancel()
    }

    fun resetBatch() {
        if (batchJob?.isActive == true) return
        mutableBatch.value = BatchIdentify()
    }

    fun coverQuery(track: Track): String = coverFinder.defaultQuery(track)

    fun searchCovers(query: String) {
        coverSearchJob?.cancel()
        if (query.isBlank()) {
            mutableCoverSearch.value = CoverSearchState.Idle
            return
        }
        mutableCoverSearch.value = CoverSearchState.Searching
        coverSearchJob = viewModelScope.launch {
            mutableCoverSearch.value = try {
                val items = coverFinder.search(query)
                if (items.isEmpty()) CoverSearchState.Empty else CoverSearchState.Results(items)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                CoverSearchState.Failed
            }
        }
    }

    fun resetCoverSearch() {
        coverSearchJob?.cancel()
        mutableCoverSearch.value = CoverSearchState.Idle
    }

    suspend fun applyCover(track: Track, option: CoverOption, wholeAlbum: Boolean): Boolean {
        val bytes = coverFinder.fetch(option.fullUrl)
        if (bytes == null) {
            toast("Couldn't download this cover")
            return false
        }
        saveCover(coverTargets(track, wholeAlbum), bytes)
        toast("Cover updated")
        return true
    }

    suspend fun applyCoverImage(track: Track, uri: Uri, wholeAlbum: Boolean): Boolean {
        val bytes = withContext(Dispatchers.IO) { runCatching { readCoverImage(uri) }.getOrNull() }
        if (bytes == null) {
            toast("Couldn't read this image")
            return false
        }
        saveCover(coverTargets(track, wholeAlbum), bytes)
        toast("Cover updated")
        return true
    }

    fun removeCover(track: Track, wholeAlbum: Boolean) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { coverTargets(track, wholeAlbum).forEach { CoverStore.clear(it.id) } }
            toast("Cover removed")
        }
    }

    fun recheckCovers() {
        val current = mutableSettings.value
        if (!current.onlineCovers || !current.onlineAsked) {
            toast("Turn on \"Find cover art online\" first")
            return
        }
        viewModelScope.launch {
            withContext(Dispatchers.IO) { CoverStore.clearChecked() }
            toast("Searching for missing covers")
            val ids = mutableLibrary.value.tracks.map { it.id }.sortedDescending()
            toast(if (coverPass(ids)) "Cover check finished" else "Couldn't finish. Check your connection")
        }
    }

    private fun coverTargets(track: Track, wholeAlbum: Boolean): List<Track> {
        if (!wholeAlbum || track.albumId <= 0) return listOf(track)
        return mutableLibrary.value.tracks
            .filter { it.albumId == track.albumId && it.album == track.album }
            .ifEmpty { listOf(track) }
    }

    private suspend fun saveCover(tracks: List<Track>, bytes: ByteArray) {
        withContext(Dispatchers.IO) { tracks.forEach { CoverStore.save(it.id, bytes, custom = true) } }
    }

    private fun readCoverImage(uri: Uri): ByteArray? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= COVER_MAX_SIDE && bounds.outHeight / (sample * 2) >= COVER_MAX_SIDE) {
            sample *= 2
        }
        val bitmap = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null
        val output = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 92, output)
        bitmap.recycle()
        return output.toByteArray()
    }

    fun exportBackup(uri: Uri) {
        val data = BackupData(
            favorites = mutableFavorites.value,
            playlists = mutablePlaylists.value,
            playCounts = mutablePlayCounts.value,
            edits = mutableEdits.value,
            lyricNames = mutableLyricNames.value,
            settings = mutableSettings.value
        )
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openOutputStream(uri, "wt")
                        ?.use { it.write(BackupCodec.encode(data).toByteArray(Charsets.UTF_8)) } != null
                }.getOrDefault(false)
            }
            toast(if (saved) "Backup saved" else "Couldn't save the backup")
        }
    }

    fun importBackup(uri: Uri) {
        viewModelScope.launch {
            val data = withContext(Dispatchers.IO) {
                runCatching { context.contentResolver.openInputStream(uri)?.use { BackupCodec.read(it) } }
                    .getOrNull()
                    ?.let { BackupCodec.decode(it) }
            }
            if (data == null) {
                toast("This isn't a valid Sonora backup")
                return@launch
            }
            applyBackup(data)
            toast("Backup restored")
        }
    }

    private fun applyBackup(data: BackupData) {
        val settings = data.settings.copy(
            onlineAsked = mutableSettings.value.onlineAsked,
            onboarded = mutableSettings.value.onboarded,
            acoustidKey = mutableSettings.value.acoustidKey
        )
        store.markIdsMigrated()
        mutableFavorites.value = data.favorites
        mutablePlaylists.value = data.playlists
        mutablePlayCounts.value = data.playCounts
        mutableEdits.value = data.edits
        mutableLyricNames.value = data.lyricNames
        mutableSettings.value = settings
        store.saveFavorites(data.favorites)
        store.savePlaylists(data.playlists)
        store.savePlayCounts(data.playCounts)
        store.saveTrackEdits(data.edits)
        store.saveLyricNames(data.lyricNames)
        store.saveSettings(settings)
        if (hasAccess) refresh()
    }

    fun open(route: Route) {
        mutableRoutes.value = mutableRoutes.value + route
    }

    fun back() {
        val current = mutableRoutes.value
        if (current.isNotEmpty()) mutableRoutes.value = current.dropLast(1)
    }

    fun clearRoutes() {
        mutableRoutes.value = emptyList()
    }

    val party: StateFlow<PartyUi> get() = partySession.state

    fun startParty() {
        viewModelScope.launch(Dispatchers.IO) { partySession.start() }
    }

    fun stopParty() {
        viewModelScope.launch(Dispatchers.IO) { partySession.stop() }
    }

    override fun onCleared() {
        if (partyDelegate.isInitialized()) partySession.stop()
        saveSession()
        network.stop()
        context.contentResolver.unregisterContentObserver(observer)
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
