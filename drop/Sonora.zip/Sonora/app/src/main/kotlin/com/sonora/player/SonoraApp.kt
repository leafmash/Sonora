package com.sonora.player

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.key.Keyer
import coil.memory.MemoryCache
import com.sonora.player.data.ArtFetcher
import com.sonora.player.data.ArtModel
import com.sonora.player.data.CoverStore
import com.sonora.player.playback.EqualizerManager

class SonoraApp : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        CrashReporter.install(this)
        EqualizerManager.init(this)
        CoverStore.init(this)
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components {
                add(Keyer<ArtModel> { data, _ -> "${data.uri}#${data.albumId}#${data.cover}" })
                add(ArtFetcher.Factory())
            }
            .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.2).build() }
            .crossfade(true)
            .build()
}
