package com.sonora.player.data

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.min

class DecodedAudio(val samples: ShortArray, val length: Int, val sampleRate: Int)

object AudioDecoder {

    private const val TIMEOUT_US = 10_000L
    private const val DEADLINE_MS = 60_000L

    fun decodeMono(context: Context, uri: Uri, maxSeconds: Int): DecodedAudio? {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            var trackIndex = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                if (format.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    trackIndex = i
                    inputFormat = format
                    break
                }
            }
            if (trackIndex < 0 || inputFormat == null) return null
            extractor.selectTrack(trackIndex)

            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: return null
            val decoder = MediaCodec.createDecoderByType(mime)
            codec = decoder
            decoder.configure(inputFormat, null, null, 0)
            decoder.start()

            var sampleRate = inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var encoding = AudioFormat.ENCODING_PCM_16BIT

            var buffer = ShortArray(sampleRate * maxSeconds)
            var written = 0
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val deadline = System.currentTimeMillis() + DEADLINE_MS

            while (!outputDone && System.currentTimeMillis() < deadline) {
                if (!inputDone) {
                    val inputIndex = decoder.dequeueInputBuffer(TIMEOUT_US)
                    if (inputIndex >= 0) {
                        val input = decoder.getInputBuffer(inputIndex)
                        val size = if (input != null) extractor.readSampleData(input, 0) else -1
                        if (size < 0) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outputIndex = decoder.dequeueOutputBuffer(info, TIMEOUT_US)
                when {
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val format = decoder.outputFormat
                        sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        encoding = if (format.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                            format.getInteger(MediaFormat.KEY_PCM_ENCODING)
                        } else {
                            AudioFormat.ENCODING_PCM_16BIT
                        }
                        val needed = sampleRate * maxSeconds
                        if (buffer.size < needed) buffer = buffer.copyOf(needed)
                    }
                    outputIndex >= 0 -> {
                        val output = decoder.getOutputBuffer(outputIndex)
                        if (output != null && info.size > 0 && channels > 0) {
                            output.position(info.offset)
                            output.limit(info.offset + info.size)
                            written = appendMono(output, encoding, channels, buffer, written)
                        }
                        decoder.releaseOutputBuffer(outputIndex, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                        if (written >= sampleRate * maxSeconds) outputDone = true
                    }
                }
            }

            return if (written > 0) DecodedAudio(buffer, min(written, buffer.size), sampleRate) else null
        } catch (e: Exception) {
            return null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    private fun appendMono(
        source: java.nio.ByteBuffer,
        encoding: Int,
        channels: Int,
        target: ShortArray,
        start: Int
    ): Int {
        source.order(ByteOrder.nativeOrder())
        var index = start
        if (encoding == AudioFormat.ENCODING_PCM_FLOAT) {
            val floats = source.asFloatBuffer()
            while (floats.remaining() >= channels && index < target.size) {
                var sum = 0f
                for (c in 0 until channels) sum += floats.get()
                val value = (sum / channels * 32767f).coerceIn(-32768f, 32767f)
                target[index++] = value.toInt().toShort()
            }
        } else {
            val shorts = source.asShortBuffer()
            while (shorts.remaining() >= channels && index < target.size) {
                var sum = 0
                for (c in 0 until channels) sum += shorts.get()
                target[index++] = (sum / channels).toShort()
            }
        }
        return index
    }
}
