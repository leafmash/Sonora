package com.sonora.player.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BackupData(
    val favorites: Set<Long>,
    val playlists: List<Playlist>,
    val playCounts: Map<Long, Int>,
    val edits: Map<Long, TrackEdit>,
    val lyricNames: Map<Long, LyricsName>,
    val settings: AppSettings
)

object BackupCodec {

    private const val APP = "sonora"
    private const val VERSION = 1
    private const val MAX_BYTES = 16 * 1024 * 1024

    fun fileName(): String =
        "sonora-backup-${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())}.json"

    fun read(input: InputStream): String? {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            if (total > MAX_BYTES) return null
            out.write(buffer, 0, count)
        }
        return out.toString(Charsets.UTF_8.name())
    }

    fun encode(data: BackupData): String {
        val settings = data.settings
        val playlists = JSONArray()
        data.playlists.forEach { playlist ->
            playlists.put(
                JSONObject()
                    .put("id", playlist.id)
                    .put("name", playlist.name)
                    .put("tracks", JSONArray(playlist.trackIds))
            )
        }
        val playCounts = JSONObject()
        data.playCounts.forEach { (id, count) -> playCounts.put(id.toString(), count) }
        val edits = JSONObject()
        data.edits.forEach { (id, edit) ->
            edits.put(
                id.toString(),
                JSONObject().put("title", edit.title).put("artist", edit.artist).put("album", edit.album)
            )
        }
        val names = JSONObject()
        data.lyricNames.forEach { (id, name) ->
            names.put(
                id.toString(),
                JSONObject().put("title", name.title).put("artist", name.artist).put("album", name.album)
            )
        }
        return JSONObject()
            .put("app", APP)
            .put("version", VERSION)
            .put("exportedAt", System.currentTimeMillis())
            .put("favorites", JSONArray(data.favorites.toList()))
            .put("playlists", playlists)
            .put("playCounts", playCounts)
            .put("edits", edits)
            .put("lyricNames", names)
            .put(
                "settings",
                JSONObject()
                    .put("theme", settings.themeMode.name)
                    .put("dynamicColor", settings.dynamicColor)
                    .put("hideShort", settings.hideShort)
                    .put("sort", settings.sort.name)
                    .put("onlineLyrics", settings.onlineLyrics)
                    .put("onlineCovers", settings.onlineCovers)
                    .put("lyricsMode", settings.lyricsMode)
                    .put("lyricsScale", settings.lyricsScale.toDouble())
                    .put("skipSilence", settings.skipSilence)
                    .put("normalizeVolume", settings.normalizeVolume)
                    .put("notificationLyrics", settings.notificationLyrics)
                    .put("skipSeconds", sanitizeSkipSeconds(settings.skipSeconds))
                    .put("showSkipButtons", settings.showSkipButtons)
            )
            .toString(2)
    }

    fun decode(raw: String): BackupData? = runCatching {
        val root = JSONObject(raw)
        require(root.optString("app") == APP)
        require(root.optInt("version", 0) in 1..VERSION)
        BackupData(
            favorites = root.optJSONArray("favorites").longs().toSet(),
            playlists = root.optJSONArray("playlists")?.let { array ->
                (0 until array.length()).map { index ->
                    val item = array.getJSONObject(index)
                    Playlist(
                        id = item.getLong("id"),
                        name = item.getString("name"),
                        trackIds = item.optJSONArray("tracks").longs().distinct()
                    )
                }
            }.orEmpty(),
            playCounts = root.optJSONObject("playCounts")?.let { obj ->
                obj.keys().asSequence().mapNotNull { key ->
                    key.toLongOrNull()?.let { it to obj.getInt(key) }
                }.toMap()
            }.orEmpty(),
            edits = root.optJSONObject("edits")?.let { obj ->
                obj.keys().asSequence().mapNotNull { key ->
                    val id = key.toLongOrNull() ?: return@mapNotNull null
                    val item = obj.getJSONObject(key)
                    id to TrackEdit(item.getString("title"), item.getString("artist"), item.getString("album"))
                }.toMap()
            }.orEmpty(),
            lyricNames = root.optJSONObject("lyricNames")?.let { obj ->
                obj.keys().asSequence().mapNotNull { key ->
                    val id = key.toLongOrNull() ?: return@mapNotNull null
                    val item = obj.getJSONObject(key)
                    id to LyricsName(item.getString("title"), item.getString("artist"), item.optString("album"))
                }.toMap()
            }.orEmpty(),
            settings = decodeSettings(root.optJSONObject("settings"))
        )
    }.getOrNull()

    private fun decodeSettings(item: JSONObject?): AppSettings {
        val defaults = AppSettings()
        if (item == null) return defaults
        return AppSettings(
            themeMode = runCatching { ThemeMode.valueOf(item.optString("theme")) }.getOrDefault(defaults.themeMode),
            dynamicColor = item.optBoolean("dynamicColor", defaults.dynamicColor),
            hideShort = item.optBoolean("hideShort", defaults.hideShort),
            sort = runCatching { SortOrder.valueOf(item.optString("sort")) }.getOrDefault(defaults.sort),
            onlineLyrics = item.optBoolean("onlineLyrics", defaults.onlineLyrics),
            onlineCovers = item.optBoolean("onlineCovers", defaults.onlineCovers),
            lyricsMode = item.optBoolean("lyricsMode", defaults.lyricsMode),
            lyricsScale = item.optDouble("lyricsScale", defaults.lyricsScale.toDouble()).toFloat(),
            skipSilence = item.optBoolean("skipSilence", defaults.skipSilence),
            normalizeVolume = item.optBoolean("normalizeVolume", defaults.normalizeVolume),
            notificationLyrics = item.optBoolean("notificationLyrics", defaults.notificationLyrics),
            skipSeconds = sanitizeSkipSeconds(item.optInt("skipSeconds", defaults.skipSeconds)),
            showSkipButtons = item.optBoolean("showSkipButtons", defaults.showSkipButtons)
        )
    }

    private fun JSONArray?.longs(): List<Long> =
        if (this == null) emptyList() else (0 until length()).map { getLong(it) }
}
