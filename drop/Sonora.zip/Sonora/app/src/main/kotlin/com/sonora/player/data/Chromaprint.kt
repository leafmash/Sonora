package com.sonora.player.data

import java.util.Base64
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

object Chromaprint {

    const val SAMPLE_RATE = 11025
    const val ALGORITHM = 1

    private const val FRAME_SIZE = 4096
    private const val HOP = FRAME_SIZE / 3
    private const val BANDS = 12
    private const val MIN_FREQ = 28
    private const val MAX_FREQ = 3520
    private const val NORMALIZE_THRESHOLD = 0.01
    private const val NORMAL_BITS_MAX = 7

    private val FILTER_COEFFICIENTS = doubleArrayOf(0.25, 0.75, 1.0, 0.75, 0.25)
    private val GRAY_CODE = intArrayOf(0, 1, 3, 2)

    private class Classifier(
        val type: Int,
        val y: Int,
        val height: Int,
        val width: Int,
        val t0: Double,
        val t1: Double,
        val t2: Double
    )

    private val CLASSIFIERS = arrayOf(
        Classifier(0, 4, 3, 15, 1.98215, 2.35817, 2.63523),
        Classifier(4, 4, 6, 15, -1.03809, -0.651211, -0.282167),
        Classifier(1, 0, 4, 16, -0.298702, 0.119262, 0.558497),
        Classifier(3, 8, 2, 12, -0.105439, 0.0153946, 0.135898),
        Classifier(3, 4, 4, 8, -0.142891, 0.0258736, 0.200632),
        Classifier(4, 0, 3, 5, -0.826319, -0.590612, -0.368214),
        Classifier(1, 2, 2, 9, -0.557409, -0.233035, 0.0534525),
        Classifier(2, 7, 3, 4, -0.0646826, 0.00620476, 0.0784847),
        Classifier(2, 6, 2, 16, -0.192387, -0.029699, 0.215855),
        Classifier(2, 1, 3, 2, -0.0397818, -0.00568076, 0.0292026),
        Classifier(5, 10, 1, 15, -0.53823, -0.369934, -0.190235),
        Classifier(3, 6, 2, 10, -0.124877, 0.0296483, 0.139239),
        Classifier(2, 1, 1, 14, -0.101475, 0.0225617, 0.231971),
        Classifier(3, 5, 6, 4, -0.0799915, -0.00729616, 0.063262),
        Classifier(1, 9, 2, 12, -0.272556, 0.019424, 0.302559),
        Classifier(3, 4, 2, 14, -0.164292, -0.0321188, 0.0846339)
    )

    private val MAX_FILTER_WIDTH = CLASSIFIERS.maxOf { it.width }

    fun fingerprint(samples: ShortArray, length: Int = samples.size): IntArray {
        val count = min(length, samples.size)
        if (count < FRAME_SIZE) return IntArray(0)

        val window = DoubleArray(FRAME_SIZE) { i ->
            (0.54 - 0.46 * cos(i * 2.0 * PI / (FRAME_SIZE - 1))) / Short.MAX_VALUE
        }
        val fft = Fft(FRAME_SIZE)
        val real = DoubleArray(FRAME_SIZE)
        val imag = DoubleArray(FRAME_SIZE)

        val minIndex = max(1, freqToIndex(MIN_FREQ.toDouble()))
        val maxIndex = min(FRAME_SIZE / 2, freqToIndex(MAX_FREQ.toDouble()))
        val notes = IntArray(FRAME_SIZE)
        for (i in minIndex until maxIndex) {
            val freq = i.toDouble() * SAMPLE_RATE / FRAME_SIZE
            val octave = ln(freq / (440.0 / 16.0)) / ln(2.0)
            notes[i] = (BANDS * (octave - floor(octave))).toInt()
        }

        val filterLength = FILTER_COEFFICIENTS.size
        val recent = ArrayList<DoubleArray>()
        val integral = ArrayList<DoubleArray>()
        val result = ArrayList<Int>()

        var start = 0
        while (start + FRAME_SIZE <= count) {
            for (i in 0 until FRAME_SIZE) {
                real[i] = samples[start + i] * window[i]
                imag[i] = 0.0
            }
            fft.transform(real, imag)

            val features = DoubleArray(BANDS)
            for (i in minIndex until maxIndex) {
                features[notes[i]] += real[i] * real[i] + imag[i] * imag[i]
            }

            recent.add(features)
            if (recent.size >= filterLength) {
                val base = recent.size - filterLength
                val filtered = DoubleArray(BANDS)
                for (band in 0 until BANDS) {
                    var sum = 0.0
                    for (j in 0 until filterLength) {
                        sum += recent[base + j][band] * FILTER_COEFFICIENTS[j]
                    }
                    filtered[band] = sum
                }
                recent.removeAt(0)

                var squares = 0.0
                for (value in filtered) squares += value * value
                val norm = if (squares > 0) sqrt(squares) else 0.0
                if (norm < NORMALIZE_THRESHOLD) {
                    filtered.fill(0.0)
                } else {
                    for (band in 0 until BANDS) filtered[band] /= norm
                }

                val row = DoubleArray(BANDS)
                var running = 0.0
                for (band in 0 until BANDS) {
                    running += filtered[band]
                    row[band] = running + if (integral.isNotEmpty()) integral[integral.size - 1][band] else 0.0
                }
                integral.add(row)

                if (integral.size >= MAX_FILTER_WIDTH) {
                    result.add(subfingerprint(integral, integral.size - MAX_FILTER_WIDTH))
                }
            }
            start += HOP
        }
        return result.toIntArray()
    }

    fun encode(fingerprint: IntArray): String {
        val normal = ArrayList<Int>()
        val exceptional = ArrayList<Int>()

        fun process(value: Int) {
            var x = value
            var bit = 1
            var lastBit = 0
            while (x != 0) {
                if ((x and 1) != 0) {
                    val delta = bit - lastBit
                    if (delta >= NORMAL_BITS_MAX) {
                        normal.add(NORMAL_BITS_MAX)
                        exceptional.add(delta - NORMAL_BITS_MAX)
                    } else {
                        normal.add(delta)
                    }
                    lastBit = bit
                }
                x = x ushr 1
                bit++
            }
            normal.add(0)
        }

        if (fingerprint.isNotEmpty()) {
            process(fingerprint[0])
            for (i in 1 until fingerprint.size) process(fingerprint[i] xor fingerprint[i - 1])
        }

        val normalBytes = pack(normal, 3)
        val exceptionalBytes = pack(exceptional, 5)
        val out = ByteArray(4 + normalBytes.size + exceptionalBytes.size)
        out[0] = (ALGORITHM and 255).toByte()
        out[1] = ((fingerprint.size shr 16) and 255).toByte()
        out[2] = ((fingerprint.size shr 8) and 255).toByte()
        out[3] = (fingerprint.size and 255).toByte()
        System.arraycopy(normalBytes, 0, out, 4, normalBytes.size)
        System.arraycopy(exceptionalBytes, 0, out, 4 + normalBytes.size, exceptionalBytes.size)
        return Base64.getUrlEncoder().withoutPadding().encodeToString(out)
    }

    private fun pack(values: List<Int>, bits: Int): ByteArray {
        val out = ByteArray((values.size * bits + 7) / 8)
        val mask = (1 shl bits) - 1
        var bitPosition = 0
        for (value in values) {
            val v = value and mask
            val byteIndex = bitPosition shr 3
            val shift = bitPosition and 7
            out[byteIndex] = (out[byteIndex].toInt() or ((v shl shift) and 0xFF)).toByte()
            if (shift + bits > 8) {
                out[byteIndex + 1] = (out[byteIndex + 1].toInt() or (v shr (8 - shift))).toByte()
            }
            bitPosition += bits
        }
        return out
    }

    private fun freqToIndex(freq: Double): Int = floor(FRAME_SIZE * freq / SAMPLE_RATE + 0.5).toInt()

    private fun subfingerprint(integral: List<DoubleArray>, offset: Int): Int {
        var bits = 0
        for (classifier in CLASSIFIERS) {
            val value = applyFilter(integral, classifier, offset)
            val level = when {
                value < classifier.t1 -> if (value < classifier.t0) 0 else 1
                else -> if (value < classifier.t2) 2 else 3
            }
            bits = (bits shl 2) or GRAY_CODE[level]
        }
        return bits
    }

    private fun area(integral: List<DoubleArray>, r1: Int, c1: Int, r2: Int, c2: Int): Double {
        if (r1 == r2 || c1 == c2) return 0.0
        return if (r1 == 0) {
            val row = integral[r2 - 1]
            if (c1 == 0) row[c2 - 1] else row[c2 - 1] - row[c1 - 1]
        } else {
            val row1 = integral[r1 - 1]
            val row2 = integral[r2 - 1]
            if (c1 == 0) {
                row2[c2 - 1] - row1[c2 - 1]
            } else {
                row2[c2 - 1] - row1[c2 - 1] - row2[c1 - 1] + row1[c1 - 1]
            }
        }
    }

    private fun subtractLog(a: Double, b: Double): Double = ln((1.0 + a) / (1.0 + b))

    private fun applyFilter(integral: List<DoubleArray>, f: Classifier, x: Int): Double {
        val y = f.y
        val w = f.width
        val h = f.height
        return when (f.type) {
            0 -> subtractLog(area(integral, x, y, x + w, y + h), 0.0)
            1 -> {
                val half = h / 2
                subtractLog(
                    area(integral, x, y + half, x + w, y + h),
                    area(integral, x, y, x + w, y + half)
                )
            }
            2 -> {
                val half = w / 2
                subtractLog(
                    area(integral, x + half, y, x + w, y + h),
                    area(integral, x, y, x + half, y + h)
                )
            }
            3 -> {
                val halfW = w / 2
                val halfH = h / 2
                val a = area(integral, x, y + halfH, x + halfW, y + h) +
                    area(integral, x + halfW, y, x + w, y + halfH)
                val b = area(integral, x, y, x + halfW, y + halfH) +
                    area(integral, x + halfW, y + halfH, x + w, y + h)
                subtractLog(a, b)
            }
            4 -> {
                val third = h / 3
                val a = area(integral, x, y + third, x + w, y + 2 * third)
                val b = area(integral, x, y, x + w, y + third) +
                    area(integral, x, y + 2 * third, x + w, y + h)
                subtractLog(a, b)
            }
            5 -> {
                val third = w / 3
                val a = area(integral, x + third, y, x + 2 * third, y + h)
                val b = area(integral, x, y, x + third, y + h) +
                    area(integral, x + 2 * third, y, x + w, y + h)
                subtractLog(a, b)
            }
            else -> 0.0
        }
    }

    private class Fft(private val size: Int) {
        private val cosTable = DoubleArray(size / 2) { cos(2.0 * PI * it / size) }
        private val sinTable = DoubleArray(size / 2) { -sin(2.0 * PI * it / size) }
        private val reversed = IntArray(size)

        init {
            val bits = Integer.numberOfTrailingZeros(size)
            for (i in 0 until size) reversed[i] = Integer.reverse(i) ushr (32 - bits)
        }

        fun transform(real: DoubleArray, imag: DoubleArray) {
            for (i in 0 until size) {
                val j = reversed[i]
                if (j > i) {
                    val tr = real[i]
                    real[i] = real[j]
                    real[j] = tr
                    val ti = imag[i]
                    imag[i] = imag[j]
                    imag[j] = ti
                }
            }
            var span = 2
            while (span <= size) {
                val half = span / 2
                val step = size / span
                var block = 0
                while (block < size) {
                    var k = 0
                    for (j in block until block + half) {
                        val wr = cosTable[k]
                        val wi = sinTable[k]
                        val xr = real[j + half] * wr - imag[j + half] * wi
                        val xi = real[j + half] * wi + imag[j + half] * wr
                        real[j + half] = real[j] - xr
                        imag[j + half] = imag[j] - xi
                        real[j] += xr
                        imag[j] += xi
                        k += step
                    }
                    block += span
                }
                span = span shl 1
            }
        }
    }
}
