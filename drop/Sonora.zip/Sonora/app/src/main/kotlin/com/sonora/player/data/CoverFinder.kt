package com.sonora.player.data

import android.content.Context
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

class CoverFinder(private val context: Context) {

    private data class Candidate(
        val title: String,
        val artist: String,
        val durationSec: Double?,
        val url: String
    )

    suspend fun ensure(track: Track): Unit = withContext(Dispatchers.IO) {
        if (!CoverStore.needsLookup(track.id)) return@withContext
        val model = ArtModel(track.uri, track.albumId)
        if (ArtFetcher.hasLocalArt(context, model)) {
            CoverStore.markChecked(track.id, localArt = true)
            return@withContext
        }
        val bytes = find(track)
        if (bytes != null) CoverStore.save(track.id, bytes) else CoverStore.markChecked(track.id)
    }

    fun defaultQuery(track: Track): String {
        val main = TrackNameCleaner.variants(track).firstOrNull() ?: return track.title
        return TrackNameCleaner.freeText(main).ifBlank { main.title }
    }

    suspend fun search(query: String): List<CoverOption> = withContext(Dispatchers.IO) {
        val term = query.trim()
        if (term.isEmpty()) return@withContext emptyList()
        val outcomes = listOf(this@CoverFinder::itunesOptions, this@CoverFinder::deezerOptions).map { source -> runCatching { source(term) } }
        if (outcomes.all { it.isFailure }) throw IOException("Cover search failed")
        val lists = outcomes.map { it.getOrNull().orEmpty() }
        val longest = lists.maxOf { it.size }
        (0 until longest)
            .flatMap { index -> lists.mapNotNull { it.getOrNull(index) } }
            .distinctBy { it.fullUrl }
            .take(MAX_OPTIONS)
    }

    suspend fun fetch(url: String): ByteArray? = withContext(Dispatchers.IO) {
        runCatching { download(url) }.getOrNull()
    }

    private fun itunesOptions(term: String): List<CoverOption> {
        val body = get("https://itunes.apple.com/search?media=music&entity=song&limit=25&term=${enc(term)}") ?: return emptyList()
        val results = JSONObject(body).optJSONArray("results") ?: return emptyList()
        return (0 until results.length()).mapNotNull { index ->
            val item = results.getJSONObject(index)
            val art = item.optString("artworkUrl100")
            if (art.isEmpty()) {
                null
            } else {
                CoverOption(
                    title = item.optString("trackName"),
                    artist = item.optString("artistName"),
                    previewUrl = art.replace("100x100bb", "300x300bb"),
                    fullUrl = art.replace("100x100bb", "1000x1000bb")
                )
            }
        }
    }

    private fun deezerOptions(term: String): List<CoverOption> {
        val body = get("https://api.deezer.com/search?limit=25&q=${enc(term)}") ?: return emptyList()
        val data = JSONObject(body).optJSONArray("data") ?: return emptyList()
        return (0 until data.length()).mapNotNull { index ->
            val item = data.getJSONObject(index)
            val album = item.optJSONObject("album")
            val full = album?.optString("cover_xl").orEmpty()
            if (full.isEmpty()) {
                null
            } else {
                CoverOption(
                    title = item.optString("title"),
                    artist = item.optJSONObject("artist")?.optString("name").orEmpty(),
                    previewUrl = album?.optString("cover_medium").orEmpty().ifEmpty { full },
                    fullUrl = full
                )
            }
        }
    }

    private fun find(track: Track): ByteArray? {
        val variants = TrackNameCleaner.variants(track)
        val main = variants.firstOrNull() ?: return null
        val titles = variants.map { it.title }.filter { it.isNotEmpty() }
        val artists = buildList {
            if (!TrackNameCleaner.isUnknown(track.artist)) add(track.artist)
            variants.mapNotNullTo(this) { it.artist }
        }.distinct()
        val seconds = track.durationMs / 1000.0

        val terms = listOf(TrackNameCleaner.freeText(main), main.title).filter { it.isNotBlank() }.distinct()
        for (term in terms) {
            for (source in listOf(::itunes, ::deezer)) {
                val best = source(term)
                    .map { it to score(it, seconds, titles, artists) }
                    .filter { it.second >= ACCEPT_SCORE }
                    .maxByOrNull { it.second }
                    ?.first
                if (best != null) {
                    download(best.url)?.let { return it }
                }
            }
        }
        return null
    }

    private fun score(candidate: Candidate, seconds: Double, titles: List<String>, artists: List<String>): Double {
        val name = TrackNameCleaner.candidateTitle(candidate.title)
        val titleSimilarity = titles.maxOfOrNull { TrackNameCleaner.similarity(name, it) } ?: 0.0
        if (titleSimilarity < MIN_TITLE_SIMILARITY) return 0.0
        val artistSimilarity = if (artists.isEmpty()) 0.5 else TrackNameCleaner.artistSimilarity(candidate.artist, artists)
        val durationScore = candidate.durationSec?.let {
            val gap = abs(it - seconds)
            if (gap > MAX_DURATION_GAP) 0.0 else 1.0 - gap / MAX_DURATION_GAP
        } ?: 0.5
        return 0.6 * titleSimilarity + 0.25 * artistSimilarity + 0.15 * durationScore
    }

    private fun itunes(term: String): List<Candidate> {
        val body = get("https://itunes.apple.com/search?media=music&entity=song&limit=15&term=${enc(term)}") ?: return emptyList()
        val results = JSONObject(body).optJSONArray("results") ?: return emptyList()
        return (0 until results.length()).mapNotNull { index ->
            val item = results.getJSONObject(index)
            val art = item.optString("artworkUrl100")
            if (art.isEmpty()) {
                null
            } else {
                Candidate(
                    title = item.optString("trackName"),
                    artist = item.optString("artistName"),
                    durationSec = item.optDouble("trackTimeMillis", -1.0).takeIf { it > 0 }?.div(1000.0),
                    url = art.replace("100x100bb", "600x600bb")
                )
            }
        }
    }

    private fun deezer(term: String): List<Candidate> {
        val body = get("https://api.deezer.com/search?limit=15&q=${enc(term)}") ?: return emptyList()
        val data = JSONObject(body).optJSONArray("data") ?: return emptyList()
        return (0 until data.length()).mapNotNull { index ->
            val item = data.getJSONObject(index)
            val art = item.optJSONObject("album")?.optString("cover_xl").orEmpty()
            if (art.isEmpty()) {
                null
            } else {
                Candidate(
                    title = item.optString("title"),
                    artist = item.optJSONObject("artist")?.optString("name").orEmpty(),
                    durationSec = item.optDouble("duration", -1.0).takeIf { it > 0 },
                    url = art
                )
            }
        }
    }

    private fun download(url: String): ByteArray? {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 8000
            connection.readTimeout = 15000
            connection.setRequestProperty("User-Agent", USER_AGENT)
            if (connection.responseCode !in 200..299) return null
            val bytes = connection.inputStream.use { it.readBytes() }
            if (bytes.isEmpty() || bytes.size > MAX_BYTES) return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            return if (bounds.outWidth > 0 && bounds.outHeight > 0) bytes else null
        } catch (e: IOException) {
            return null
        } finally {
            connection.disconnect()
        }
    }

    private fun get(url: String): String? {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 8000
            connection.readTimeout = 10000
            connection.setRequestProperty("User-Agent", USER_AGENT)
            val code = connection.responseCode
            if (code == 404) return null
            if (code !in 200..299) throw IOException("HTTP $code")
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private companion object {
        const val USER_AGENT = "Sonora/1.0 (Android music player)"
        const val MIN_TITLE_SIMILARITY = 0.6
        const val ACCEPT_SCORE = 0.6
        const val MAX_DURATION_GAP = 30.0
        const val MAX_BYTES = 6 * 1024 * 1024
        const val MAX_OPTIONS = 30
    }
}
