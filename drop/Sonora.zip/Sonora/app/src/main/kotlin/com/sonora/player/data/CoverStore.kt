package com.sonora.player.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

object CoverStore {

    private const val SKIP_TTL_MS = 7L * 24 * 60 * 60 * 1000

    private lateinit var dir: File
    private val mutableStamps = MutableStateFlow<Map<Long, Long>>(emptyMap())

    val stamps: StateFlow<Map<Long, Long>> = mutableStamps.asStateFlow()

    fun init(context: Context) {
        dir = File(context.filesDir, "covers").apply { mkdirs() }
        mutableStamps.value = dir.listFiles().orEmpty()
            .filter { it.extension == "jpg" }
            .mapNotNull { file -> file.nameWithoutExtension.toLongOrNull()?.let { it to file.lastModified() } }
            .toMap()
    }

    fun file(id: Long): File? {
        if (!::dir.isInitialized) return null
        return File(dir, "$id.jpg").takeIf { it.exists() }
    }

    fun needsLookup(id: Long): Boolean {
        if (File(dir, "$id.jpg").exists()) return false
        val skip = File(dir, "$id.skip")
        return !(skip.exists() && System.currentTimeMillis() - skip.lastModified() < SKIP_TTL_MS)
    }

    fun save(id: Long, bytes: ByteArray) {
        val target = File(dir, "$id.jpg")
        target.writeBytes(bytes)
        File(dir, "$id.skip").delete()
        mutableStamps.value = mutableStamps.value + (id to target.lastModified())
    }

    fun markChecked(id: Long) {
        File(dir, "$id.skip").writeText("")
    }

    fun migrate(map: Map<Long, Long>) {
        dir.listFiles().orEmpty().forEach { file ->
            val old = file.nameWithoutExtension.toLongOrNull() ?: return@forEach
            val target = map[old]
            if (target == null) {
                file.delete()
            } else if (target != old) {
                val moved = File(dir, "$target.${file.extension}")
                if (!moved.exists()) file.renameTo(moved) else file.delete()
            }
        }
        mutableStamps.value = dir.listFiles().orEmpty()
            .filter { it.extension == "jpg" }
            .mapNotNull { file -> file.nameWithoutExtension.toLongOrNull()?.let { it to file.lastModified() } }
            .toMap()
    }

    fun remove(ids: Set<Long>) {
        ids.forEach {
            File(dir, "$it.jpg").delete()
            File(dir, "$it.skip").delete()
        }
        mutableStamps.value = mutableStamps.value - ids
    }
}
