package com.sonora.player.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class LibraryStore(context: Context) {

    private val prefs = context.getSharedPreferences("sonora", Context.MODE_PRIVATE)

    fun favorites(): Set<Long> =
        prefs.getStringSet("favorites", emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()

    fun saveFavorites(ids: Set<Long>) {
        prefs.edit().putStringSet("favorites", ids.map { it.toString() }.toSet()).apply()
    }

    fun playlists(): List<Playlist> {
        val raw = prefs.getString("playlists", null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val obj = array.getJSONObject(i)
                val ids = obj.getJSONArray("tracks")
                Playlist(
                    id = obj.getLong("id"),
                    name = obj.getString("name"),
                    trackIds = (0 until ids.length()).map { ids.getLong(it) }
                )
            }
        }.getOrDefault(emptyList())
    }

    fun savePlaylists(list: List<Playlist>) {
        val array = JSONArray()
        list.forEach { playlist ->
            array.put(
                JSONObject()
                    .put("id", playlist.id)
                    .put("name", playlist.name)
                    .put("tracks", JSONArray(playlist.trackIds))
            )
        }
        prefs.edit().putString("playlists", array.toString()).apply()
    }

    fun settings(): AppSettings = AppSettings(
        themeMode = runCatching { ThemeMode.valueOf(prefs.getString("theme", "") ?: "") }.getOrDefault(ThemeMode.System),
        dynamicColor = prefs.getBoolean("dynamic", true),
        hideShort = prefs.getBoolean("hide_short", true),
        sort = runCatching { SortOrder.valueOf(prefs.getString("sort", "") ?: "") }.getOrDefault(SortOrder.Title),
        onlineLyrics = prefs.getBoolean("online_lyrics", true),
        onlineCovers = prefs.getBoolean("online_covers", true),
        onlineAsked = prefs.getBoolean("online_asked", false),
        lyricsMode = prefs.getBoolean("lyrics_mode", false),
        lyricsScale = prefs.getFloat("lyrics_scale", 1f),
        skipSilence = prefs.getBoolean("skip_silence", false),
        normalizeVolume = prefs.getBoolean("normalize", false),
        notificationLyrics = prefs.getBoolean("notification_lyrics", true),
        skipSeconds = sanitizeSkipSeconds(prefs.getInt("skip_seconds", DefaultSkipSeconds)),
        showSkipButtons = prefs.getBoolean("show_skip_buttons", false)
    )

    fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putString("theme", settings.themeMode.name)
            .putBoolean("dynamic", settings.dynamicColor)
            .putBoolean("hide_short", settings.hideShort)
            .putString("sort", settings.sort.name)
            .putBoolean("online_lyrics", settings.onlineLyrics)
            .putBoolean("online_covers", settings.onlineCovers)
            .putBoolean("online_asked", settings.onlineAsked)
            .putBoolean("lyrics_mode", settings.lyricsMode)
            .putFloat("lyrics_scale", settings.lyricsScale)
            .putBoolean("skip_silence", settings.skipSilence)
            .putBoolean("normalize", settings.normalizeVolume)
            .putBoolean("notification_lyrics", settings.notificationLyrics)
            .putInt("skip_seconds", sanitizeSkipSeconds(settings.skipSeconds))
            .putBoolean("show_skip_buttons", settings.showSkipButtons)
            .apply()
    }

    fun trackEdits(): Map<Long, TrackEdit> {
        val raw = prefs.getString("track_edits", null) ?: return emptyMap()
        return runCatching {
            val obj = JSONObject(raw)
            obj.keys().asSequence().mapNotNull { key ->
                val id = key.toLongOrNull() ?: return@mapNotNull null
                val item = obj.getJSONObject(key)
                id to TrackEdit(item.getString("title"), item.getString("artist"), item.getString("album"))
            }.toMap()
        }.getOrDefault(emptyMap())
    }

    fun saveTrackEdits(edits: Map<Long, TrackEdit>) {
        val obj = JSONObject()
        edits.forEach { (id, edit) ->
            obj.put(
                id.toString(),
                JSONObject()
                    .put("title", edit.title)
                    .put("artist", edit.artist)
                    .put("album", edit.album)
            )
        }
        prefs.edit().putString("track_edits", obj.toString()).apply()
    }

    fun lyricNames(): Map<Long, LyricsName> {
        val raw = prefs.getString("lyric_names", null) ?: return emptyMap()
        return runCatching {
            val obj = JSONObject(raw)
            obj.keys().asSequence().mapNotNull { key ->
                val id = key.toLongOrNull() ?: return@mapNotNull null
                val item = obj.getJSONObject(key)
                id to LyricsName(item.getString("title"), item.getString("artist"), item.optString("album"))
            }.toMap()
        }.getOrDefault(emptyMap())
    }

    fun saveLyricNames(names: Map<Long, LyricsName>) {
        val obj = JSONObject()
        names.forEach { (id, name) ->
            obj.put(
                id.toString(),
                JSONObject()
                    .put("title", name.title)
                    .put("artist", name.artist)
                    .put("album", name.album)
            )
        }
        prefs.edit().putString("lyric_names", obj.toString()).apply()
    }

    fun idsMigrated(): Boolean = prefs.getBoolean("ids_migrated", false)

    fun markIdsMigrated() {
        prefs.edit().putBoolean("ids_migrated", true).apply()
    }

    fun playCounts(): Map<Long, Int> {
        val raw = prefs.getString("play_counts", null) ?: return emptyMap()
        return runCatching {
            val obj = JSONObject(raw)
            obj.keys().asSequence().mapNotNull { key ->
                key.toLongOrNull()?.let { it to obj.getInt(key) }
            }.toMap()
        }.getOrDefault(emptyMap())
    }

    fun savePlayCounts(counts: Map<Long, Int>) {
        val obj = JSONObject()
        counts.forEach { (id, count) -> obj.put(id.toString(), count) }
        prefs.edit().putString("play_counts", obj.toString()).apply()
    }

    fun session(): SavedSession? {
        val ids = prefs.getString("session_ids", null)
            ?.split(',')
            ?.mapNotNull { it.toLongOrNull() }
            .orEmpty()
        if (ids.isEmpty()) return null
        return SavedSession(ids, prefs.getInt("session_index", 0), prefs.getLong("session_position", 0L))
    }

    fun saveSession(session: SavedSession) {
        prefs.edit()
            .putString("session_ids", session.ids.joinToString(","))
            .putInt("session_index", session.index)
            .putLong("session_position", session.positionMs)
            .apply()
    }
}
