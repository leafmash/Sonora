package com.sonora.player.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

class LyricsRepository(context: Context) {

    private val dir = File(context.filesDir, "lyrics").apply { mkdirs() }

    private data class Hit(val synced: String?, val plain: String?)

    suspend fun load(track: Track, online: Boolean, force: Boolean): LyricsState =
        withContext(Dispatchers.IO) { loadBlocking(track, online, force) }

    suspend fun saveImported(trackId: Long, text: String): LyricsState =
        withContext(Dispatchers.IO) {
            val clean = text.take(300_000)
            val lines = LrcParser.parse(clean)
            if (lines.isNotEmpty()) {
                store(trackId, "lrc", clean)
                LyricsState.Synced(lines)
            } else {
                val plain = clean.trim()
                store(trackId, "txt", plain)
                LyricsState.Plain(plain)
            }
        }

    suspend fun search(title: String, artist: String): LyricsSearchState =
        withContext(Dispatchers.IO) {
            try {
                val typed = TrackNameCleaner.Query(title.trim(), artist.trim().ifEmpty { null })
                val cleaned = TrackNameCleaner.clean(title, artist.trim().ifEmpty { null })
                val attempts = LinkedHashSet<String>()
                listOf(typed, cleaned).forEach { variant ->
                    if (variant.title.isNotEmpty() && variant.artist != null) {
                        attempts += "track_name=${enc(variant.title)}&artist_name=${enc(variant.artist)}"
                    }
                }
                listOf(typed, cleaned).forEach { variant ->
                    val words = TrackNameCleaner.freeText(variant)
                    if (words.isNotEmpty()) attempts += "q=${enc(words)}"
                }
                if (cleaned.title.isNotEmpty()) attempts += "q=${enc(cleaned.title)}"

                val found = LinkedHashMap<Long, LyricsCandidate>()
                for (query in attempts) {
                    collect(query, found)
                    if (found.size >= MIN_RESULTS) break
                }
                val sorted = found.values.sortedByDescending { it.isSynced }.take(MAX_RESULTS)
                if (sorted.isEmpty()) LyricsSearchState.Empty else LyricsSearchState.Results(sorted)
            } catch (e: Exception) {
                LyricsSearchState.Failed
            }
        }

    suspend fun saveCandidate(trackId: Long, candidate: LyricsCandidate): LyricsState =
        withContext(Dispatchers.IO) {
            val lines = candidate.synced?.let { LrcParser.parse(it) }.orEmpty()
            if (lines.isNotEmpty()) {
                store(trackId, "lrc", candidate.synced.orEmpty())
                LyricsState.Synced(lines)
            } else {
                val plain = candidate.plain?.trim().orEmpty()
                store(trackId, "txt", plain)
                LyricsState.Plain(plain)
            }
        }

    private fun collect(query: String, into: MutableMap<Long, LyricsCandidate>) {
        val body = get("$BASE/search?$query") ?: return
        val array = JSONArray(body)
        for (index in 0 until array.length()) {
            candidateFrom(array.getJSONObject(index))?.let { into.putIfAbsent(it.id, it) }
        }
    }

    private fun candidateFrom(obj: JSONObject): LyricsCandidate? {
        val synced = text(obj, "syncedLyrics")?.takeIf { it.isNotBlank() }
        val plain = text(obj, "plainLyrics")?.takeIf { it.isNotBlank() }
        if (synced == null && plain == null) return null
        return LyricsCandidate(
            id = obj.optLong("id"),
            title = text(obj, "trackName").orEmpty(),
            artist = text(obj, "artistName").orEmpty(),
            album = text(obj, "albumName").orEmpty(),
            durationSec = obj.optDouble("duration", 0.0).toInt(),
            synced = synced,
            plain = plain
        )
    }

    private fun loadBlocking(track: Track, online: Boolean, force: Boolean): LyricsState {
        val cached = readCache(track.id)
        if (cached != null && !force) return cached
        val cachedLyrics = cached?.takeIf { it is LyricsState.Synced || it is LyricsState.Plain }
        if (!online) return cachedLyrics ?: LyricsState.NotFound

        val hit = try {
            fetch(track)
        } catch (e: Exception) {
            return cachedLyrics ?: LyricsState.Failed
        }

        if (hit != null) {
            val lines = hit.synced?.let { LrcParser.parse(it) }.orEmpty()
            if (lines.isNotEmpty()) {
                store(track.id, "lrc", hit.synced.orEmpty())
                return LyricsState.Synced(lines)
            }
            val plain = hit.plain?.trim().orEmpty()
            if (plain.isNotEmpty()) {
                if (cachedLyrics is LyricsState.Synced) return cachedLyrics
                store(track.id, "txt", plain)
                return LyricsState.Plain(plain)
            }
        }

        if (cachedLyrics != null) return cachedLyrics
        store(track.id, "none", "")
        return LyricsState.NotFound
    }

    private fun readCache(id: Long): LyricsState? {
        val synced = File(dir, "$id.lrc")
        if (synced.exists()) {
            val lines = LrcParser.parse(synced.readText())
            if (lines.isNotEmpty()) return LyricsState.Synced(lines)
        }
        val plainFile = File(dir, "$id.txt")
        if (plainFile.exists()) {
            val text = plainFile.readText().trim()
            if (text.isNotEmpty()) return LyricsState.Plain(text)
        }
        val none = File(dir, "$id.none")
        if (none.exists() && System.currentTimeMillis() - none.lastModified() < NONE_TTL_MS) {
            return LyricsState.NotFound
        }
        return null
    }

    private fun store(id: Long, extension: String, text: String) {
        listOf("lrc", "txt", "none").forEach { other ->
            if (other != extension) File(dir, "$id.$other").delete()
        }
        File(dir, "$id.$extension").writeText(text)
    }

    private fun fetch(track: Track): Hit? {
        val seconds = (track.durationMs / 1000).toInt()
        val knownArtist = !TrackNameCleaner.isUnknown(track.artist)
        val knownAlbum = !TrackNameCleaner.isUnknown(track.album)
        val variants = TrackNameCleaner.variants(track)
        val first = variants.firstOrNull()

        if (knownArtist && knownAlbum && first != null && first.artist != null && first.title.isNotEmpty()) {
            val url = "$BASE/get?track_name=${enc(first.title)}&artist_name=${enc(first.artist)}" +
                "&album_name=${enc(track.album)}&duration=$seconds"
            get(url)?.let { body ->
                hitFrom(JSONObject(body))?.let { return it }
            }
        }

        val seen = HashSet<String>()
        val pool = ArrayList<Pair<JSONObject, String>>()
        var requests = 0
        for (variant in variants) {
            if (variant.title.isEmpty()) continue
            val queries = buildList {
                if (variant.artist != null) {
                    add("track_name=${enc(variant.title)}&artist_name=${enc(variant.artist)}")
                }
                add("q=${enc(TrackNameCleaner.freeText(variant))}")
            }
            for (query in queries) {
                if (requests >= MAX_REQUESTS) break
                if (!seen.add(query)) continue
                requests++
                val body = get("$BASE/search?$query") ?: continue
                val array = JSONArray(body)
                val entries = (0 until array.length()).map { array.getJSONObject(it) }
                best(entries, seconds, STRICT_TOLERANCE, null)?.let { return it }
                entries.forEach { pool += it to variant.title }
            }
        }

        for ((entry, wanted) in pool) {
            val name = text(entry, "trackName").orEmpty()
            if (!TrackNameCleaner.titlesMatch(name, wanted)) continue
            best(listOf(entry), seconds, RELAXED_TOLERANCE, wanted)?.let { return it }
        }
        return null
    }

    private fun best(entries: List<JSONObject>, seconds: Int, tolerance: Double, wanted: String?): Hit? {
        val close = entries
            .filter { abs(it.optDouble("duration", -1000.0) - seconds) <= tolerance }
            .filter { wanted == null || TrackNameCleaner.titlesMatch(text(it, "trackName").orEmpty(), wanted) }
            .sortedBy { abs(it.optDouble("duration", 0.0) - seconds) }
        if (close.isEmpty()) return null
        close.firstOrNull { !text(it, "syncedLyrics").isNullOrBlank() }?.let {
            return Hit(text(it, "syncedLyrics"), text(it, "plainLyrics"))
        }
        close.firstOrNull { !text(it, "plainLyrics").isNullOrBlank() }?.let {
            return Hit(null, text(it, "plainLyrics"))
        }
        return null
    }

    private fun hitFrom(obj: JSONObject): Hit? {
        val synced = text(obj, "syncedLyrics")
        val plain = text(obj, "plainLyrics")
        if (synced.isNullOrBlank() && plain.isNullOrBlank()) return null
        return Hit(synced, plain)
    }

    private fun text(obj: JSONObject, key: String): String? =
        if (obj.isNull(key)) null else obj.getString(key)

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun get(url: String): String? {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 8000
            connection.readTimeout = 10000
            connection.setRequestProperty("User-Agent", "Sonora/1.0 (Android music player)")
            val code = connection.responseCode
            if (code == 404) return null
            if (code !in 200..299) throw IOException("HTTP $code")
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private companion object {
        const val BASE = "https://lrclib.net/api"
        const val MAX_RESULTS = 30
        const val MIN_RESULTS = 5
        const val MAX_REQUESTS = 6
        const val STRICT_TOLERANCE = 6.0
        const val RELAXED_TOLERANCE = 15.0
        const val NONE_TTL_MS = 3L * 24 * 60 * 60 * 1000
    }
}
