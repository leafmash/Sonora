package com.sonora.player.data

import android.net.Uri

data class Track(
    val id: Long,
    val mediaId: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val uri: Uri,
    val dateAdded: Long,
    val folder: String
)

data class Album(
    val id: Long,
    val name: String,
    val artist: String,
    val tracks: List<Track>
) {
    val cover: Track get() = tracks.first()
}

data class Artist(
    val name: String,
    val tracks: List<Track>,
    val albumCount: Int
)

data class Folder(
    val path: String,
    val tracks: List<Track>
) {
    val name: String get() = path.substringAfterLast('/').ifBlank { "Unknown folder" }
    val location: String get() = path.removePrefix("/storage/emulated/0").trim('/').ifBlank { "Unknown location" }
}

data class Playlist(
    val id: Long,
    val name: String,
    val trackIds: List<Long>
)

data class Library(
    val tracks: List<Track> = emptyList(),
    val albums: List<Album> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val folders: List<Folder> = emptyList()
) {
    private val byId: Map<Long, Track> = tracks.associateBy { it.id }

    fun track(id: Long): Track? = byId[id]

    companion object {
        fun build(source: List<Track>): Library {
            val tracks = source.sortedBy { it.title.lowercase() }

            val albums = tracks
                .groupBy { it.albumId }
                .map { (albumId, list) ->
                    Album(
                        id = albumId,
                        name = list.groupingBy { it.album }.eachCount().maxByOrNull { it.value }?.key ?: list.first().album,
                        artist = list.groupingBy { it.artist }.eachCount().maxByOrNull { it.value }?.key ?: list.first().artist,
                        tracks = list
                    )
                }
                .sortedBy { it.name.lowercase() }

            val artists = tracks
                .groupBy { it.artist }
                .map { (name, list) -> Artist(name, list, list.map { it.albumId }.distinct().size) }
                .sortedBy { it.name.lowercase() }

            val folders = tracks
                .groupBy { it.folder }
                .map { (path, list) -> Folder(path, list) }
                .sortedBy { it.name.lowercase() }

            return Library(tracks, albums, artists, folders)
        }
    }
}

enum class ThemeMode { System, Light, Dark, Amoled }

enum class SortOrder(val label: String) {
    Title("Title"),
    Artist("Artist"),
    Album("Album"),
    Recent("Recently added"),
    Duration("Duration")
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.System,
    val dynamicColor: Boolean = true,
    val hideShort: Boolean = true,
    val sort: SortOrder = SortOrder.Title,
    val onlineLyrics: Boolean = true,
    val onlineCovers: Boolean = true,
    val onlineAsked: Boolean = false,
    val lyricsMode: Boolean = false,
    val lyricsScale: Float = 1f,
    val skipSilence: Boolean = false,
    val normalizeVolume: Boolean = false,
    val notificationLyrics: Boolean = true,
    val skipSeconds: Int = DefaultSkipSeconds,
    val showSkipButtons: Boolean = false
)

const val DefaultSkipSeconds = 10
val SkipSecondsOptions = listOf(5, 10, 15, 30)

fun sanitizeSkipSeconds(value: Int): Int = if (value in SkipSecondsOptions) value else DefaultSkipSeconds

data class TrackEdit(
    val title: String,
    val artist: String,
    val album: String
)

data class LyricsName(
    val title: String,
    val artist: String,
    val album: String = ""
)

data class LyricLine(val timeMs: Long, val text: String)

sealed interface LyricsState {
    data object Idle : LyricsState
    data object Loading : LyricsState
    data class Synced(val lines: List<LyricLine>) : LyricsState
    data class Plain(val text: String) : LyricsState
    data object NotFound : LyricsState
    data object Failed : LyricsState
}

data class LyricsLoad(
    val state: LyricsState,
    val name: LyricsName? = null
)

data class LyricsCandidate(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationSec: Int,
    val synced: String?,
    val plain: String?
) {
    val isSynced: Boolean get() = !synced.isNullOrBlank()
}

sealed interface LyricsSearchState {
    data object Idle : LyricsSearchState
    data object Searching : LyricsSearchState
    data class Results(val items: List<LyricsCandidate>) : LyricsSearchState
    data object Empty : LyricsSearchState
    data object Failed : LyricsSearchState
}

data class CoverOption(
    val title: String,
    val artist: String,
    val previewUrl: String,
    val fullUrl: String
)

sealed interface CoverSearchState {
    data object Idle : CoverSearchState
    data object Searching : CoverSearchState
    data class Results(val items: List<CoverOption>) : CoverSearchState
    data object Empty : CoverSearchState
    data object Failed : CoverSearchState
}

data class SavedSession(
    val ids: List<Long>,
    val index: Int,
    val positionMs: Long
)

sealed interface Route {
    data class AlbumRoute(val albumId: Long) : Route
    data class ArtistRoute(val name: String) : Route
    data class PlaylistRoute(val id: Long) : Route
    data class FolderRoute(val path: String) : Route
    data object FavoritesRoute : Route
    data object RecentRoute : Route
    data object MostPlayedRoute : Route
    data object EqualizerRoute : Route
    data object AboutRoute : Route
}
