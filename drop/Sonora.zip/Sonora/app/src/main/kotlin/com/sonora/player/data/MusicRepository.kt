package com.sonora.player.data

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MusicRepository(private val context: Context) {

    suspend fun load(
        hideShort: Boolean,
        edits: Map<Long, TrackEdit> = emptyMap(),
        names: Map<Long, LyricsName> = emptyMap()
    ): Library = withContext(Dispatchers.IO) {
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.IS_RINGTONE,
            MediaStore.Audio.Media.IS_NOTIFICATION,
            MediaStore.Audio.Media.IS_ALARM
        ) + if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) arrayOf(MediaStore.Audio.Media.IS_RECORDING) else emptyArray<String>()
        val minDuration = if (hideShort) 30_000L else 1_000L
        val selection = "${MediaStore.Audio.Media.DURATION} >= ?"
        val tracks = ArrayList<Track>()

        context.contentResolver.query(collection, projection, selection, arrayOf(minDuration.toString()), null)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val addedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
            val ringtoneCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_RINGTONE)
            val notificationCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_NOTIFICATION)
            val alarmCol = cursor.getColumnIndex(MediaStore.Audio.Media.IS_ALARM)
            val recordingCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                cursor.getColumnIndex(MediaStore.Audio.Media.IS_RECORDING)
            } else {
                -1
            }

            while (cursor.moveToNext()) {
                val isSystemSound = (ringtoneCol >= 0 && cursor.getInt(ringtoneCol) != 0) ||
                    (notificationCol >= 0 && cursor.getInt(notificationCol) != 0) ||
                    (alarmCol >= 0 && cursor.getInt(alarmCol) != 0)
                if (isSystemSound) continue
                if (recordingCol >= 0 && cursor.getInt(recordingCol) != 0) continue

                val id = cursor.getLong(idCol)
                val rawArtist = cursor.getString(artistCol)
                    ?.takeUnless { it == MediaStore.UNKNOWN_STRING || it.isBlank() }
                val rawTitle = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                val shown = runCatching { TrackNameCleaner.display(rawTitle, rawArtist) }.getOrNull()
                val artist = shown?.artist ?: rawArtist ?: "Unknown artist"
                val album = cursor.getString(albumCol)
                    ?.takeUnless { it.isBlank() || it == MediaStore.UNKNOWN_STRING }
                    ?: "Unknown album"
                val path = if (dataCol >= 0) cursor.getString(dataCol).orEmpty() else ""
                if (isVoiceRecording(path)) continue
                val key = stableId(path, id)
                val edit = edits[key]
                val name = names[key]
                tracks += Track(
                    id = key,
                    mediaId = id,
                    title = edit?.title ?: name?.title?.takeIf { it.isNotBlank() } ?: shown?.title?.takeIf { it.isNotBlank() } ?: rawTitle ?: "Unknown title",
                    artist = edit?.artist ?: name?.artist?.takeIf { it.isNotBlank() } ?: artist,
                    album = edit?.album ?: name?.album?.takeIf { it.isNotBlank() } ?: album,
                    albumId = cursor.getLong(albumIdCol),
                    durationMs = cursor.getLong(durationCol),
                    uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                    dateAdded = cursor.getLong(addedCol),
                    folder = path.substringBeforeLast('/', "").substringAfterLast('/')
                )
            }
        }

        Library.build(tracks)
    }

    private fun stableId(path: String, fallback: Long): Long {
        if (path.isBlank()) return fallback
        var hash = -3750763034362895579L
        for (ch in path) {
            hash = hash xor ch.code.toLong()
            hash *= 1099511628211L
        }
        return hash and Long.MAX_VALUE
    }

    private fun isVoiceRecording(path: String): Boolean {
        val lower = path.lowercase()
        return RECORDING_MARKERS.any { lower.contains(it) }
    }

    private companion object {
        val RECORDING_MARKERS = listOf(
            "voice notes",
            "voice recorder",
            "voicerecorder",
            "voice memo",
            "sound recorder",
            "soundrecorder",
            "/recordings/",
            "/recording/",
            "call recording",
            "callrecord",
            "call_record"
        )
    }
}
