package com.sonora.player.data

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sin

object PcmResampler {

    private const val ZERO_CROSSINGS = 12
    private const val TABLE_SIZE = 2048
    private const val CUTOFF = 0.45

    fun resample(input: ShortArray, length: Int, fromRate: Int, toRate: Int): ShortArray {
        val count = min(length, input.size)
        if (fromRate == toRate) return input.copyOf(count)
        if (count == 0 || fromRate <= 0 || toRate <= 0) return ShortArray(0)

        val ratio = fromRate.toDouble() / toRate
        val cutoff = CUTOFF / maxOf(1.0, ratio)
        val halfWidth = ZERO_CROSSINGS / (2.0 * cutoff)

        val table = DoubleArray(TABLE_SIZE + 2)
        for (i in table.indices) {
            val u = i.toDouble() / TABLE_SIZE * halfWidth
            val x = 2.0 * cutoff * u
            val sinc = if (x == 0.0) 1.0 else sin(PI * x) / (PI * x)
            val taper = 0.5 + 0.5 * cos(PI * u / halfWidth)
            table[i] = 2.0 * cutoff * sinc * taper
        }
        val tableScale = TABLE_SIZE / halfWidth

        val outputLength = floor(count / ratio).toInt()
        val output = ShortArray(outputLength)
        for (n in 0 until outputLength) {
            val center = n * ratio
            val first = maxOf(0, ceil(center - halfWidth).toInt())
            val last = min(count - 1, floor(center + halfWidth).toInt())
            var sum = 0.0
            for (i in first..last) {
                val position = abs(i - center) * tableScale
                val index = position.toInt()
                val fraction = position - index
                val weight = table[index] + (table[index + 1] - table[index]) * fraction
                sum += input[i] * weight
            }
            output[n] = sum.coerceIn(-32768.0, 32767.0).toInt().toShort()
        }
        return output
    }
}
