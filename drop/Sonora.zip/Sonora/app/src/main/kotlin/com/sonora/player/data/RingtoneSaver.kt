package com.sonora.player.data

import android.content.ContentValues
import android.content.Context
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object RingtoneSaver {

    fun canWriteSettings(context: Context): Boolean = Settings.System.canWrite(context)

    suspend fun setAsRingtone(context: Context, track: Track): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val target = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                existingRingtone(context, track) ?: copyToRingtones(context, track)
            } else {
                legacyRingtone(track)
            }
            RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_RINGTONE, target)
            true
        }.getOrDefault(false)
    }

    private fun safeName(track: Track): String {
        val raw = "${track.title} - ${track.artist}"
        return raw.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().take(80).ifBlank { "ringtone" }
    }

    private fun sourceExtension(context: Context, track: Track): String {
        val name = context.contentResolver.query(track.uri, arrayOf(MediaStore.Audio.Media.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0).orEmpty() else ""
        }.orEmpty()
        return name.substringAfterLast('.', "mp3").ifBlank { "mp3" }
    }

    private fun mimeFor(context: Context, track: Track, extension: String): String {
        val stored = context.contentResolver.getType(track.uri)
        if (!stored.isNullOrBlank() && stored.startsWith("audio/")) return stored
        return when (extension.lowercase()) {
            "m4a", "aac" -> "audio/mp4"
            "flac" -> "audio/flac"
            "ogg", "oga", "opus" -> "audio/ogg"
            "wav" -> "audio/x-wav"
            else -> "audio/mpeg"
        }
    }

    private fun existingRingtone(context: Context, track: Track): Uri? {
        val extension = sourceExtension(context, track)
        val name = "${safeName(track)}.$extension"
        val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        return context.contentResolver.query(
            collection,
            arrayOf(MediaStore.Audio.Media._ID),
            "${MediaStore.Audio.Media.DISPLAY_NAME} = ? AND ${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?",
            arrayOf(name, "${Environment.DIRECTORY_RINGTONES}/%"),
            null
        )?.use {
            if (it.moveToFirst()) android.content.ContentUris.withAppendedId(collection, it.getLong(0)) else null
        }
    }

    private fun copyToRingtones(context: Context, track: Track): Uri {
        val extension = sourceExtension(context, track)
        val resolver = context.contentResolver
        val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, "${safeName(track)}.$extension")
            put(MediaStore.Audio.Media.TITLE, track.title)
            put(MediaStore.Audio.Media.ARTIST, track.artist)
            put(MediaStore.Audio.Media.MIME_TYPE, mimeFor(context, track, extension))
            put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_RINGTONES)
            put(MediaStore.Audio.Media.IS_RINGTONE, 1)
            put(MediaStore.Audio.Media.IS_MUSIC, 0)
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val target = resolver.insert(collection, values) ?: error("insert failed")
        try {
            val input = resolver.openInputStream(track.uri) ?: error("open failed")
            val output = resolver.openOutputStream(target) ?: error("write failed")
            input.use { source -> output.use { sink -> source.copyTo(sink) } }
            val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
            resolver.update(target, done, null, null)
        } catch (error: Throwable) {
            runCatching { resolver.delete(target, null, null) }
            throw error
        }
        return target
    }

    private fun legacyRingtone(track: Track): Uri = track.uri
}
