package com.sonora.player.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import org.jaudiotagger.tag.images.ArtworkFactory
import java.io.File

class TagWriter(private val context: Context) {

    fun write(
        uri: Uri,
        title: String?,
        artist: String?,
        album: String?,
        cover: ByteArray?,
        clearCover: Boolean
    ): Boolean {
        val resolver = context.contentResolver
        val temp = File.createTempFile("tags", ".${extensionOf(uri)}", context.cacheDir)
        return try {
            val input = resolver.openInputStream(uri) ?: return false
            input.use { source -> temp.outputStream().use { source.copyTo(it) } }
            val audio = AudioFileIO.read(temp)
            val tag = audio.tagOrCreateAndSetDefault
            if (title != null) tag.setField(FieldKey.TITLE, title)
            if (artist != null) tag.setField(FieldKey.ARTIST, artist)
            if (album != null) tag.setField(FieldKey.ALBUM, album)
            if (cover != null) {
                val artwork = ArtworkFactory.getNew()
                artwork.binaryData = cover
                artwork.mimeType = mimeOf(cover)
                artwork.pictureType = FRONT_COVER
                tag.deleteArtworkField()
                tag.setField(artwork)
            } else if (clearCover) {
                tag.deleteArtworkField()
            }
            audio.commit()
            val output = resolver.openOutputStream(uri, "wt") ?: return false
            output.use { target -> temp.inputStream().use { it.copyTo(target) } }
            true
        } catch (error: SecurityException) {
            throw error
        } catch (error: Throwable) {
            false
        } finally {
            temp.delete()
        }
    }

    private fun mimeOf(bytes: ByteArray): String =
        if (bytes.size > 3 && bytes[0] == 0x89.toByte() && bytes[1] == 'P'.code.toByte()) "image/png" else "image/jpeg"

    private fun extensionOf(uri: Uri): String {
        val name = runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull()
        val extension = name?.substringAfterLast('.', "")?.lowercase().orEmpty()
        return extension.ifEmpty { "mp3" }
    }

    private companion object {
        const val FRONT_COVER = 3
    }
}
