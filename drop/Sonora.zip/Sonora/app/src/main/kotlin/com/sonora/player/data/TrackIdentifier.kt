package com.sonora.player.data

import android.content.Context
import com.sonora.player.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class IdentifyMatch(
    val title: String,
    val artist: String,
    val album: String,
    val score: Double
)

data class BatchIdentify(
    val running: Boolean = false,
    val total: Int = 0,
    val done: Int = 0,
    val applied: Int = 0,
    val finished: Boolean = false,
    val needsKey: Boolean = false,
    val offline: Boolean = false
)

fun isUnidentified(track: Track): Boolean =
    track.id >= 0 && (TrackNameCleaner.isUnknown(track.artist) || TrackNameCleaner.isUnknown(track.album))

sealed interface IdentifyState {
    data object Idle : IdentifyState
    data object Decoding : IdentifyState
    data object Fingerprinting : IdentifyState
    data object Looking : IdentifyState
    data class Found(val matches: List<IdentifyMatch>) : IdentifyState
    data object NotFound : IdentifyState
    data object NoKey : IdentifyState
    data object Unreadable : IdentifyState
    data object Failed : IdentifyState
}

private class InvalidKeyException : IOException("Invalid AcoustID key")

class TrackIdentifier(private val context: Context) {

    suspend fun identify(
        track: Track,
        userKey: String,
        onStage: (IdentifyState) -> Unit
    ): IdentifyState = withContext(Dispatchers.IO) {
        val key = userKey.trim().ifEmpty { BuildConfig.ACOUSTID_KEY }
        if (key.isEmpty()) return@withContext IdentifyState.NoKey

        onStage(IdentifyState.Decoding)
        val decoded = AudioDecoder.decodeMono(context, track.uri, ANALYZE_SECONDS)
            ?: return@withContext IdentifyState.Unreadable

        onStage(IdentifyState.Fingerprinting)
        val pcm = PcmResampler.resample(
            decoded.samples,
            decoded.length,
            decoded.sampleRate,
            Chromaprint.SAMPLE_RATE
        )
        val fingerprint = Chromaprint.fingerprint(pcm)
        if (fingerprint.size < MIN_SUBFINGERPRINTS) return@withContext IdentifyState.Unreadable

        onStage(IdentifyState.Looking)
        val duration = (track.durationMs / 1000).toInt().coerceAtLeast(pcm.size / Chromaprint.SAMPLE_RATE)
        try {
            val body = lookup(key, duration, Chromaprint.encode(fingerprint))
            val matches = parse(body)
            if (matches.isEmpty()) IdentifyState.NotFound else IdentifyState.Found(matches)
        } catch (e: InvalidKeyException) {
            IdentifyState.NoKey
        } catch (e: IOException) {
            IdentifyState.Failed
        } catch (e: JSONException) {
            IdentifyState.Failed
        }
    }

    private fun lookup(key: String, duration: Int, fingerprint: String): String {
        val form = "client=${enc(key)}" +
            "&duration=$duration" +
            "&meta=${enc("recordings releasegroups")}" +
            "&format=json" +
            "&fingerprint=${enc(fingerprint)}"
        val connection = URL(ENDPOINT).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.doOutput = true
            connection.connectTimeout = 10_000
            connection.readTimeout = 20_000
            connection.setRequestProperty("User-Agent", USER_AGENT)
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            connection.outputStream.use { it.write(form.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (text.isEmpty()) throw IOException("HTTP $code")
            return text
        } finally {
            connection.disconnect()
        }
    }

    private fun parse(body: String): List<IdentifyMatch> {
        val root = JSONObject(body)
        if (root.optString("status") != "ok") {
            val code = root.optJSONObject("error")?.optInt("code") ?: 0
            if (code == INVALID_KEY_CODE) throw InvalidKeyException()
            throw IOException("AcoustID error $code")
        }
        val results = root.optJSONArray("results") ?: return emptyList()
        val found = ArrayList<IdentifyMatch>()
        for (r in 0 until results.length()) {
            val result = results.getJSONObject(r)
            val score = result.optDouble("score", 0.0)
            if (score < MIN_SCORE) continue
            val recordings = result.optJSONArray("recordings") ?: continue
            for (i in 0 until recordings.length()) {
                val recording = recordings.getJSONObject(i)
                val title = recording.optString("title").trim()
                if (title.isEmpty()) continue
                val artist = joinArtists(recording)
                if (artist.isEmpty()) continue
                found += IdentifyMatch(title, artist, pickAlbum(recording), score)
            }
        }
        return found
            .distinctBy { Triple(it.title.lowercase(), it.artist.lowercase(), it.album.lowercase()) }
            .sortedByDescending { it.score }
            .take(MAX_MATCHES)
    }

    private fun joinArtists(recording: JSONObject): String {
        val artists = recording.optJSONArray("artists") ?: return ""
        val builder = StringBuilder()
        for (i in 0 until artists.length()) {
            val artist = artists.getJSONObject(i)
            builder.append(artist.optString("name"))
            if (i < artists.length() - 1) {
                builder.append(artist.optString("joinphrase").ifEmpty { ", " })
            }
        }
        return builder.toString().trim()
    }

    private fun pickAlbum(recording: JSONObject): String {
        val groups = recording.optJSONArray("releasegroups") ?: return ""
        var fallback = ""
        for (i in 0 until groups.length()) {
            val group = groups.getJSONObject(i)
            val title = group.optString("title").trim()
            if (title.isEmpty()) continue
            val secondary = group.optJSONArray("secondarytypes")
            val plain = secondary == null || secondary.length() == 0
            val type = group.optString("type")
            if (type.equals("Album", ignoreCase = true) && plain) return title
            if (fallback.isEmpty() && plain) fallback = title
        }
        return fallback
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private companion object {
        const val ENDPOINT = "https://api.acoustid.org/v2/lookup"
        const val USER_AGENT = "Sonora/1.0 (Android music player)"
        const val ANALYZE_SECONDS = 120
        const val MIN_SUBFINGERPRINTS = 20
        const val MIN_SCORE = 0.5
        const val MAX_MATCHES = 6
        const val INVALID_KEY_CODE = 4
    }
}
