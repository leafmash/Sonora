package com.sonora.player.data

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date
import java.util.Locale

data class TrackInfo(
    val fileName: String,
    val path: String,
    val format: String,
    val codec: String,
    val bitrate: String,
    val sampleRate: String,
    val channels: String,
    val bitDepth: String,
    val sizeBytes: Long,
    val dateAdded: String,
    val dateModified: String
)

object TrackInfoLoader {

    suspend fun load(context: Context, track: Track): TrackInfo = withContext(Dispatchers.IO) {
        var fileName = ""
        var path = ""
        var mime = ""
        var size = 0L
        var added = 0L
        var modified = 0L
        runCatching {
            val projection = arrayOf(
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.MIME_TYPE,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.DATE_ADDED,
                MediaStore.Audio.Media.DATE_MODIFIED
            )
            context.contentResolver.query(track.uri, projection, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    fileName = cursor.getString(0).orEmpty()
                    path = cursor.getString(1).orEmpty()
                    mime = cursor.getString(2).orEmpty()
                    size = cursor.getLong(3)
                    added = cursor.getLong(4)
                    modified = cursor.getLong(5)
                }
            }
        }

        var codec = ""
        var sampleRate = 0
        var channelCount = 0
        var bitrate = 0L
        var bitDepth = 0
        runCatching {
            val extractor = MediaExtractor()
            try {
                extractor.setDataSource(context, track.uri, null)
                for (index in 0 until extractor.trackCount) {
                    val format = extractor.getTrackFormat(index)
                    val trackMime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                    if (!trackMime.startsWith("audio/")) continue
                    codec = trackMime
                    if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channelCount = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (format.containsKey(MediaFormat.KEY_BIT_RATE)) bitrate = format.getInteger(MediaFormat.KEY_BIT_RATE).toLong()
                    if (format.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                        bitDepth = when (format.getInteger(MediaFormat.KEY_PCM_ENCODING)) {
                            3 -> 8
                            2 -> 16
                            21 -> 24
                            22 -> 32
                            4 -> 32
                            else -> 0
                        }
                    }
                    break
                }
            } finally {
                extractor.release()
            }
        }

        if (bitrate <= 0) {
            runCatching {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, track.uri)
                    bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull() ?: 0L
                } finally {
                    retriever.release()
                }
            }
        }
        if (bitrate <= 0 && size > 0 && track.durationMs > 0) {
            bitrate = size * 8 * 1000 / track.durationMs
        }

        val extension = fileName.substringAfterLast('.', "").ifBlank { path.substringAfterLast('.', "") }
        val format = formatName(extension, mime.ifBlank { codec })

        TrackInfo(
            fileName = fileName.ifBlank { path.substringAfterLast('/') },
            path = path.ifBlank { "Unknown" },
            format = format,
            codec = codecName(codec),
            bitrate = if (bitrate > 0) "${(bitrate / 1000.0).let { Math.round(it) }} kbps" else "Unknown",
            sampleRate = if (sampleRate > 0) formatSampleRate(sampleRate) else "Unknown",
            channels = when (channelCount) {
                0 -> "Unknown"
                1 -> "Mono"
                2 -> "Stereo"
                else -> "$channelCount channels"
            },
            bitDepth = if (bitDepth > 0) "$bitDepth-bit" else "",
            sizeBytes = size,
            dateAdded = formatDate(added),
            dateModified = formatDate(modified)
        )
    }

    private fun formatName(extension: String, mime: String): String {
        val ext = extension.lowercase(Locale.ROOT)
        if (ext.isNotBlank()) return ext.uppercase(Locale.ROOT)
        return mime.substringAfter('/', mime).uppercase(Locale.ROOT).ifBlank { "Unknown" }
    }

    private fun codecName(mime: String): String = when (mime.lowercase(Locale.ROOT)) {
        "audio/mpeg" -> "MP3"
        "audio/mp4a-latm" -> "AAC"
        "audio/flac" -> "FLAC"
        "audio/vorbis" -> "Vorbis"
        "audio/opus" -> "Opus"
        "audio/raw" -> "PCM"
        "audio/amr-wb" -> "AMR-WB"
        "audio/3gpp" -> "AMR-NB"
        "audio/alac" -> "ALAC"
        "audio/ac3" -> "AC-3"
        "audio/eac3" -> "E-AC-3"
        "" -> "Unknown"
        else -> mime.substringAfter('/', mime).uppercase(Locale.ROOT)
    }

    private fun formatSampleRate(hz: Int): String {
        val khz = hz / 1000.0
        return if (hz % 1000 == 0) "${hz / 1000} kHz" else String.format(Locale.US, "%.1f kHz", khz)
    }

    private fun formatDate(epochSeconds: Long): String {
        if (epochSeconds <= 0) return "Unknown"
        return DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(epochSeconds * 1000))
    }
}

fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return "Unknown"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1 -> String.format(Locale.US, "%.2f GB", gb)
        mb >= 1 -> String.format(Locale.US, "%.2f MB", mb)
        else -> String.format(Locale.US, "%.0f KB", kb)
    }
}
