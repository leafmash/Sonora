package com.sonora.player.data

import java.text.Normalizer

object TrackNameCleaner {

    data class Query(val title: String, val artist: String?)

    private const val WORD = "[\\p{L}\\p{M}\\p{N}]"

    private val extension = Regex("""\.(mp3|m4a|flac|wav|ogg|opus|aac|wma|mp4|webm|amr|3gp)$""", RegexOption.IGNORE_CASE)
    private val invisible = Regex("""[\u200B-\u200D\u2060\uFEFF\u00AD]""")
    private val dashes = Regex("""[\u2010-\u2015\u2212\u2012]""")
    private val url = Regex("""(?i)(?:https?://|www\.)\S+""")
    private val domain = Regex("""(?i)(?<![\p{L}\p{N}])[\p{L}\p{N}-]+\.(?:com|net|org|in|co|me|info|pk|bd|xyz|io|tv|fm|cc|ws|biz|site|online)(?![\p{L}\p{N}])""")
    private val bitrate = Regex("""(?i)(?<!\d)\d{2,3}\s*kbps""")
    private val brackets = Regex("""\([^()]*\)|\[[^\[\]]*]|\{[^{}]*}|【[^】]*】|「[^」]*」|『[^』]*』|（[^）]*）""")
    private val leadingTrack = Regex("""^\s*(?:\(\d{1,3}\)\s*|\d{1,3}\s*[-.)]\s+|\d{1,2}\s*-\s*\d{1,2}\s+|0\d\s+)""")
    private val featTail = Regex("""(?i)\s+(?:feat|ft|featuring)\.?\s+.*$""")
    private val featInline = Regex("""(?i)(?<![\p{L}\p{N}])(?:feat|ft|featuring)\.?\s+""")
    private val strayChars = Regex("""[^\p{L}\p{M}\p{N}\s'&.,!?()\-]""")
    private val edgePunct = Regex("""^[\s\-.,:;|/\\~_*+]+|[\s\-.,:;|/\\~_*+]+$""")
    private val spaces = Regex("""\s+""")
    private val repeatedDash = Regex("""(?:\s*-\s*){2,}""")
    private val alnumOnly = Regex("""[^\p{L}\p{M}\p{N}]""")
    private val separators = Regex("""\s+[|/~•·:]{1,2}\s+|\s*\|\s*|\s*//\s*""")
    private val artistSplit = Regex("""(?i)\s*(?:,|&|;|\+|/|\bx\b|\band\b|\bfeat\.?|\bft\.?|\bfeaturing\b|\bwith\b|\bvs\.?)\s*""")

    private val noiseWords = listOf(
        "official", "video", "videos", "audio", "lyric", "lyrics", "lyrical", "visualizer", "visualiser",
        "hd", "hq", "4k", "8k", "1080p", "720p", "480p", "360p", "mv", "m/v", "full song", "full video",
        "full audio", "with lyrics", "free download", "download", "new song", "latest song", "new video",
        "remastered", "remaster", "explicit", "clean", "music video", "song", "songs", "out now", "premiere",
        "vevo", "topic", "karaoke", "status", "whatsapp status", "bass boosted", "slowed", "reverb", "8d",
        "from", "original motion picture soundtrack", "ost", "soundtrack", "title track",
        "অফিসিয়াল", "অফিশিয়াল", "ভিডিও", "অডিও", "লিরিক", "লিরিকস", "লিরিক্স", "গান", "নতুন গান", "ফুল গান", "ফুল ভিডিও"
    )

    private val noisePattern: Regex = run {
        val joined = noiseWords.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) }
        Regex("(?<!$WORD)(?:$joined)(?!$WORD)", RegexOption.IGNORE_CASE)
    }

    private val pureNoisePattern: Regex = run {
        val joined = noiseWords.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) }
        Regex("^(?:(?:$joined)|[\\s\\-.,:;|/&+])+$", RegexOption.IGNORE_CASE)
    }

    private val unknownMarkers = setOf("unknown artist", "unknown title", "unknown album", "<unknown>", "unknown")

    fun isUnknown(value: String?): Boolean {
        val v = value?.trim()?.lowercase().orEmpty()
        return v.isEmpty() || v in unknownMarkers
    }

    fun normalizeKey(value: String): String =
        Normalizer.normalize(value, Normalizer.Form.NFC).lowercase().replace(alnumOnly, "")

    private fun basic(raw: String): String {
        var s = Normalizer.normalize(raw, Normalizer.Form.NFC)
        s = s.replace(invisible, "")
        s = s.replace('_', ' ')
        s = s.replace(dashes, "-")
        s = s.replace('\u00A0', ' ')
        return s.replace(spaces, " ").trim()
    }

    private fun stripBrackets(input: String, removeAll: Boolean): String {
        var s = input
        var previous: String
        do {
            previous = s
            s = brackets.replace(s) { match ->
                val inner = match.value.substring(1, match.value.length - 1)
                if (removeAll || noisePattern.containsMatchIn(inner) || featInline.containsMatchIn(inner)) " " else match.value
            }
        } while (s != previous)
        return s
    }

    private fun tidy(input: String): String {
        var s = input.replace(strayChars, " ")
        s = s.replace(repeatedDash, " - ")
        s = s.replace(spaces, " ")
        s = s.replace(edgePunct, "")
        s = s.replace("()", "").replace("( )", "")
        return s.replace(spaces, " ").trim()
    }

    private fun dropNoiseSegments(input: String): String {
        val segments = input.split(separators).map { it.trim() }.filter { it.isNotEmpty() }
        if (segments.isEmpty()) return input
        val useful = segments.filterNot { pureNoisePattern.matches(it) }
        return (useful.firstOrNull() ?: segments.first())
    }

    private fun dropNoiseDashParts(input: String): String {
        val parts = input.split(" - ").map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size < 2) return input
        val useful = parts.filterNot { pureNoisePattern.matches(it) }
        return (if (useful.isEmpty()) parts else useful).joinToString(" - ")
    }

    private fun lightTidy(input: String): String =
        input.replace(spaces, " ").replace(edgePunct, "").replace(spaces, " ").trim()

    private fun prepare(raw: String, keepBrackets: Boolean, lenient: Boolean = false): String {
        var s = basic(raw)
        s = s.replace(extension, "")
        s = s.replace(url, " ")
        s = s.replace(domain, " ")
        s = s.replace(bitrate, " ")
        s = stripBrackets(s, removeAll = !keepBrackets)
        s = s.replace(leadingTrack, "")
        s = dropNoiseSegments(s)
        s = dropNoiseDashParts(s)
        if (!s.any { it.isWhitespace() } && s.count { it == '-' } >= 2) s = s.replace('-', ' ')
        return if (lenient) lightTidy(s) else tidy(s)
    }

    private fun stripFeat(input: String): String = tidy(input.replace(featTail, ""))

    fun cleanArtist(raw: String?): String? {
        if (isUnknown(raw)) return null
        var s = basic(raw.orEmpty())
        s = s.replace(url, " ").replace(domain, " ")
        s = stripBrackets(s, removeAll = false)
        s = s.replace(Regex("""(?i)\s*-\s*topic$"""), "")
        s = s.replace(Regex("""(?i)\s*vevo$"""), "")
        s = s.replace(Regex("""(?i)\s*official$"""), "")
        s = tidy(s)
        return s.takeIf { it.isNotEmpty() && !isUnknown(it) }
    }

    fun primaryArtist(artist: String?): String? {
        val cleaned = cleanArtist(artist) ?: return null
        val first = cleaned.split(artistSplit).map { it.trim() }.firstOrNull { it.isNotEmpty() }
        return first?.takeIf { it.length >= 2 }
    }

    private fun splitArtistTitle(title: String, artist: String?): Pair<String, String?> {
        val index = title.indexOf(" - ")
        if (index <= 0) return title to artist
        val left = title.substring(0, index).trim()
        val right = title.substring(index + 3).trim()
        if (left.isEmpty() || right.isEmpty()) return title to artist
        if (artist == null) return right to stripFeat(left).ifEmpty { left }
        val artistKey = normalizeKey(artist)
        val leftKey = normalizeKey(left)
        val rightKey = normalizeKey(right)
        return when {
            artistKey.isNotEmpty() && (leftKey == artistKey || leftKey.contains(artistKey) || artistKey.contains(leftKey)) -> right to artist
            artistKey.isNotEmpty() && (rightKey == artistKey || rightKey.contains(artistKey)) -> left to artist
            else -> title to artist
        }
    }

    fun clean(rawTitle: String, rawArtist: String?): Query {
        val artist = cleanArtist(rawArtist)
        val title = prepare(if (isUnknown(rawTitle)) "" else rawTitle, keepBrackets = true)
        val (splitTitle, splitArtist) = splitArtistTitle(title, artist)
        val finalTitle = stripFeat(splitTitle).ifEmpty { splitTitle }
        val finalArtist = splitArtist?.let { cleanArtist(it) }
        return Query(finalTitle, finalArtist)
    }

    fun display(rawTitle: String?, rawArtist: String?): Query {
        val artist = cleanArtist(rawArtist)
        val title = prepare(rawTitle.orEmpty(), keepBrackets = true, lenient = true)
        val (splitTitle, splitArtist) = splitArtistTitle(title, artist)
        return Query(
            title = splitTitle.ifBlank { title },
            artist = splitArtist?.let { cleanArtist(it) } ?: artist
        )
    }

    fun variants(track: Track): List<Query> {
        val rawArtist = track.artist.takeUnless { isUnknown(it) }
        val main = clean(track.title, rawArtist)
        val out = LinkedHashSet<Query>()

        if (main.title.isNotEmpty()) out += main

        val primary = primaryArtist(main.artist ?: rawArtist)
        if (main.title.isNotEmpty() && primary != null && primary != main.artist) {
            out += Query(main.title, primary)
        }

        val bare = prepare(if (isUnknown(track.title)) "" else track.title, keepBrackets = false)
        val (bareTitle, bareArtist) = splitArtistTitle(bare, cleanArtist(rawArtist))
        val finalBare = stripFeat(bareTitle).ifEmpty { bareTitle }
        if (finalBare.isNotEmpty()) {
            out += Query(finalBare, bareArtist ?: primary)
        }

        if (main.title.isNotEmpty()) out += Query(main.title, null)
        if (finalBare.isNotEmpty()) out += Query(finalBare, null)

        return out.toList()
    }

    fun freeText(query: Query): String =
        listOfNotNull(query.title.takeIf { it.isNotEmpty() }, query.artist?.takeIf { it.isNotEmpty() })
            .joinToString(" ")

    fun titlesMatch(candidate: String, wanted: String): Boolean {
        val a = normalizeKey(stripFeat(stripBrackets(basic(candidate), removeAll = true)))
        val b = normalizeKey(wanted)
        if (a.isEmpty() || b.isEmpty()) return false
        return a == b || (minOf(a.length, b.length) >= 4 && (a.contains(b) || b.contains(a)))
    }
}
