package com.sonora.player.data

import android.text.Html
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.min

data class WordDefinition(val partOfSpeech: String, val text: String, val example: String?)

data class WordMeaning(
    val phonetic: String?,
    val translation: String?,
    val definitions: List<WordDefinition>
)

object WordLookup {

    private class Entry(val phonetic: String?, val definitions: List<WordDefinition>)

    fun sourceLanguage(text: String): String {
        for (ch in text) {
            if (!Character.isLetter(ch)) continue
            return when (Character.UnicodeBlock.of(ch)) {
                Character.UnicodeBlock.BENGALI -> "bn"
                Character.UnicodeBlock.DEVANAGARI -> "hi"
                Character.UnicodeBlock.ARABIC -> "ur"
                Character.UnicodeBlock.BASIC_LATIN,
                Character.UnicodeBlock.LATIN_1_SUPPLEMENT,
                Character.UnicodeBlock.LATIN_EXTENDED_A,
                Character.UnicodeBlock.LATIN_EXTENDED_B -> "en"
                else -> "Autodetect"
            }
        }
        return "en"
    }

    suspend fun lookup(word: String, source: String, target: String): WordMeaning = withContext(Dispatchers.IO) {
        val translation = runCatching { translate(word, source, target) }
        val entry = if (source == "en") runCatching { dictionary(word) } else Result.success(Entry(null, emptyList()))
        if (translation.isFailure && entry.isFailure) {
            throw translation.exceptionOrNull() ?: IOException("Lookup failed")
        }
        WordMeaning(
            phonetic = entry.getOrNull()?.phonetic,
            translation = translation.getOrNull(),
            definitions = entry.getOrNull()?.definitions.orEmpty()
        )
    }

    suspend fun translateLine(line: String, source: String, target: String): String? = withContext(Dispatchers.IO) {
        translate(line.take(450), source, target)
    }

    private fun translate(text: String, source: String, target: String): String? {
        if (source == target) return null
        val url = "https://api.mymemory.translated.net/get?q=${enc(text)}&langpair=${enc("$source|$target")}"
        val body = get(url) ?: return null
        val root = JSONObject(body)
        val translated = root.optJSONObject("responseData")?.optString("translatedText").orEmpty()
        if (root.optInt("responseStatus", 200) != 200) return null
        if (translated.isBlank() || translated.startsWith("MYMEMORY WARNING", ignoreCase = true)) return null
        val clean = Html.fromHtml(translated, Html.FROM_HTML_MODE_LEGACY).toString().trim()
        return clean.takeIf { it.isNotBlank() && !it.equals(text, ignoreCase = true) }
    }

    private fun dictionary(word: String): Entry {
        val body = get("https://api.dictionaryapi.dev/api/v2/entries/en/${enc(word.lowercase())}")
            ?: return Entry(null, emptyList())
        val first = JSONArray(body).optJSONObject(0) ?: return Entry(null, emptyList())
        var phonetic = first.optString("phonetic").takeIf { it.isNotBlank() }
        if (phonetic == null) {
            val phonetics = first.optJSONArray("phonetics")
            if (phonetics != null) {
                for (index in 0 until phonetics.length()) {
                    val text = phonetics.optJSONObject(index)?.optString("text").orEmpty()
                    if (text.isNotBlank()) {
                        phonetic = text
                        break
                    }
                }
            }
        }
        val definitions = ArrayList<WordDefinition>()
        val meanings = first.optJSONArray("meanings")
        if (meanings != null) {
            for (index in 0 until min(meanings.length(), 3)) {
                val meaning = meanings.optJSONObject(index) ?: continue
                val definition = meaning.optJSONArray("definitions")?.optJSONObject(0) ?: continue
                val text = definition.optString("definition")
                if (text.isBlank()) continue
                definitions += WordDefinition(
                    partOfSpeech = meaning.optString("partOfSpeech"),
                    text = text,
                    example = definition.optString("example").takeIf { it.isNotBlank() }
                )
            }
        }
        return Entry(phonetic, definitions)
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun get(url: String): String? {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 8000
            connection.readTimeout = 10000
            connection.setRequestProperty("User-Agent", "Sonora/1.0 (Android music player)")
            val code = connection.responseCode
            if (code == 404) return null
            if (code !in 200..299) throw IOException("HTTP $code")
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}
