package com.sonora.player.party

import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

object PartyNetwork {

    fun localAddress(): String? {
        val found = ArrayList<Pair<Int, String>>()
        val interfaces = runCatching { Collections.list(NetworkInterface.getNetworkInterfaces()) }.getOrDefault(emptyList())
        for (item in interfaces) {
            if (!runCatching { item.isUp }.getOrDefault(false) || item.isLoopback) continue
            val name = item.name.lowercase()
            val rank = when {
                name == "wlan0" -> 0
                name.contains("wlan") || name.startsWith("ap") || name.contains("softap") -> 1
                name.startsWith("eth") -> 2
                else -> continue
            }
            for (address in Collections.list(item.inetAddresses)) {
                if (address is Inet4Address && address.isSiteLocalAddress) {
                    address.hostAddress?.let { found += rank to it }
                }
            }
        }
        return found.minByOrNull { it.first }?.second
    }
}
