package com.sonora.player.party

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

data class PartyTrack(val id: Long, val title: String, val artist: String)

data class PartyQueueItem(val track: PartyTrack, val votes: Int, val requested: Boolean)

data class PartySnapshot(val current: PartyTrack?, val playing: Boolean, val upcoming: List<PartyQueueItem>)

data class PartyReply(val ok: Boolean, val message: String)

interface PartyHost {
    fun snapshot(): PartySnapshot
    fun search(query: String): List<PartyTrack>
    fun request(trackId: Long, client: String): PartyReply
    fun vote(trackId: Long, client: String): PartyReply
    fun cover(trackId: Long): ByteArray?
}

class PartyServer(
    private val host: PartyHost,
    private val page: () -> ByteArray,
    val port: Int,
    private val token: String
) {
    private var socket: ServerSocket? = null
    private var pool: ExecutorService? = null

    @Volatile
    private var running = false

    fun start() {
        val server = ServerSocket()
        server.reuseAddress = true
        server.bind(InetSocketAddress(port))
        socket = server
        pool = Executors.newFixedThreadPool(8)
        running = true
        val thread = Thread({ accept(server) }, "party-accept")
        thread.isDaemon = true
        thread.start()
    }

    fun stop() {
        running = false
        runCatching { socket?.close() }
        pool?.shutdownNow()
        socket = null
        pool = null
    }

    private fun accept(server: ServerSocket) {
        while (running) {
            val client = try {
                server.accept()
            } catch (_: IOException) {
                break
            }
            val executor = pool ?: break
            runCatching { executor.execute { serve(client) } }.onFailure { runCatching { client.close() } }
        }
    }

    private fun serve(client: Socket) {
        client.use { connection ->
            runCatching {
                connection.soTimeout = 8000
                val request = readRequest(connection.getInputStream()) ?: return
                val address = (connection.remoteSocketAddress as? InetSocketAddress)?.address?.hostAddress.orEmpty()
                val response = runCatching { route(request, address) }
                    .getOrElse { Response(500, "text/plain; charset=utf-8", "Something went wrong".toByteArray()) }
                val out = connection.getOutputStream()
                out.write(response.bytes())
                out.flush()
            }
        }
    }

    private class Request(val path: String, val query: Map<String, String>)

    private class Response(
        val status: Int,
        val type: String,
        val body: ByteArray,
        val cache: String = "no-store"
    ) {
        fun bytes(): ByteArray {
            val reason = when (status) {
                200 -> "OK"
                403 -> "Forbidden"
                404 -> "Not Found"
                else -> "Error"
            }
            val head = "HTTP/1.1 $status $reason\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\n" +
                "Cache-Control: $cache\r\nConnection: close\r\n\r\n"
            return head.toByteArray(Charsets.ISO_8859_1) + body
        }
    }

    private fun readRequest(input: InputStream): Request? {
        val reader = BufferedReader(InputStreamReader(input, Charsets.ISO_8859_1))
        val line = reader.readLine() ?: return null
        val parts = line.split(' ')
        if (parts.size < 2) return null
        var header = reader.readLine()
        var count = 0
        while (!header.isNullOrEmpty() && count < 64) {
            header = reader.readLine()
            count++
        }
        val target = parts[1]
        val query = target.substringAfter('?', "")
            .split('&')
            .filter { it.isNotEmpty() }
            .associate { pair -> decode(pair.substringBefore('=')) to decode(pair.substringAfter('=', "")) }
        return Request(target.substringBefore('?'), query)
    }

    private fun decode(value: String): String = runCatching { URLDecoder.decode(value, "UTF-8") }.getOrDefault(value)

    private fun route(request: Request, client: String): Response {
        if (request.query["k"] != token) {
            return Response(403, "text/plain; charset=utf-8", "Scan the QR code on the host's phone again.".toByteArray())
        }
        val id = request.query["id"]?.toLongOrNull()
        return when (request.path) {
            "/" -> Response(200, "text/html; charset=utf-8", page())
            "/api/state" -> json(stateJson())
            "/api/search" -> json(searchJson(request.query["q"].orEmpty()))
            "/api/request" -> json(replyJson(id?.let { host.request(it, client) }))
            "/api/vote" -> json(replyJson(id?.let { host.vote(it, client) }))
            "/api/cover" -> {
                val bytes = id?.let { host.cover(it) }
                if (bytes == null) {
                    Response(404, "text/plain", ByteArray(0))
                } else {
                    Response(200, "image/jpeg", bytes, "max-age=3600")
                }
            }
            else -> Response(404, "text/plain", ByteArray(0))
        }
    }

    private fun json(value: Any): Response =
        Response(200, "application/json; charset=utf-8", value.toString().toByteArray(Charsets.UTF_8))

    private fun trackJson(track: PartyTrack): JSONObject =
        JSONObject().put("id", track.id.toString()).put("title", track.title).put("artist", track.artist)

    private fun stateJson(): JSONObject {
        val snapshot = host.snapshot()
        val upcoming = JSONArray()
        snapshot.upcoming.forEach { item ->
            upcoming.put(trackJson(item.track).put("votes", item.votes).put("requested", item.requested))
        }
        return JSONObject()
            .put("current", snapshot.current?.let { trackJson(it) } ?: JSONObject.NULL)
            .put("playing", snapshot.playing)
            .put("upcoming", upcoming)
    }

    private fun searchJson(query: String): JSONArray {
        val array = JSONArray()
        host.search(query).forEach { array.put(trackJson(it)) }
        return array
    }

    private fun replyJson(reply: PartyReply?): JSONObject {
        val safe = reply ?: PartyReply(false, "Something went wrong")
        return JSONObject().put("ok", safe.ok).put("message", safe.message)
    }
}
