package com.sonora.player.party

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import com.sonora.player.PlayerViewModel
import com.sonora.player.R
import com.sonora.player.data.ArtFetcher
import com.sonora.player.data.ArtModel
import com.sonora.player.data.Track
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.ByteArrayOutputStream
import java.security.SecureRandom
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.roundToInt

data class RequestUi(val title: String, val artist: String, val votes: Int)

data class PartyUi(
    val running: Boolean = false,
    val url: String? = null,
    val requests: List<RequestUi> = emptyList(),
    val error: String? = null
)

class PartySession(
    private val vm: PlayerViewModel,
    private val context: Context
) : PartyHost {

    private class RequestInfo(val track: Track, val voters: MutableSet<String>)

    private val handler = Handler(Looper.getMainLooper())
    private val requests = LinkedHashMap<Long, RequestInfo>()
    private val lastRequestAt = ConcurrentHashMap<String, Long>()
    private val covers = LruCache<Long, ByteArray>(60)
    private val page by lazy { context.resources.openRawResource(R.raw.party_page).use { it.readBytes() } }
    private var server: PartyServer? = null

    val state = MutableStateFlow(PartyUi())

    fun start() {
        if (server != null) return
        val address = PartyNetwork.localAddress()
        if (address == null) {
            state.value = PartyUi(error = "Connect to Wi-Fi or turn on your hotspot first.")
            return
        }
        val token = randomToken()
        for (port in PORTS) {
            val candidate = PartyServer(this, { page }, port, token)
            if (runCatching { candidate.start() }.isSuccess) {
                server = candidate
                state.value = PartyUi(running = true, url = "http://$address:$port/?k=$token")
                return
            }
        }
        state.value = PartyUi(error = "Couldn't start the party server. Try again.")
    }

    fun stop() {
        server?.stop()
        server = null
        lastRequestAt.clear()
        onMain { requests.clear() }
        state.value = PartyUi()
    }

    private fun randomToken(): String {
        val letters = "abcdefghjkmnpqrstuvwxyz23456789"
        val random = SecureRandom()
        return buildString { repeat(6) { append(letters[random.nextInt(letters.length)]) } }
    }

    private fun <T> onMain(block: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val task = FutureTask(Callable { block() })
        handler.post(task)
        return task.get(4, TimeUnit.SECONDS)
    }

    private fun partyTrack(track: Track) = PartyTrack(track.id, track.title, track.artist)

    private fun upcomingTracks(): List<Track> {
        val now = vm.now.value
        val index = now.queueIndex
        return if (index in now.queue.indices) now.queue.subList(index + 1, now.queue.size) else emptyList()
    }

    private fun prune() {
        val keep = HashSet<Long>()
        upcomingTracks().forEach { keep += it.id }
        vm.now.value.track?.let { keep += it.id }
        requests.keys.retainAll(keep)
    }

    private fun publish() {
        val list = requests.values
            .map { RequestUi(it.track.title, it.track.artist, it.voters.size) }
            .sortedByDescending { it.votes }
        state.value = state.value.copy(requests = list)
    }

    override fun snapshot(): PartySnapshot = onMain {
        prune()
        val upcoming = upcomingTracks().take(15).map { track ->
            val info = requests[track.id]
            PartyQueueItem(partyTrack(track), info?.voters?.size ?: 0, info != null)
        }
        publish()
        PartySnapshot(vm.now.value.track?.let { partyTrack(it) }, vm.now.value.isPlaying, upcoming)
    }

    override fun search(query: String): List<PartyTrack> {
        val tracks = vm.library.value.tracks
        val text = query.trim().lowercase()
        val matches = if (text.isEmpty()) {
            tracks
        } else {
            tracks.filter {
                it.title.lowercase().contains(text) ||
                    it.artist.lowercase().contains(text) ||
                    it.album.lowercase().contains(text)
            }
        }
        return matches.take(40).map { partyTrack(it) }
    }

    override fun request(trackId: Long, client: String): PartyReply {
        val now = System.currentTimeMillis()
        val last = lastRequestAt[client]
        if (last != null && now - last < COOLDOWN_MS) {
            return PartyReply(false, "Wait a few seconds before the next request")
        }
        val reply = onMain {
            val track = vm.library.value.track(trackId) ?: return@onMain PartyReply(false, "Song not found")
            if (vm.now.value.track?.id == track.id) return@onMain PartyReply(false, "That song is playing right now")
            if (upcomingTracks().any { it.id == track.id }) return@onMain PartyReply(false, "Already in the queue")
            vm.enqueue(track)
            requests[track.id] = RequestInfo(track, mutableSetOf(client))
            publish()
            PartyReply(true, "Added to the queue")
        }
        if (reply.ok) lastRequestAt[client] = now
        return reply
    }

    override fun vote(trackId: Long, client: String): PartyReply = onMain {
        val info = requests[trackId] ?: return@onMain PartyReply(false, "Request this song first")
        if (!info.voters.add(client)) return@onMain PartyReply(false, "You already voted")
        boost(info)
        publish()
        PartyReply(true, "Vote counted")
    }

    private fun boost(info: RequestInfo) {
        val votes = info.voters.size
        if (votes < 2) return
        val now = vm.now.value
        val from = now.queue.indexOfFirst { it.id == info.track.id }
        val current = now.queueIndex
        if (from <= current) return
        val ahead = now.queue.withIndex().count { (index, track) ->
            index > current && track.id != info.track.id && (requests[track.id]?.voters?.size ?: 0) >= votes
        }
        val target = current + 1 + ahead
        if (from > target) vm.moveQueueItem(from, target)
    }

    override fun cover(trackId: Long): ByteArray? {
        covers.get(trackId)?.let { return it }
        val track = vm.library.value.track(trackId) ?: return null
        val bitmap = ArtFetcher.load(context, ArtModel(track.uri, track.albumId, track.id)) ?: return null
        val scale = COVER_SIDE.toFloat() / max(bitmap.width, bitmap.height)
        val scaled = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * scale).roundToInt().coerceAtLeast(1),
                (bitmap.height * scale).roundToInt().coerceAtLeast(1),
                true
            )
        } else {
            bitmap
        }
        val output = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 82, output)
        return output.toByteArray().also { covers.put(trackId, it) }
    }

    private companion object {
        val PORTS = 8080..8090
        const val COOLDOWN_MS = 6000L
        const val COVER_SIDE = 240
    }
}
