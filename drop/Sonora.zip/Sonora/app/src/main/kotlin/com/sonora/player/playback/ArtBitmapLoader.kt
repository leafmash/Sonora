package com.sonora.player.playback

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.util.BitmapLoader
import androidx.media3.datasource.DataSourceBitmapLoader
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.sonora.player.data.ArtFetcher
import com.sonora.player.data.ArtModel
import java.io.IOException
import java.util.concurrent.Callable
import java.util.concurrent.Executors

class ArtBitmapLoader(private val context: Context) : BitmapLoader {

    private val fallback = DataSourceBitmapLoader(context)
    private val executor = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())

    override fun supportsMimeType(mimeType: String): Boolean = fallback.supportsMimeType(mimeType)

    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> = fallback.decodeBitmap(data)

    private var lastUri: Uri? = null
    private var lastBitmap: ListenableFuture<Bitmap>? = null

    @Synchronized
    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> {
        if (uri.scheme != SCHEME) return fallback.loadBitmap(uri)
        val cached = lastBitmap
        if (uri == lastUri && cached != null && (!cached.isDone || runCatching { cached.get() }.isSuccess)) return cached
        val future = executor.submit(
            Callable {
                val trackId = uri.lastPathSegment?.toLongOrNull() ?: throw IOException("Bad artwork uri")
                val mediaId = uri.getQueryParameter("media")?.toLongOrNull() ?: 0L
                val albumId = uri.getQueryParameter("album")?.toLongOrNull() ?: 0L
                val trackUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, mediaId)
                ArtFetcher.load(context, ArtModel(trackUri, albumId, trackId)) ?: throw IOException("No artwork")
            }
        )
        lastUri = uri
        lastBitmap = future
        return future
    }

    companion object {
        const val SCHEME = "sonora-art"

        fun uriFor(trackId: Long, mediaId: Long, albumId: Long): Uri =
            Uri.parse("$SCHEME://track/$trackId?media=$mediaId&album=$albumId")
    }
}
