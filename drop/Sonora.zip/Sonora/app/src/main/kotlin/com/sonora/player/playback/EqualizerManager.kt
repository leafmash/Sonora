package com.sonora.player.playback

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class EqBand(val index: Int, val centerHz: Int, val level: Int)

data class EqState(
    val available: Boolean = false,
    val enabled: Boolean = false,
    val bands: List<EqBand> = emptyList(),
    val minLevel: Int = -1500,
    val maxLevel: Int = 1500,
    val presets: List<String> = emptyList(),
    val currentPreset: Int = -1,
    val bassSupported: Boolean = false,
    val bass: Int = 0,
    val virtualizerSupported: Boolean = false,
    val virtualizer: Int = 0
)

object EqualizerManager {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizerEffect: Virtualizer? = null
    private var prefs: SharedPreferences? = null
    private var enabled = false
    private var preset = -1
    private var bass = 0
    private var surround = 0

    private val mutableState = MutableStateFlow(EqState())

    val state: StateFlow<EqState> = mutableState.asStateFlow()

    fun init(context: Context) {
        val saved = context.getSharedPreferences("sonora_eq", Context.MODE_PRIVATE)
        prefs = saved
        enabled = saved.getBoolean("enabled", false)
        preset = saved.getInt("preset", -1)
        bass = saved.getInt("bass", 0)
        surround = saved.getInt("surround", 0)
    }

    @Synchronized
    fun attach(sessionId: Int) {
        if (sessionId == 0) return
        releaseEffects()
        equalizer = runCatching { Equalizer(0, sessionId) }.getOrNull()
        bassBoost = runCatching { BassBoost(0, sessionId) }.getOrNull()
        virtualizerEffect = runCatching { Virtualizer(0, sessionId) }.getOrNull()

        equalizer?.let { eq ->
            runCatching {
                val range = eq.bandLevelRange
                for (i in 0 until eq.numberOfBands.toInt()) {
                    val level = prefs?.getInt("band_$i", Int.MIN_VALUE) ?: Int.MIN_VALUE
                    if (level != Int.MIN_VALUE) {
                        eq.setBandLevel(i.toShort(), level.coerceIn(range[0].toInt(), range[1].toInt()).toShort())
                    }
                }
                eq.setEnabled(enabled)
            }
        }
        bassBoost?.let { effect ->
            runCatching {
                if (effect.strengthSupported) effect.setStrength(bass.toShort())
                effect.setEnabled(enabled)
            }
        }
        virtualizerEffect?.let { effect ->
            runCatching {
                if (effect.strengthSupported) effect.setStrength(surround.toShort())
                effect.setEnabled(enabled)
            }
        }
        publish()
    }

    fun setEnabled(value: Boolean) {
        enabled = value
        runCatching { equalizer?.setEnabled(value) }
        runCatching { bassBoost?.setEnabled(value) }
        runCatching { virtualizerEffect?.setEnabled(value) }
        prefs?.edit()?.putBoolean("enabled", value)?.apply()
        publish()
    }

    fun setBand(index: Int, level: Int) {
        val eq = equalizer ?: return
        runCatching { eq.setBandLevel(index.toShort(), level.toShort()) }
        preset = -1
        prefs?.edit()?.putInt("band_$index", level)?.putInt("preset", -1)?.apply()
        publish()
    }

    fun usePreset(index: Int) {
        val eq = equalizer ?: return
        runCatching { eq.usePreset(index.toShort()) }
        preset = index
        val editor = prefs?.edit()
        runCatching {
            for (i in 0 until eq.numberOfBands.toInt()) {
                editor?.putInt("band_$i", eq.getBandLevel(i.toShort()).toInt())
            }
        }
        editor?.putInt("preset", index)
        editor?.apply()
        publish()
    }

    fun setBass(value: Int) {
        bass = value
        runCatching { bassBoost?.setStrength(value.toShort()) }
        prefs?.edit()?.putInt("bass", value)?.apply()
        publish()
    }

    fun setVirtualizer(value: Int) {
        surround = value
        runCatching { virtualizerEffect?.setStrength(value.toShort()) }
        prefs?.edit()?.putInt("surround", value)?.apply()
        publish()
    }

    fun release() {
        releaseEffects()
        mutableState.value = EqState()
    }

    private fun releaseEffects() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { virtualizerEffect?.release() }
        equalizer = null
        bassBoost = null
        virtualizerEffect = null
    }

    private fun publish() {
        val eq = equalizer
        if (eq == null) {
            mutableState.value = EqState()
            return
        }
        val range = eq.bandLevelRange
        val bands = (0 until eq.numberOfBands.toInt()).map { i ->
            EqBand(i, eq.getCenterFreq(i.toShort()) / 1000, eq.getBandLevel(i.toShort()).toInt())
        }
        val presets = (0 until eq.numberOfPresets.toInt()).map { eq.getPresetName(it.toShort()) }
        mutableState.value = EqState(
            available = true,
            enabled = enabled,
            bands = bands,
            minLevel = range[0].toInt(),
            maxLevel = range[1].toInt(),
            presets = presets,
            currentPreset = preset,
            bassSupported = bassBoost?.strengthSupported == true,
            bass = bass,
            virtualizerSupported = virtualizerEffect?.strengthSupported == true,
            virtualizer = surround
        )
    }
}
