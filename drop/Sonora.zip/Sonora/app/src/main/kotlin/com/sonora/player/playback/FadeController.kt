package com.sonora.player.playback

import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.min

class FadeController(
    private val player: ExoPlayer,
    private val scope: CoroutineScope
) {
    private var fadeMs = 0L
    private var fadeInActive = false
    private var job: Job? = null

    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            fadeInActive = fadeMs > 0 && reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO
            apply()
        }
    }

    init {
        player.addListener(listener)
    }

    fun setSeconds(seconds: Int) {
        fadeMs = seconds * 1000L
        job?.cancel()
        job = null
        if (fadeMs <= 0L) {
            fadeInActive = false
            player.volume = 1f
            return
        }
        job = scope.launch {
            while (isActive) {
                apply()
                delay(TICK_MS)
            }
        }
    }

    fun release() {
        job?.cancel()
        job = null
        player.removeListener(listener)
        player.volume = 1f
    }

    private fun apply() {
        if (fadeMs <= 0L) return
        val duration = player.duration
        val known = duration != C.TIME_UNSET && duration > 0L
        val window = if (known) min(fadeMs, duration / 2) else fadeMs
        val position = player.currentPosition
        var factor = 1f
        if (fadeInActive) {
            if (position >= window) {
                fadeInActive = false
            } else {
                factor = min(factor, position.toFloat() / window)
            }
        }
        if (known && player.repeatMode != Player.REPEAT_MODE_ONE && player.hasNextMediaItem()) {
            val remaining = duration - position
            if (remaining < window) factor = min(factor, remaining.toFloat() / window)
        }
        val clamped = factor.coerceIn(0f, 1f)
        val target = clamped * clamped
        if (abs(player.volume - target) > 0.01f) player.volume = target
    }

    private companion object {
        const val TICK_MS = 80L
    }
}
