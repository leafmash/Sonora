package com.sonora.player.playback

import android.media.audiofx.DynamicsProcessing
import android.os.Build

object LevelingManager {

    private var effect: DynamicsProcessing? = null
    private var enabled = false

    @Synchronized
    fun attach(sessionId: Int) {
        releaseEffect()
        if (sessionId == 0 || Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return
        effect = build(sessionId)
    }

    @Synchronized
    fun setEnabled(value: Boolean) {
        enabled = value
        runCatching { effect?.setEnabled(value) }
    }

    @Synchronized
    fun release() {
        releaseEffect()
    }

    private fun releaseEffect() {
        runCatching { effect?.release() }
        effect = null
    }

    private fun build(sessionId: Int): DynamicsProcessing? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return null
        return runCatching {
            val config = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                2,
                false,
                0,
                true,
                1,
                false,
                0,
                true
            ).build()
            val processing = DynamicsProcessing(0, sessionId, config)
            val band = DynamicsProcessing.MbcBand(true, 20000f, 20f, 250f, 3f, -28f, 6f, -90f, 1f, 0f, 8f)
            processing.setMbcBandAllChannelsTo(0, band)
            val limiter = DynamicsProcessing.Limiter(true, true, 0, 1f, 60f, 10f, -1f, 0f)
            processing.setLimiterAllChannelsTo(limiter)
            processing.setEnabled(enabled)
            processing
        }.getOrNull()
    }
}
