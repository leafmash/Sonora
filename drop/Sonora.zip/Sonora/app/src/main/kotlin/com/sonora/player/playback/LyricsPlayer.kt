package com.sonora.player.playback

import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import java.util.concurrent.CopyOnWriteArraySet

class LyricsPlayer(player: Player, skipSeconds: Int) : ForwardingPlayer(player) {

    private val listeners = CopyOnWriteArraySet<Player.Listener>()
    private var line: String? = null

    @Volatile
    private var skipMs: Long = skipSeconds * 1000L

    fun setSkipSeconds(seconds: Int) {
        skipMs = seconds * 1000L
    }

    override fun getSeekBackIncrement(): Long = skipMs

    override fun getSeekForwardIncrement(): Long = skipMs

    override fun seekBack() {
        seekByDelta(-skipMs)
    }

    override fun seekForward() {
        seekByDelta(skipMs)
    }

    private fun seekByDelta(deltaMs: Long) {
        if (mediaItemCount == 0) return
        val length = duration
        val target = currentPosition + deltaMs
        val upper = if (length != C.TIME_UNSET && length > 0L) length else Long.MAX_VALUE
        seekTo(target.coerceIn(0L, upper))
    }

    override fun addListener(listener: Player.Listener) {
        super.addListener(listener)
        listeners.add(listener)
    }

    override fun removeListener(listener: Player.Listener) {
        super.removeListener(listener)
        listeners.remove(listener)
    }

    override fun getMediaMetadata(): MediaMetadata {
        val base = super.getMediaMetadata()
        val current = line ?: return base
        return base.buildUpon().setArtist(current).setSubtitle(current).build()
    }

    fun showLine(value: String?) {
        if (value == line) return
        line = value
        val metadata = mediaMetadata
        listeners.forEach { it.onMediaMetadataChanged(metadata) }
    }
}
