package com.sonora.player.playback

import kotlinx.coroutines.flow.MutableStateFlow

object NotificationLyrics {
    val line = MutableStateFlow<String?>(null)
}
