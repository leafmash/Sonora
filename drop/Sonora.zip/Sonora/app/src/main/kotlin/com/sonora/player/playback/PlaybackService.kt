package com.sonora.player.playback

import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.sonora.player.MainActivity
import com.sonora.player.R

class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private var exoPlayer: ExoPlayer? = null

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { prefs, key ->
        when (key) {
            "skip_silence" -> exoPlayer?.setSkipSilenceEnabled(prefs.getBoolean(key.orEmpty(), false))
            "normalize" -> LevelingManager.setEnabled(prefs.getBoolean(key.orEmpty(), false))
        }
    }

    override fun onCreate() {
        super.onCreate()
        setMediaNotificationProvider(
            DefaultMediaNotificationProvider(this).apply { setSmallIcon(R.drawable.ic_notification) }
        )
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                runCatching { EqualizerManager.attach(audioSessionId) }
                runCatching { LevelingManager.attach(audioSessionId) }
            }
        })
        exoPlayer = player
        val prefs = getSharedPreferences("sonora", MODE_PRIVATE)
        player.setSkipSilenceEnabled(prefs.getBoolean("skip_silence", false))
        LevelingManager.setEnabled(prefs.getBoolean("normalize", false))
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)
        runCatching { EqualizerManager.attach(player.audioSessionId) }
        runCatching { LevelingManager.attach(player.audioSessionId) }
        SleepTimer.bind(player)

        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, player)
            .setSessionActivity(openApp)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = session?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        getSharedPreferences("sonora", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefsListener)
        SleepTimer.bind(null)
        EqualizerManager.release()
        LevelingManager.release()
        exoPlayer = null
        session?.let {
            it.player.release()
            it.release()
        }
        session = null
        super.onDestroy()
    }
}
