package com.sonora.player.playback

import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import com.sonora.player.MainActivity
import com.sonora.player.R
import com.sonora.player.data.DefaultSkipSeconds
import com.sonora.player.data.LibraryStore
import com.sonora.player.data.MusicRepository
import com.sonora.player.data.sanitizeSkipSeconds
import com.sonora.player.toMediaItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private var exoPlayer: ExoPlayer? = null
    private var lyricsPlayer: LyricsPlayer? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val store by lazy { LibraryStore(this) }

    private val sessionCallback = object : MediaSession.Callback {
        override fun onPlaybackResumption(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            val result = SettableFuture.create<MediaSession.MediaItemsWithStartPosition>()
            scope.launch {
                val point = runCatching { loadResumePoint() }.getOrNull()
                if (point == null) {
                    result.setException(UnsupportedOperationException("Nothing to resume"))
                } else {
                    result.set(
                        MediaSession.MediaItemsWithStartPosition(
                            point.tracks.map { it.toMediaItem() },
                            point.index,
                            point.positionMs
                        )
                    )
                }
            }
            return result
        }
    }

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { prefs, key ->
        when (key) {
            "skip_silence" -> exoPlayer?.setSkipSilenceEnabled(prefs.getBoolean(key.orEmpty(), false))
            "normalize" -> LevelingManager.setEnabled(prefs.getBoolean(key.orEmpty(), false))
            "skip_seconds" -> lyricsPlayer?.setSkipSeconds(
                sanitizeSkipSeconds(prefs.getInt(key.orEmpty(), DefaultSkipSeconds))
            )
        }
    }

    override fun onCreate() {
        super.onCreate()
        setMediaNotificationProvider(
            DefaultMediaNotificationProvider(this).apply { setSmallIcon(R.drawable.ic_notification) }
        )
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                runCatching { EqualizerManager.attach(audioSessionId) }
                runCatching { LevelingManager.attach(audioSessionId) }
            }

            override fun onEvents(player: Player, events: Player.Events) {
                if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION) ||
                    events.contains(Player.EVENT_TIMELINE_CHANGED) ||
                    (events.contains(Player.EVENT_IS_PLAYING_CHANGED) && !player.isPlaying)
                ) {
                    persistSession()
                }
            }
        })
        exoPlayer = player
        val prefs = getSharedPreferences("sonora", MODE_PRIVATE)
        player.setSkipSilenceEnabled(prefs.getBoolean("skip_silence", false))
        LevelingManager.setEnabled(prefs.getBoolean("normalize", false))
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)
        runCatching { EqualizerManager.attach(player.audioSessionId) }
        runCatching { LevelingManager.attach(player.audioSessionId) }
        SleepTimer.bind(player)

        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val wrapped = LyricsPlayer(
            player,
            sanitizeSkipSeconds(prefs.getInt("skip_seconds", DefaultSkipSeconds))
        )
        lyricsPlayer = wrapped
        scope.launch { NotificationLyrics.line.collect { wrapped.showLine(it) } }
        session = MediaSession.Builder(this, wrapped)
            .setCallback(sessionCallback)
            .setSessionActivity(openApp)
            .setBitmapLoader(ArtBitmapLoader(this))
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    private suspend fun loadResumePoint(): ResumePoint? {
        val saved = store.session() ?: return null
        val library = MusicRepository(this).load(store.settings().hideShort, store.trackEdits(), store.lyricNames())
        return SessionResume.resolve(saved, library)
    }

    private fun persistSession() {
        val player = exoPlayer ?: return
        SessionResume.snapshot(player)?.let { store.saveSession(it) }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        persistSession()
        val player = session?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        persistSession()
        getSharedPreferences("sonora", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefsListener)
        scope.cancel()
        SleepTimer.bind(null)
        EqualizerManager.release()
        LevelingManager.release()
        exoPlayer = null
        lyricsPlayer = null
        session?.let {
            it.player.release()
            it.release()
        }
        session = null
        super.onDestroy()
    }
}
