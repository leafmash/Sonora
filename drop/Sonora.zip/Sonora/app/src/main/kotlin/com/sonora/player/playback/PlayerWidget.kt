package com.sonora.player.playback

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.view.KeyEvent
import android.widget.RemoteViews
import androidx.media3.session.MediaButtonReceiver
import com.sonora.player.MainActivity
import com.sonora.player.R
import java.io.File
import kotlin.math.min

object PlayerWidget {

    private const val PREFS = "sonora_widget"
    private const val ART_FILE = "widget_art.png"
    private const val ART_SIZE = 192
    private const val ART_RADIUS = 30f

    private var title: String? = null
    private var artist: String? = null
    private var playing = false
    private var art: Bitmap? = null
    private var artKey: String? = null
    private var restored = false

    @Synchronized
    fun artKey(): String? = artKey

    @Synchronized
    fun update(context: Context, title: String?, artist: String?, playing: Boolean) {
        restore(context)
        val changed = title != this.title || artist != this.artist
        this.title = title
        this.artist = artist
        this.playing = playing
        if (changed) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("title", title)
                .putString("artist", artist)
                .apply()
        }
        push(context)
    }

    @Synchronized
    fun setArt(context: Context, key: String, bitmap: Bitmap?) {
        restore(context)
        art = bitmap?.let(::rounded)
        artKey = key
        val file = File(context.cacheDir, ART_FILE)
        val saved = art
        if (saved != null) {
            runCatching { file.outputStream().use { saved.compress(Bitmap.CompressFormat.PNG, 100, it) } }
        } else {
            file.delete()
        }
        push(context)
    }

    @Synchronized
    fun markStopped(context: Context) {
        restore(context)
        playing = false
        push(context)
    }

    @Synchronized
    fun push(context: Context) {
        restore(context)
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, PlayerWidgetProvider::class.java))
        if (ids.isEmpty()) return
        manager.updateAppWidget(ids, build(context))
    }

    private fun restore(context: Context) {
        if (restored) return
        restored = true
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        title = prefs.getString("title", null)
        artist = prefs.getString("artist", null)
        val file = File(context.cacheDir, ART_FILE)
        if (file.exists()) art = runCatching { BitmapFactory.decodeFile(file.path) }.getOrNull()
    }

    private fun build(context: Context): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_player)
        views.setTextViewText(R.id.widget_title, title ?: context.getString(R.string.app_name))
        views.setTextViewText(R.id.widget_artist, artist ?: "Tap to start listening")
        val cover = art
        if (cover != null) {
            views.setImageViewBitmap(R.id.widget_art, cover)
        } else {
            views.setImageViewResource(R.id.widget_art, R.mipmap.ic_launcher)
        }
        views.setImageViewResource(R.id.widget_play, if (playing) R.drawable.ic_widget_pause else R.drawable.ic_widget_play)
        views.setContentDescription(R.id.widget_play, if (playing) "Pause" else "Play")
        views.setOnClickPendingIntent(R.id.widget_prev, keyIntent(context, KeyEvent.KEYCODE_MEDIA_PREVIOUS, 1))
        views.setOnClickPendingIntent(R.id.widget_play, keyIntent(context, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 2))
        views.setOnClickPendingIntent(R.id.widget_next, keyIntent(context, KeyEvent.KEYCODE_MEDIA_NEXT, 3))
        views.setOnClickPendingIntent(
            R.id.widget_root,
            PendingIntent.getActivity(
                context,
                0,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        )
        return views
    }

    private fun keyIntent(context: Context, keyCode: Int, requestCode: Int): PendingIntent {
        val intent = Intent(Intent.ACTION_MEDIA_BUTTON)
            .setComponent(ComponentName(context, MediaButtonReceiver::class.java))
            .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun rounded(source: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(ART_SIZE, ART_SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val side = min(source.width, source.height)
        val from = Rect(
            (source.width - side) / 2,
            (source.height - side) / 2,
            (source.width + side) / 2,
            (source.height + side) / 2
        )
        val to = RectF(0f, 0f, ART_SIZE.toFloat(), ART_SIZE.toFloat())
        canvas.drawRoundRect(to, ART_RADIUS, ART_RADIUS, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(source, from, to, paint)
        return output
    }
}
