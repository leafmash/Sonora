package com.sonora.player.playback

import androidx.media3.common.Player
import com.sonora.player.data.Library
import com.sonora.player.data.SavedSession
import com.sonora.player.data.Track

data class ResumePoint(
    val tracks: List<Track>,
    val index: Int,
    val positionMs: Long
)

object SessionResume {

    fun snapshot(player: Player): SavedSession? {
        if (player.mediaItemCount == 0) return null
        val ids = (0 until player.mediaItemCount).map { player.getMediaItemAt(it).mediaId.toLongOrNull() ?: -1L }
        return SavedSession(ids, player.currentMediaItemIndex, player.currentPosition.coerceAtLeast(0L))
    }

    fun resolve(saved: SavedSession, library: Library): ResumePoint? {
        val resolved = saved.ids.mapIndexedNotNull { position, id -> library.track(id)?.let { position to it } }
        if (resolved.isEmpty()) return null
        val start = resolved.indexOfFirst { it.first >= saved.index }.takeIf { it >= 0 } ?: resolved.lastIndex
        val exact = resolved[start].first == saved.index
        return ResumePoint(resolved.map { it.second }, start, if (exact) saved.positionMs else 0L)
    }
}
