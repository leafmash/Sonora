package com.sonora.player.playback

import android.os.SystemClock
import androidx.media3.common.Player
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

object SleepTimer {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null
    private var player: Player? = null
    private val mutableRemaining = MutableStateFlow<Long?>(null)

    val remaining: StateFlow<Long?> = mutableRemaining.asStateFlow()

    fun bind(target: Player?) {
        player = target
        if (target == null) cancel()
    }

    fun start(minutes: Int) {
        job?.cancel()
        val end = SystemClock.elapsedRealtime() + minutes * 60_000L
        job = scope.launch {
            while (true) {
                val left = end - SystemClock.elapsedRealtime()
                if (left <= 0L) break
                mutableRemaining.value = left
                delay(1000)
            }
            player?.pause()
            mutableRemaining.value = null
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        mutableRemaining.value = null
    }
}
