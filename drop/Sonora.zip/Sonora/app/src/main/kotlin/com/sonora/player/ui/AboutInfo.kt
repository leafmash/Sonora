package com.sonora.player.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Language
import androidx.compose.ui.graphics.vector.ImageVector

data class AboutLink(
    val label: String,
    val value: String,
    val uri: String,
    val icon: ImageVector
)

object AboutInfo {
    const val DeveloperName = "Sonora Developer"
    const val DeveloperRole = "Design and development"
    const val DeveloperBio = "Built with care for people who love their music."

    val Links: List<AboutLink> = listOf(
        AboutLink("Email", "you@example.com", "mailto:you@example.com", Icons.Rounded.Email),
        AboutLink("Website", "example.com", "https://example.com", Icons.Rounded.Language)
    )
}
