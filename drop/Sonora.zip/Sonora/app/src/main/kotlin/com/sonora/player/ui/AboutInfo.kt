package com.sonora.player.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Language
import androidx.compose.ui.graphics.vector.ImageVector

data class AboutLink(
    val label: String,
    val value: String,
    val uri: String,
    val icon: ImageVector
)

object AboutInfo {
    const val DeveloperName = "Imora Studio"
    const val DeveloperRole = "Developer"
    const val DeveloperBio = "Built with care for people who love their music."

    val Links: List<AboutLink> = listOf(
        AboutLink("Email", "in.with.imran@gmail.com", "mailto:in.with.imran@gmail.com", Icons.Rounded.Email),
        AboutLink("Website", "inwithimran.vercel.app", "https://inwithimran.vercel.app", Icons.Rounded.Language),
        AboutLink("Facebook", "facebook.com/in.with.imran", "https://www.facebook.com/in.with.imran", Icons.Rounded.Group)
    )
}
