package com.sonora.player.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonora.player.BuildConfig
import com.sonora.player.ui.components.SonoraMark
import com.sonora.player.ui.theme.auroraBackdrop
import com.sonora.player.ui.theme.brandBrush
import java.util.Calendar

private val Features = listOf(
    "Synced lyrics",
    "Equalizer",
    "Bass boost",
    "Volume leveling",
    "Skip silence",
    "Sleep timer",
    "Playlists",
    "Favorites"
)

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val year = remember { Calendar.getInstance().get(Calendar.YEAR) }

    Column(
        Modifier
            .fillMaxSize()
            .auroraBackdrop()
            .statusBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, end = 20.dp, top = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Back")
            }
            Text("About", style = MaterialTheme.typography.titleLarge)
        }

        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Reveal(0) { Hero() }
            Spacer(Modifier.height(28.dp))
            Reveal(1) { AppDetails() }
            Spacer(Modifier.height(20.dp))
            Reveal(2) { FeatureCard() }
            Spacer(Modifier.height(20.dp))
            Reveal(3) { DeveloperCard() }
            Spacer(Modifier.height(28.dp))
            Reveal(4) { Footer(year) }
        }
    }
}

@Composable
private fun Reveal(index: Int, content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(450, delayMillis = index * 90)) +
            slideInVertically(tween(450, delayMillis = index * 90)) { it / 6 }
    ) {
        content()
    }
}

@Composable
private fun Hero() {
    val scheme = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(12.dp))
        Box(
            Modifier
                .size(124.dp)
                .clip(CircleShape)
                .background(scheme.primary.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .size(92.dp)
                    .clip(CircleShape)
                    .background(scheme.surfaceContainerHigh),
                contentAlignment = Alignment.Center
            ) {
                SonoraMark(size = 48.dp, dancing = true)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text(
            text = "Sonora",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = (-0.5).sp
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = "Music player with synced lyrics",
            style = MaterialTheme.typography.bodyMedium,
            color = scheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .clip(CircleShape)
                .background(scheme.primary.copy(alpha = 0.16f))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(
                text = "Version ${BuildConfig.VERSION_NAME}",
                style = MaterialTheme.typography.labelLarge,
                color = scheme.primary
            )
        }
    }
}

@Composable
private fun AppDetails() {
    SectionCard(title = "App details") {
        InfoRow(Icons.Rounded.Info, "Version", "${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})")
        RowDivider()
        InfoRow(Icons.Rounded.Android, "Package", BuildConfig.APPLICATION_ID)
        RowDivider()
        InfoRow(Icons.Rounded.PhoneAndroid, "Running on", "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        RowDivider()
        InfoRow(Icons.Rounded.Lyrics, "Lyrics source", "lrclib.net")
        RowDivider()
        InfoRow(Icons.Rounded.Image, "Cover art source", "iTunes, Deezer")
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FeatureCard() {
    val scheme = MaterialTheme.colorScheme
    SectionCard(title = "What's inside") {
        FlowRow(
            Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Features.forEach { label ->
                Box(
                    Modifier
                        .clip(CircleShape)
                        .background(scheme.primary.copy(alpha = 0.12f))
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(label, style = MaterialTheme.typography.labelLarge, color = scheme.primary)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun DeveloperCard() {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    val brush = brandBrush()
    SectionCard(title = "Developer") {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(brush),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = AboutInfo.DeveloperName.firstOrNull()?.uppercase() ?: "S",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(AboutInfo.DeveloperName, style = MaterialTheme.typography.titleLarge)
                Text(
                    text = AboutInfo.DeveloperRole,
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.primary
                )
            }
        }
        if (AboutInfo.DeveloperBio.isNotBlank()) {
            Text(
                text = AboutInfo.DeveloperBio,
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
        AboutInfo.Links.forEach { link ->
            RowDivider()
            InfoRow(
                icon = link.icon,
                label = link.label,
                value = link.value,
                trailing = Icons.Rounded.OpenInNew,
                onClick = {
                    runCatching {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link.uri)))
                    }
                }
            )
        }
    }
}

@Composable
private fun Footer(year: Int) {
    val scheme = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Made with ", style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
            Icon(Icons.Rounded.Favorite, contentDescription = null, tint = scheme.secondary, modifier = Modifier.size(14.dp))
            Text(" for music lovers", style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = "© $year ${AboutInfo.DeveloperName}",
            style = MaterialTheme.typography.labelMedium,
            color = scheme.onSurfaceVariant.copy(alpha = 0.7f)
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth()) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelMedium,
            letterSpacing = 1.6.sp,
            color = scheme.primary,
            modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
        )
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.large,
            color = scheme.surfaceContainerHigh.copy(alpha = 0.85f)
        ) {
            Column(Modifier.padding(vertical = 8.dp)) { content() }
        }
    }
}

@Composable
private fun InfoRow(
    icon: ImageVector,
    label: String,
    value: String,
    trailing: ImageVector? = null,
    onClick: (() -> Unit)? = null
) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(scheme.primary.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = scheme.primary, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.bodyLarge)
        }
        if (trailing != null) {
            Icon(trailing, contentDescription = null, tint = scheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun RowDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(start = 68.dp, end = 16.dp),
        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
    )
}
