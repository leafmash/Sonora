package com.sonora.player.ui

import android.graphics.drawable.BitmapDrawable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.palette.graphics.Palette
import coil.imageLoader
import coil.request.ImageRequest
import com.sonora.player.data.ArtModel
import com.sonora.player.data.CoverStore
import com.sonora.player.data.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ArtColors(val deep: Color, val bright: Color)

@Composable
fun rememberArtColors(track: Track?): State<ArtColors?> {
    val context = LocalContext.current
    val stamps by CoverStore.stamps.collectAsState()
    val cover = track?.let { stamps[it.id] } ?: 0L
    return produceState<ArtColors?>(initialValue = null, track?.id, cover) {
        value = if (track == null) {
            null
        } else {
            withContext(Dispatchers.Default) {
                val request = ImageRequest.Builder(context)
                    .data(ArtModel(track.uri, track.albumId, track.id, cover))
                    .size(200)
                    .allowHardware(false)
                    .build()
                val bitmap = (context.imageLoader.execute(request).drawable as? BitmapDrawable)?.bitmap
                bitmap?.let { source ->
                    val palette = Palette.from(source).maximumColorCount(16).generate()
                    val deep = palette.getDarkVibrantColor(0).takeIf { it != 0 }
                        ?: palette.getVibrantColor(0).takeIf { it != 0 }
                        ?: palette.getDarkMutedColor(0).takeIf { it != 0 }
                        ?: palette.getDominantColor(0).takeIf { it != 0 }
                    val bright = palette.getVibrantColor(0).takeIf { it != 0 }
                        ?: palette.getLightVibrantColor(0).takeIf { it != 0 }
                        ?: palette.getMutedColor(0).takeIf { it != 0 }
                        ?: deep
                    deep?.let { ArtColors(Color(it), Color(bright ?: it)) }
                }
            }
        }
    }
}
