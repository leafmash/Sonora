package com.sonora.player.ui

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.AbsoluteRoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.onLongClick
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sonora.player.PlayerViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

private const val SkipWindowMs = 700L
private const val SkipHoldMs = 650L
private const val SwipeCommitFraction = 0.25f

@Stable
private class SkipFeedback {
    var side by mutableIntStateOf(0)
        private set
    var seconds by mutableIntStateOf(0)
        private set
    val alpha = Animatable(0f)
    private var lastAt = 0L
    private var job: Job? = null

    fun chains(direction: Int, at: Long): Boolean =
        side == direction && at - lastAt in 0L..SkipWindowMs

    fun register(direction: Int, step: Int, scope: CoroutineScope) {
        val now = SystemClock.uptimeMillis()
        seconds = if (chains(direction, now)) seconds + step else step
        side = direction
        lastAt = now
        job?.cancel()
        job = scope.launch {
            alpha.snapTo(1f)
            delay(SkipHoldMs)
            alpha.animateTo(0f, tween(260))
        }
    }
}

@Composable
internal fun CoverGestureBox(
    vm: PlayerViewModel,
    skipSeconds: Int,
    playing: Boolean,
    onLongPress: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val feedback = remember { SkipFeedback() }
    var dragX by remember { mutableFloatStateOf(0f) }
    var widthPx by remember { mutableFloatStateOf(1f) }
    var settleJob by remember { mutableStateOf<Job?>(null) }
    val step by rememberUpdatedState(skipSeconds)
    val currentLongPress by rememberUpdatedState(onLongPress)

    val skip: (Int) -> Unit = { direction ->
        feedback.register(direction, step, scope)
        vm.seekBy(direction * step * 1000L)
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }
    val currentSkip by rememberUpdatedState(skip)

    val settle: () -> Unit = {
        settleJob?.cancel()
        settleJob = scope.launch {
            animate(
                initialValue = dragX,
                targetValue = 0f,
                animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)
            ) { value, _ -> dragX = value }
        }
    }
    val currentSettle by rememberUpdatedState(settle)

    Box(
        modifier
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .semantics {
                contentDescription = "Album cover"
                onClick(label = if (playing) "Pause" else "Play") {
                    vm.togglePlay()
                    true
                }
                onLongClick(label = "Change cover art") {
                    currentLongPress()
                    true
                }
                customActions = listOf(
                    CustomAccessibilityAction(if (playing) "Pause" else "Play") {
                        vm.togglePlay()
                        true
                    },
                    CustomAccessibilityAction("Seek back $skipSeconds seconds") {
                        vm.seekBy(-skipSeconds * 1000L)
                        true
                    },
                    CustomAccessibilityAction("Seek forward $skipSeconds seconds") {
                        vm.seekBy(skipSeconds * 1000L)
                        true
                    },
                    CustomAccessibilityAction("Next song") {
                        vm.next()
                        true
                    },
                    CustomAccessibilityAction("Previous song") {
                        vm.previous()
                        true
                    }
                )
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { offset ->
                        val direction = if (offset.x < size.width / 2f) -1 else 1
                        val tappedAt = SystemClock.uptimeMillis() - viewConfiguration.doubleTapTimeoutMillis
                        if (feedback.chains(direction, tappedAt)) {
                            currentSkip(direction)
                        } else {
                            vm.togglePlay()
                        }
                    },
                    onDoubleTap = { offset ->
                        currentSkip(if (offset.x < size.width / 2f) -1 else 1)
                    },
                    onLongPress = { currentLongPress() }
                )
            }
            .pointerInput(Unit) {
                val tracker = VelocityTracker()
                detectHorizontalDragGestures(
                    onDragStart = {
                        settleJob?.cancel()
                        tracker.resetTracking()
                    },
                    onDragEnd = {
                        val velocity = tracker.calculateVelocity().x
                        val distance = dragX
                        val byDistance = abs(distance) > widthPx * SwipeCommitFraction
                        val byFling = abs(velocity) > 900.dp.toPx() &&
                            abs(distance) > 24.dp.toPx() &&
                            velocity * distance > 0f
                        if (byDistance || byFling) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            if (distance < 0f) vm.next() else vm.previous()
                        }
                        currentSettle()
                    },
                    onDragCancel = { currentSettle() },
                    onHorizontalDrag = { change, amount ->
                        tracker.addPosition(change.uptimeMillis, change.position)
                        change.consume()
                        dragX = (dragX + amount).coerceIn(-widthPx, widthPx)
                    }
                )
            }
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val progress = (abs(dragX) / widthPx).coerceIn(0f, 1f)
                    val shrink = 1f - 0.08f * progress
                    translationX = dragX
                    alpha = 1f - 0.45f * progress
                    scaleX = shrink
                    scaleY = shrink
                },
            content = content
        )
        SkipOverlay(feedback)
    }
}

@Composable
private fun BoxScope.SkipOverlay(feedback: SkipFeedback) {
    val left = feedback.side < 0
    val shape = if (left) {
        AbsoluteRoundedCornerShape(26.dp, 14.dp, 14.dp, 26.dp)
    } else {
        AbsoluteRoundedCornerShape(14.dp, 26.dp, 26.dp, 14.dp)
    }
    Box(
        Modifier
            .align(if (left) AbsoluteAlignment.CenterLeft else AbsoluteAlignment.CenterRight)
            .fillMaxWidth(0.5f)
            .fillMaxHeight()
            .padding(6.dp)
            .graphicsLayer { alpha = feedback.alpha.value }
            .clip(shape)
            .background(Color.White.copy(alpha = 0.22f))
            .clearAndSetSemantics { },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = if (left) Icons.Rounded.FastRewind else Icons.Rounded.FastForward,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(40.dp)
            )
            Text(
                text = "${if (left) "-" else "+"}${feedback.seconds}s",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
