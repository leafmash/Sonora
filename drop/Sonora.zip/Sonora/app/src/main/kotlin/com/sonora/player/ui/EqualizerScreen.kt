package com.sonora.player.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.playback.EqState
import com.sonora.player.playback.EqualizerManager
import com.sonora.player.ui.components.EmptyState

@Composable
fun EqualizerScreen(onBack: () -> Unit) {
    val state by EqualizerManager.state.collectAsStateWithLifecycle()

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, end = 20.dp, top = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Back")
            }
            Text("Equalizer", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            Switch(
                checked = state.enabled,
                onCheckedChange = { EqualizerManager.setEnabled(it) },
                enabled = state.available
            )
        }

        if (!state.available) {
            EmptyState(
                icon = Icons.Rounded.Equalizer,
                title = "Equalizer unavailable",
                message = "Start playing a song first, or your device may not support audio effects."
            )
        } else {
            EqualizerBody(state)
        }
    }
}

@Composable
private fun EqualizerBody(state: EqState) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)
    ) {
        if (state.presets.isNotEmpty()) {
            item {
                Text(
                    text = "Presets",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(state.presets) { index, name ->
                        FilterChip(
                            selected = state.currentPreset == index,
                            onClick = {
                                if (!state.enabled) EqualizerManager.setEnabled(true)
                                EqualizerManager.usePreset(index)
                            },
                            label = { Text(name) }
                        )
                    }
                }
            }
        }
        item {
            Text(
                text = "Bands",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 20.dp, bottom = 4.dp)
            )
        }
        items(state.bands, key = { it.index }) { band ->
            val hz = band.centerHz
            val label = if (hz >= 1000) "%.1f kHz".format(hz / 1000f) else "$hz Hz"
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(label, style = MaterialTheme.typography.labelLarge, modifier = Modifier.width(72.dp))
                Slider(
                    value = band.level.toFloat(),
                    onValueChange = {
                        if (!state.enabled) EqualizerManager.setEnabled(true)
                        EqualizerManager.setBand(band.index, it.toInt())
                    },
                    valueRange = state.minLevel.toFloat()..state.maxLevel.toFloat(),
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "%+.1f dB".format(band.level / 100f),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.width(64.dp)
                )
            }
        }
        if (state.bassSupported) {
            item {
                EffectSlider("Bass boost", state.bass) {
                    if (!state.enabled) EqualizerManager.setEnabled(true)
                    EqualizerManager.setBass(it)
                }
            }
        }
        if (state.virtualizerSupported) {
            item {
                EffectSlider("Surround", state.virtualizer) {
                    if (!state.enabled) EqualizerManager.setEnabled(true)
                    EqualizerManager.setVirtualizer(it)
                }
            }
        }
    }
}

@Composable
private fun EffectSlider(title: String, value: Int, onChange: (Int) -> Unit) {
    Column(Modifier.padding(top = 20.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(
                text = "${value / 10}%",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.toInt()) },
            valueRange = 0f..1000f
        )
    }
}
