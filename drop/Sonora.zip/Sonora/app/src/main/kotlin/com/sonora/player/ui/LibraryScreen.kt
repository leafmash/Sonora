package com.sonora.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import com.sonora.player.ui.components.BrandButton
import com.sonora.player.ui.components.PillTabs
import com.sonora.player.ui.components.ScreenHeader
import com.sonora.player.ui.theme.brandBrush
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.Artist
import com.sonora.player.data.Library
import com.sonora.player.data.Folder
import com.sonora.player.data.Route
import com.sonora.player.data.SortOrder
import com.sonora.player.data.Track
import com.sonora.player.ui.components.AlbumCard
import com.sonora.player.ui.components.Artwork
import com.sonora.player.ui.components.EmptyState
import com.sonora.player.ui.components.TrackList

@Composable
fun LibraryScreen(vm: PlayerViewModel, onAddToPlaylist: (Track) -> Unit) {
    val library by vm.library.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val loadError by vm.loadError.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var section by rememberSaveable { mutableIntStateOf(0) }
    var sortMenu by remember { mutableStateOf(false) }

    val sorted = remember(library, settings.sort) {
        when (settings.sort) {
            SortOrder.Title -> library.tracks
            SortOrder.Artist -> library.tracks.sortedBy { it.artist.lowercase() }
            SortOrder.Album -> library.tracks.sortedBy { it.album.lowercase() }
            SortOrder.Recent -> library.tracks.sortedByDescending { it.dateAdded }
            SortOrder.Duration -> library.tracks.sortedByDescending { it.durationMs }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        ScreenHeader(title = "Library", kicker = greeting()) {
            if (section == 0) {
                Box {
                    IconButton(onClick = { sortMenu = true }) {
                        Icon(Icons.Rounded.Sort, contentDescription = "Sort")
                    }
                    DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                        SortOrder.entries.forEach { order ->
                            DropdownMenuItem(
                                text = { Text(order.label) },
                                trailingIcon = {
                                    if (settings.sort == order) Icon(Icons.Rounded.Check, contentDescription = null)
                                },
                                onClick = {
                                    sortMenu = false
                                    vm.updateSettings { it.copy(sort = order) }
                                }
                            )
                        }
                    }
                }
            }
            IconButton(onClick = vm::refresh) {
                Icon(Icons.Rounded.Refresh, contentDescription = "Rescan")
            }
        }

        PillTabs(
            labels = listOf("Songs", "Albums", "Artists", "Folders"),
            selected = section,
            onSelect = { section = it },
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
        )

        when {
            library.tracks.isEmpty() && loading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            library.tracks.isEmpty() -> {
                EmptyState(
                    icon = Icons.Rounded.LibraryMusic,
                    title = "No music found",
                    message = loadError ?: "Add some audio files to your device, then tap rescan."
                )
            }
            section == 0 -> SongsSection(sorted, vm, onAddToPlaylist)
            section == 1 -> AlbumsSection(library, vm)
            section == 2 -> ArtistsSection(library, vm)
            else -> FoldersSection(library, vm)
        }
    }
}

@Composable
private fun SongsSection(tracks: List<Track>, vm: PlayerViewModel, onAddToPlaylist: (Track) -> Unit) {
    TrackList(
        tracks = tracks,
        vm = vm,
        onAddToPlaylist = onAddToPlaylist,
        header = {
            item { LibraryHero(tracks.size, onPlay = { vm.playTracks(tracks, 0) }, onShuffle = { vm.shufflePlay(tracks) }) }
        }
    )
}

@Composable
private fun LibraryHero(count: Int, onPlay: () -> Unit, onShuffle: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(
                Brush.linearGradient(
                    listOf(scheme.primary.copy(alpha = 0.3f), scheme.secondary.copy(alpha = 0.22f), scheme.tertiary.copy(alpha = 0.18f))
                )
            )
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = "$count",
                style = MaterialTheme.typography.headlineLarge.copy(brush = brandBrush())
            )
            Text(
                text = "songs ready to play",
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onSurfaceVariant
            )
        }
        FilledTonalIconButton(onClick = onShuffle) {
            Icon(Icons.Rounded.Shuffle, contentDescription = "Shuffle")
        }
        Spacer(Modifier.width(10.dp))
        BrandButton(text = "Play", icon = Icons.Rounded.PlayArrow, onClick = onPlay)
    }
}

@Composable
private fun AlbumsSection(library: Library, vm: PlayerViewModel) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(library.albums, key = { it.id }) { album ->
            AlbumCard(album, onClick = { vm.open(Route.AlbumRoute(album.id)) })
        }
    }
}

@Composable
private fun ArtistsSection(library: Library, vm: PlayerViewModel) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        items(library.artists, key = { it.name }) { artist ->
            ArtistRow(artist, onClick = { vm.open(Route.ArtistRoute(artist.name)) })
        }
    }
}

@Composable
private fun FoldersSection(library: Library, vm: PlayerViewModel) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        items(library.folders, key = { it.path }) { folder ->
            FolderRow(folder, onClick = { vm.open(Route.FolderRoute(folder.path)) })
        }
    }
}

@Composable
private fun FolderRow(folder: Folder, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(scheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Folder, contentDescription = null, tint = scheme.onPrimaryContainer)
        }
        Column(
            Modifier
                .weight(1f)
                .padding(start = 16.dp)
        ) {
            Text(
                text = folder.name,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${folder.tracks.size} songs  ·  ${folder.location}",
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ArtistRow(artist: Artist, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Artwork(artist.tracks.first(), Modifier.size(56.dp), CircleShape)
        Column(
            Modifier
                .weight(1f)
                .padding(start = 16.dp)
        ) {
            Text(
                text = artist.name,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${artist.tracks.size} songs  ·  ${artist.albumCount} albums",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
