package com.sonora.player.ui

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.FileProvider
import androidx.core.graphics.ColorUtils
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class CardStyle(val label: String) {
    Aurora("Aurora"),
    Poster("Poster"),
    Glass("Glass"),
    Paper("Paper")
}

enum class CardRatio(val label: String, val w: Int, val h: Int) {
    Post("Post 4:5", 4, 5),
    Story("Story 9:16", 9, 16),
    Square("Square 1:1", 1, 1);

    val aspect: Float get() = w.toFloat() / h
}

object LyricsCardRenderer {

    fun render(
        cover: Bitmap?,
        colors: ArtColors?,
        title: String,
        artist: String,
        lines: List<String>,
        style: CardStyle,
        ratio: CardRatio,
        width: Int
    ): Bitmap {
        val height = (width / ratio.aspect).roundToInt()
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val painter = CardPainter(
            canvas = Canvas(bitmap),
            w = width.toFloat(),
            h = height.toFloat(),
            cover = cover,
            deep = colors?.deep?.toArgb() ?: 0xFF1B1A4B.toInt(),
            bright = colors?.bright?.toArgb() ?: 0xFFFFB547.toInt(),
            title = title,
            artist = artist,
            text = lines.joinToString("\n")
        )
        when (style) {
            CardStyle.Aurora -> painter.aurora()
            CardStyle.Poster -> painter.poster()
            CardStyle.Glass -> painter.glass()
            CardStyle.Paper -> painter.paper()
        }
        return bitmap
    }
}

private class CardPainter(
    private val canvas: Canvas,
    private val w: Float,
    private val h: Float,
    private val cover: Bitmap?,
    private val deep: Int,
    private val bright: Int,
    private val title: String,
    private val artist: String,
    private val text: String
) {
    private val u = w / 1080f
    private val bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    private val serif = Typeface.create(Typeface.SERIF, Typeface.BOLD)
    private val smooth = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    private fun dark(color: Int, amount: Float) = ColorUtils.blendARGB(color, Color.BLACK, amount)

    private fun light(color: Int, amount: Float) = ColorUtils.blendARGB(color, Color.WHITE, amount)

    private fun alpha(color: Int, value: Float) = ColorUtils.setAlphaComponent(color, (value * 255f).roundToInt().coerceIn(0, 255))

    private fun cropRect(bitmap: Bitmap, aspect: Float): Rect {
        val bw = bitmap.width.toFloat()
        val bh = bitmap.height.toFloat()
        return if (bw / bh > aspect) {
            val cropW = (bh * aspect).roundToInt()
            val x = ((bw - cropW) / 2f).roundToInt()
            Rect(x, 0, x + cropW, bitmap.height)
        } else {
            val cropH = (bw / aspect).roundToInt()
            val y = ((bh - cropH) / 2f).roundToInt()
            Rect(0, y, bitmap.width, y + cropH)
        }
    }

    private fun softened(source: Bitmap, aspect: Float): Bitmap {
        val crop = cropRect(source, aspect)
        val part = Bitmap.createBitmap(source, crop.left, crop.top, crop.width(), crop.height())
        val smallW = 24
        val smallH = max(1, (smallW / aspect).roundToInt())
        val small = Bitmap.createScaledBitmap(part, smallW, smallH, true)
        return Bitmap.createScaledBitmap(small, smallW * 6, smallH * 6, true)
    }

    private fun drawSoft(target: RectF) {
        val source = cover ?: return
        val soft = softened(source, target.width() / target.height())
        canvas.drawBitmap(soft, null, target, smooth)
    }

    private fun drawSharp(target: RectF) {
        val source = cover ?: return
        canvas.drawBitmap(source, cropRect(source, target.width() / target.height()), target, smooth)
    }

    private fun glow(cx: Float, cy: Float, radius: Float, color: Int, strength: Float) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = RadialGradient(cx, cy, radius, alpha(color, strength), alpha(color, 0f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
    }

    private fun verticalGradient(top: Int, bottom: Int) {
        val paint = Paint()
        paint.shader = LinearGradient(0f, 0f, 0f, h, top, bottom, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
    }

    private fun shadow(rect: RectF, radius: Float, blur: Float, dy: Float, strength: Float) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.BLACK
        paint.setShadowLayer(blur, 0f, dy, alpha(Color.BLACK, strength))
        canvas.drawRoundRect(rect, radius, radius, paint)
    }

    private fun drawCover(rect: RectF, radius: Float) {
        val save = canvas.save()
        val path = Path()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)
        canvas.clipPath(path)
        if (cover != null) {
            canvas.drawBitmap(cover, cropRect(cover, rect.width() / rect.height()), rect, smooth)
        } else {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            paint.shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom, bright, deep, Shader.TileMode.CLAMP)
            canvas.drawRect(rect, paint)
            val note = textPaint(Color.WHITE, rect.height() * 0.5f, bold)
            note.textAlign = Paint.Align.CENTER
            canvas.drawText("\u266A", rect.centerX(), rect.centerY() + rect.height() * 0.17f, note)
        }
        canvas.restoreToCount(save)
    }

    private fun textPaint(color: Int, size: Float, face: Typeface, spacing: Float = 0f): TextPaint {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        paint.color = color
        paint.textSize = size
        paint.typeface = face
        paint.letterSpacing = spacing
        return paint
    }

    private fun layout(
        value: String,
        paint: TextPaint,
        width: Int,
        align: Layout.Alignment,
        maxLines: Int = Int.MAX_VALUE
    ): StaticLayout {
        val builder = StaticLayout.Builder.obtain(value, 0, value.length, paint, width)
            .setAlignment(align)
            .setLineSpacing(0f, 1.14f)
            .setIncludePad(false)
        if (maxLines != Int.MAX_VALUE) builder.setMaxLines(maxLines).setEllipsize(TextUtils.TruncateAt.END)
        return builder.build()
    }

    private fun fit(
        paint: TextPaint,
        width: Int,
        maxHeight: Float,
        maxSize: Float,
        minSize: Float,
        align: Layout.Alignment
    ): StaticLayout {
        var size = maxSize
        while (true) {
            paint.textSize = size
            val result = layout(text, paint, width, align)
            if (result.height <= maxHeight || size <= minSize) return result
            size -= 2f
        }
    }

    private fun draw(layout: StaticLayout, x: Float, y: Float) {
        val save = canvas.save()
        canvas.translate(x, y)
        layout.draw(canvas)
        canvas.restoreToCount(save)
    }

    private fun quote(x: Float, baseline: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.LEFT) {
        val paint = textPaint(color, size, serif)
        paint.textAlign = align
        canvas.drawText("\u201C", x, baseline, paint)
    }

    private fun brand(color: Int, x: Float, baseline: Float, align: Paint.Align) {
        val paint = textPaint(color, 26f * u, bold, 0.3f)
        paint.textAlign = align
        canvas.drawText("SONORA", x, baseline, paint)
    }

    private fun accentBar(x: Float, y: Float, width: Float) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = bright
        canvas.drawRoundRect(RectF(x, y, x + width, y + 8f * u), 4f * u, 4f * u, paint)
    }

    private fun footer(x: Float, bottom: Float, titleColor: Int, subColor: Int, round: Boolean) {
        val thumb = 128f * u
        val top = bottom - thumb
        val rect = RectF(x, top, x + thumb, bottom)
        shadow(rect, if (round) thumb / 2f else 30f * u, 24f * u, 8f * u, 0.35f)
        drawCover(rect, if (round) thumb / 2f else 30f * u)
        val left = x + thumb + 28f * u
        val width = (w - left - x).toInt()
        val titleLayout = layout(title, textPaint(titleColor, 42f * u, bold), width, Layout.Alignment.ALIGN_NORMAL, 1)
        val artistLayout = layout(artist, textPaint(subColor, 32f * u, Typeface.DEFAULT), width, Layout.Alignment.ALIGN_NORMAL, 1)
        val block = titleLayout.height + 8f * u + artistLayout.height
        val y = top + (thumb - block) / 2f
        draw(titleLayout, left, y)
        draw(artistLayout, left, y + titleLayout.height + 8f * u)
    }

    private fun centeredInfo(top: Float, titleColor: Int, subColor: Int): Float {
        val width = (w - 168f * u).toInt()
        val titleLayout = layout(title, textPaint(titleColor, 42f * u, bold), width, Layout.Alignment.ALIGN_CENTER, 1)
        val artistLayout = layout(artist, textPaint(subColor, 32f * u, Typeface.DEFAULT), width, Layout.Alignment.ALIGN_CENTER, 1)
        draw(titleLayout, 84f * u, top)
        draw(artistLayout, 84f * u, top + titleLayout.height + 8f * u)
        return top + titleLayout.height + 8f * u + artistLayout.height
    }

    fun aurora() {
        val base = dark(deep, 0.5f)
        canvas.drawColor(base)
        drawSoft(RectF(0f, 0f, w, h))
        verticalGradient(alpha(deep, 0.18f), alpha(base, 0.9f))
        glow(w * 0.95f, 0f, w * 0.95f, bright, 0.5f)
        glow(0f, h, w * 0.9f, bright, 0.28f)
        val pad = 84f * u
        brand(alpha(Color.WHITE, 0.6f), w - pad, pad + 26f * u, Paint.Align.RIGHT)
        val top = pad + 170f * u
        val bottom = h - pad - 128f * u - 90f * u
        val body = fit(textPaint(Color.WHITE, 0f, bold), (w - pad * 2).toInt(), bottom - top, 96f * u, 38f * u, Layout.Alignment.ALIGN_NORMAL)
        val textY = top + max(0f, (bottom - top - body.height) / 2f)
        quote(pad - 8f * u, textY + 0.3f * 280f * u, 280f * u, bright)
        draw(body, pad, textY)
        accentBar(pad, h - pad - 128f * u - 52f * u, 96f * u)
        footer(pad, h - pad, Color.WHITE, alpha(Color.WHITE, 0.72f), false)
    }

    fun poster() {
        val base = dark(deep, 0.55f)
        verticalGradient(dark(deep, 0.12f), base)
        glow(w / 2f, h * 0.22f, w * 0.85f, bright, 0.38f)
        val pad = 84f * u
        val size = min(w * 0.56f, h * 0.34f)
        val rect = RectF((w - size) / 2f, pad * 1.1f, (w + size) / 2f, pad * 1.1f + size)
        shadow(rect, 52f * u, 60f * u, 24f * u, 0.5f)
        drawCover(rect, 52f * u)
        val infoBottom = centeredInfo(rect.bottom + 52f * u, Color.WHITE, alpha(Color.WHITE, 0.7f))
        accentBar((w - 72f * u) / 2f, infoBottom + 40f * u, 72f * u)
        val top = infoBottom + 40f * u + 8f * u + 44f * u
        val bottom = h - 150f * u
        val body = fit(textPaint(Color.WHITE, 0f, bold), (w - pad * 2).toInt(), bottom - top, 78f * u, 32f * u, Layout.Alignment.ALIGN_CENTER)
        draw(body, pad, top + max(0f, (bottom - top - body.height) / 2f))
        brand(alpha(Color.WHITE, 0.55f), w / 2f, h - 64f * u, Paint.Align.CENTER)
    }

    fun glass() {
        val base = dark(deep, 0.5f)
        canvas.drawColor(base)
        if (cover != null) {
            drawSharp(RectF(0f, 0f, w, h))
        } else {
            verticalGradient(bright, deep)
        }
        val shade = Paint()
        shade.color = alpha(Color.BLACK, 0.34f)
        canvas.drawRect(0f, 0f, w, h, shade)
        val pad = 72f * u
        val cardPad = 64f * u
        val quoteSpace = 110f * u
        val maxText = min(h * 0.55f, h - (cardPad * 2 + quoteSpace) - 424f * u)
        val body = fit(
            textPaint(Color.WHITE, 0f, bold),
            (w - pad * 2 - cardPad * 2).toInt(),
            maxText,
            84f * u,
            34f * u,
            Layout.Alignment.ALIGN_CENTER
        )
        val cardHeight = body.height + cardPad * 2 + quoteSpace
        val cardTop = (h - (cardHeight + 156f * u)) / 2f - 20f * u
        val card = RectF(pad, cardTop, w - pad, cardTop + cardHeight)
        val radius = 56f * u
        val save = canvas.save()
        val clip = Path()
        clip.addRoundRect(card, radius, radius, Path.Direction.CW)
        canvas.clipPath(clip)
        if (cover != null) drawSoft(RectF(0f, 0f, w, h)) else canvas.drawColor(alpha(deep, 0.6f))
        val frost = Paint()
        frost.color = alpha(Color.WHITE, 0.17f)
        canvas.drawRect(card, frost)
        canvas.restoreToCount(save)
        val edge = Paint(Paint.ANTI_ALIAS_FLAG)
        edge.style = Paint.Style.STROKE
        edge.strokeWidth = 3f * u
        edge.color = alpha(Color.WHITE, 0.38f)
        canvas.drawRoundRect(card, radius, radius, edge)
        quote(w / 2f, cardTop + cardPad * 0.4f + 130f * u, 170f * u, light(bright, 0.25f), Paint.Align.CENTER)
        draw(body, pad + cardPad, cardTop + cardPad + quoteSpace * 0.85f)
        centeredInfo(card.bottom + 56f * u, Color.WHITE, alpha(Color.WHITE, 0.78f))
        brand(alpha(Color.WHITE, 0.6f), w / 2f, h - 64f * u, Paint.Align.CENTER)
    }

    fun paper() {
        val background = ColorUtils.blendARGB(0xFFF7F2EA.toInt(), bright, 0.1f)
        canvas.drawColor(background)
        val ink = dark(deep, 0.35f)
        val disc = Paint(Paint.ANTI_ALIAS_FLAG)
        disc.color = alpha(bright, 0.18f)
        canvas.drawCircle(w * 0.96f, h * 0.06f, w * 0.42f, disc)
        disc.color = alpha(bright, 0.12f)
        canvas.drawCircle(w * 0.02f, h * 0.97f, w * 0.3f, disc)
        val pad = 92f * u
        brand(alpha(ink, 0.45f), w - pad, pad + 26f * u, Paint.Align.RIGHT)
        val top = pad + 190f * u
        val bottom = h - pad - 128f * u - 80f * u
        val inset = 44f * u
        val body = fit(textPaint(ink, 0f, serif), (w - pad * 2 - inset).toInt(), bottom - top, 90f * u, 38f * u, Layout.Alignment.ALIGN_NORMAL)
        val y = top + max(0f, (bottom - top - body.height) / 2f)
        quote(pad - 10f * u, y + 0.3f * 300f * u, 300f * u, bright)
        val bar = Paint(Paint.ANTI_ALIAS_FLAG)
        bar.color = bright
        canvas.drawRoundRect(RectF(pad, y, pad + 10f * u, y + body.height), 5f * u, 5f * u, bar)
        draw(body, pad + inset, y)
        footer(pad, h - pad, ink, alpha(ink, 0.62f), true)
    }
}

fun shareLyricsCard(context: Context, card: Bitmap, caption: String) {
    val dir = File(context.cacheDir, "shared")
    dir.mkdirs()
    dir.listFiles()?.forEach { it.delete() }
    val file = File(dir, "sonora-lyrics-${System.currentTimeMillis()}.png")
    file.outputStream().use { card.compress(Bitmap.CompressFormat.PNG, 100, it) }
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
    val send = Intent(Intent.ACTION_SEND)
        .setType("image/png")
        .putExtra(Intent.EXTRA_STREAM, uri)
        .putExtra(Intent.EXTRA_TEXT, caption)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    send.clipData = ClipData.newRawUri("Lyrics card", uri)
    val chooser = Intent.createChooser(send, "Share lyrics card")
    if (context !is android.app.Activity) chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(chooser)
}
