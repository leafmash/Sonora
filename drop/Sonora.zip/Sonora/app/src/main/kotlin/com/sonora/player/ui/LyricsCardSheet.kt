package com.sonora.player.ui

import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.collectAsState
import coil.imageLoader
import coil.request.ImageRequest
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.ArtModel
import com.sonora.player.data.CoverStore
import com.sonora.player.data.LyricsState
import com.sonora.player.data.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val MaxCardLines = 6
private const val PreviewWidth = 640
private const val ExportWidth = 1080

private class CardSource(val lines: List<String>, val start: Int)

@Composable
fun LyricsCardSheet(
    vm: PlayerViewModel,
    track: Track,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lyrics by vm.lyrics.collectAsStateWithLifecycle()
    val stamps by CoverStore.stamps.collectAsState()
    val stamp = stamps[track.id] ?: 0L
    val art by rememberArtColors(track)
    val initialPosition = remember { vm.position.value }

    val source = remember(lyrics) {
        when (val state = lyrics) {
            is LyricsState.Synced -> {
                val lines = state.lines.filter { it.text.isNotBlank() }
                CardSource(
                    lines.map { it.text.trim() },
                    lines.indexOfLast { it.timeMs <= initialPosition + 150 }.coerceAtLeast(0)
                )
            }
            is LyricsState.Plain -> CardSource(state.text.lines().map { it.trim() }.filter { it.isNotBlank() }, 0)
            else -> CardSource(emptyList(), 0)
        }
    }

    var selected by remember(source) {
        mutableStateOf(setOf(source.start, source.start + 1).filter { it < source.lines.size }.toSet())
    }
    var style by remember { mutableStateOf(CardStyle.Aurora) }
    var ratio by remember { mutableStateOf(CardRatio.Post) }
    var sharing by remember { mutableStateOf(false) }

    val cover by produceState<Bitmap?>(null, track.id, stamp) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val request = ImageRequest.Builder(context)
                    .data(ArtModel(track.uri, track.albumId, track.id, stamp))
                    .size(900)
                    .allowHardware(false)
                    .build()
                (context.imageLoader.execute(request).drawable as? BitmapDrawable)?.bitmap
            }.getOrNull()
        }
    }

    val chosen = remember(selected, source) { selected.sorted().mapNotNull { source.lines.getOrNull(it) } }

    val preview by produceState<Bitmap?>(null, cover, art, style, ratio, chosen) {
        value = if (chosen.isEmpty()) {
            null
        } else {
            withContext(Dispatchers.Default) {
                runCatching {
                    LyricsCardRenderer.render(cover, art, track.title, track.artist, chosen, style, ratio, PreviewWidth)
                }.getOrNull()
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.94f)
                .navigationBarsPadding()
        ) {
            Text(
                text = "Lyrics card",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
            if (source.lines.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        text = "No lyrics found for this song yet. Open the player menu and search for lyrics first.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(320.dp)
                        .padding(top = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val image = preview
                    if (image != null) {
                        Image(
                            bitmap = image.asImageBitmap(),
                            contentDescription = "Lyrics card preview",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxHeight()
                                .aspectRatio(ratio.aspect)
                                .clip(RoundedCornerShape(16.dp))
                        )
                    } else if (chosen.isEmpty()) {
                        Text(
                            text = "Pick a line below",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        CircularProgressIndicator()
                    }
                }
                Row(
                    Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CardStyle.entries.forEach { option ->
                        FilterChip(selected = style == option, onClick = { style = option }, label = { Text(option.label) })
                    }
                }
                Row(
                    Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CardRatio.entries.forEach { option ->
                        FilterChip(selected = ratio == option, onClick = { ratio = option }, label = { Text(option.label) })
                    }
                }
                Text(
                    text = "Choose up to $MaxCardLines lines  ·  ${selected.size} selected",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 4.dp)
                )
                LazyColumn(Modifier.weight(1f)) {
                    itemsIndexed(source.lines) { index, line ->
                        val on = index in selected
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 2.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (on) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)
                                .clickable {
                                    if (on) {
                                        selected = selected - index
                                    } else if (selected.size >= MaxCardLines) {
                                        Toast.makeText(context, "You can pick up to $MaxCardLines lines", Toast.LENGTH_SHORT).show()
                                    } else {
                                        selected = selected + index
                                    }
                                }
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (on) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                                contentDescription = null,
                                tint = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(Modifier.size(12.dp))
                            Text(text = line, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
                Button(
                    onClick = {
                        sharing = true
                        scope.launch {
                            val result = withContext(Dispatchers.Default) {
                                runCatching {
                                    LyricsCardRenderer.render(cover, art, track.title, track.artist, chosen, style, ratio, ExportWidth)
                                }.getOrNull()
                            }
                            if (result != null) {
                                runCatching { withContext(Dispatchers.IO) { shareLyricsCard(context, result, "${track.title} - ${track.artist}") } }
                                    .onFailure { Toast.makeText(context, "Couldn't share the card", Toast.LENGTH_SHORT).show() }
                            } else {
                                Toast.makeText(context, "Couldn't create the card", Toast.LENGTH_SHORT).show()
                            }
                            sharing = false
                        }
                    },
                    enabled = chosen.isNotEmpty() && !sharing,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Text(if (sharing) "Creating…" else "Share card")
                }
            }
        }
    }
}
