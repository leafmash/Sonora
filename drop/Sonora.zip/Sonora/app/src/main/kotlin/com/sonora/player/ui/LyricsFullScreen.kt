package com.sonora.player.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.LyricsState
import com.sonora.player.data.Track
import kotlinx.coroutines.delay

private const val ControlsIdleMs = 4000L

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun LyricsFullScreen(
    vm: PlayerViewModel,
    track: Track,
    state: LyricsState,
    top: Color,
    bright: Color,
    onImport: () -> Unit,
    onClose: () -> Unit,
    onNotFoundTimeout: (() -> Unit)? = null
) {
    val view = LocalView.current
    val activity = LocalContext.current.findActivity()
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    var controlsVisible by remember { mutableStateOf(false) }
    var touches by remember { mutableIntStateOf(0) }
    var shown by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { shown = true }

    BackHandler(onBack = onClose)

    LaunchedEffect(touches) {
        controlsVisible = true
        delay(ControlsIdleMs)
        controlsVisible = false
    }

    DisposableEffect(view, activity) {
        view.keepScreenOn = true
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        val originalOrientation = activity?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            view.keepScreenOn = false
            controller?.show(WindowInsetsCompat.Type.systemBars())
            activity?.requestedOrientation = originalOrientation
        }
    }

    fun rotate() {
        touches++
        activity?.requestedOrientation = if (landscape) {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    val luminous = remember(bright) {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(bright.toArgb(), hsv)
        val saturation = if (hsv[1] < 0.12f) hsv[1] else 0.52f
        Color(android.graphics.Color.HSVToColor(floatArrayOf(hsv[0], saturation, 1f)))
    }
    val activeColor by animateColorAsState(lerp(luminous, Color.White, 0.18f), tween(700), label = "activeColor")
    val glow by animateColorAsState(luminous, tween(700), label = "glowColor")
    val chip = lerp(bright, Color.White, 0.35f).copy(alpha = 0.16f)
    val chipEdge = Color.White.copy(alpha = 0.22f)
    val lyricsPadding = if (landscape) 64.dp else 20.dp
    val iconTurn by animateFloatAsState(
        targetValue = if (landscape) 90f else 0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 180f),
        label = "rotateIcon"
    )

    Box(
        Modifier
            .fillMaxSize()
            .nowPlayingBackdrop(top, bright, animated = false)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        if (event.type == PointerEventType.Press) touches++
                    }
                }
            }
    ) {
        AnimatedVisibility(
            visible = true,
            enter = fadeIn(tween(1000)),
            exit = fadeOut(tween(300))
        ) {
            Box(Modifier.fillMaxSize()) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                0f to Color(0xFF05060B).copy(alpha = 0.78f),
                                1f to Color(0xFF020307).copy(alpha = 0.9f)
                            )
                        )
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                0f to Color.Transparent,
                                1f to Color.Black.copy(alpha = 0.55f),
                                radius = 1500f
                            )
                        )
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                0.7f to Color.Transparent,
                                1f to bright.copy(alpha = 0.16f)
                            )
                        )
                )
                SnowFall(Modifier.fillMaxSize(), count = 100, accent = luminous)
            }
        }

        LyricsPanel(
            vm = vm,
            track = track,
            state = state,
            onImport = onImport,
            showToolbar = false,
            immersive = true,
            immersiveSize = if (landscape) 42.sp else 34.sp,
            glowColor = glow,
            activeColor = activeColor,
            modifier = Modifier
                .fillMaxSize()
                .displayCutoutPadding()
                .systemBarsPadding()
                .padding(horizontal = lyricsPadding),
            onNotFoundTimeout = onNotFoundTimeout
        )

        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(tween(350)) + scaleIn(tween(350), initialScale = 0.8f),
            exit = fadeOut(tween(500)) + scaleOut(tween(500), targetScale = 0.8f),
            modifier = Modifier
                .align(Alignment.TopStart)
                .displayCutoutPadding()
                .systemBarsPadding()
                .padding(12.dp)
        ) {
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(chip)
                    .border(1.dp, chipEdge, CircleShape)
                    .clickable(onClick = onClose),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    SonoraIcons.Collapse,
                    contentDescription = "Exit full screen",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(tween(350)) + scaleIn(tween(350), initialScale = 0.8f),
            exit = fadeOut(tween(500)) + scaleOut(tween(500), targetScale = 0.8f),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .displayCutoutPadding()
                .systemBarsPadding()
                .padding(12.dp)
        ) {
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(chip)
                    .border(1.dp, chipEdge, CircleShape)
                    .clickable(onClick = ::rotate),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.ScreenRotation,
                    contentDescription = "Rotate",
                    tint = Color.White,
                    modifier = Modifier
                        .size(24.dp)
                        .rotate(iconTurn)
                )
            }
        }
    }
}
