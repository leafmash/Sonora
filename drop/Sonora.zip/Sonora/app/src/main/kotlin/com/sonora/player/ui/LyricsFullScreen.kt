package com.sonora.player.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.LyricsState
import com.sonora.player.data.Track
import kotlinx.coroutines.delay

private const val ControlsIdleMs = 4000L

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun LyricsFullScreen(
    vm: PlayerViewModel,
    track: Track,
    state: LyricsState,
    top: Color,
    bright: Color,
    onImport: () -> Unit,
    onClose: () -> Unit,
    onNotFoundTimeout: (() -> Unit)? = null
) {
    val view = LocalView.current
    val activity = LocalContext.current.findActivity()
    var controlsVisible by remember { mutableStateOf(false) }
    var touches by remember { mutableIntStateOf(0) }
    var locked by remember { mutableStateOf(false) }
    var shown by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { shown = true }

    BackHandler { if (!locked) onClose() }

    LaunchedEffect(touches) {
        controlsVisible = true
        delay(ControlsIdleMs)
        controlsVisible = false
    }

    DisposableEffect(view, activity) {
        view.keepScreenOn = true
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        val originalOrientation = activity?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            view.keepScreenOn = false
            controller?.show(WindowInsetsCompat.Type.systemBars())
            activity?.requestedOrientation = originalOrientation
        }
    }

    val luminous = remember(bright) {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(bright.toArgb(), hsv)
        val saturation = if (hsv[1] < 0.12f) hsv[1] else 0.52f
        Color(android.graphics.Color.HSVToColor(floatArrayOf(hsv[0], saturation, 1f)))
    }
    val activeColor by animateColorAsState(lerp(luminous, Color.White, 0.18f), tween(700), label = "activeColor")
    val chip = lerp(bright, Color.White, 0.35f).copy(alpha = 0.16f)
    val chipEdge = Color.White.copy(alpha = 0.22f)

    Box(
        Modifier
            .fillMaxSize()
            .nowPlayingBackdrop(top, bright, animated = false)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        if (event.type == PointerEventType.Press) touches++
                    }
                }
            }
    ) {
        AnimatedVisibility(
            visible = true,
            enter = fadeIn(tween(1000)),
            exit = fadeOut(tween(300))
        ) {
            Box(Modifier.fillMaxSize()) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                0f to Color(0xFF05060B).copy(alpha = 0.78f),
                                1f to Color(0xFF020307).copy(alpha = 0.9f)
                            )
                        )
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                0f to Color.Transparent,
                                1f to Color.Black.copy(alpha = 0.55f),
                                radius = 1500f
                            )
                        )
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                0.7f to Color.Transparent,
                                1f to bright.copy(alpha = 0.16f)
                            )
                        )
                )
                SnowFall(Modifier.fillMaxSize().graphicsLayer(), count = 70, accent = luminous)
            }
        }

        LyricsPanel(
            vm = vm,
            track = track,
            state = state,
            onImport = onImport,
            showToolbar = false,
            immersive = true,
            immersiveSize = 48.sp,
            activeColor = activeColor,
            modifier = Modifier
                .fillMaxSize()
                .displayCutoutPadding()
                .systemBarsPadding()
                .padding(horizontal = 64.dp),
            onNotFoundTimeout = onNotFoundTimeout
        )

        if (locked) {
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        awaitPointerEventScope {
                            while (true) {
                                awaitPointerEvent().changes.forEach { it.consume() }
                            }
                        }
                    }
            )
        }

        AnimatedVisibility(
            visible = controlsVisible && !locked,
            enter = fadeIn(tween(350)) + scaleIn(tween(350), initialScale = 0.8f),
            exit = fadeOut(tween(500)) + scaleOut(tween(500), targetScale = 0.8f),
            modifier = Modifier
                .align(Alignment.TopStart)
                .displayCutoutPadding()
                .systemBarsPadding()
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ControlChip(SonoraIcons.Collapse, "Exit full screen", 46.dp, chip, chipEdge, onClose)
                ControlChip(Icons.Rounded.Lock, "Lock screen", 46.dp, chip, chipEdge) {
                    locked = true
                    controlsVisible = false
                }
            }
        }

        AnimatedVisibility(
            visible = controlsVisible && locked,
            enter = fadeIn(tween(350)) + scaleIn(tween(350), initialScale = 0.8f),
            exit = fadeOut(tween(500)) + scaleOut(tween(500), targetScale = 0.8f),
            modifier = Modifier
                .align(Alignment.TopStart)
                .displayCutoutPadding()
                .systemBarsPadding()
                .padding(12.dp)
        ) {
            ControlChip(Icons.Rounded.LockOpen, "Unlock screen", 46.dp, chip, chipEdge) { locked = false }
        }

        AnimatedVisibility(
            visible = controlsVisible && !locked,
            enter = fadeIn(tween(350)) + scaleIn(tween(350), initialScale = 0.8f),
            exit = fadeOut(tween(500)) + scaleOut(tween(500), targetScale = 0.8f),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .displayCutoutPadding()
                .systemBarsPadding()
                .padding(12.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ControlChip(Icons.Rounded.SkipPrevious, "Previous", 40.dp, chip, chipEdge) {
                    touches++
                    vm.previous()
                }
                ControlChip(Icons.Rounded.SkipNext, "Next", 40.dp, chip, chipEdge) {
                    touches++
                    vm.next()
                }
            }
        }
    }
}

@Composable
private fun ControlChip(
    icon: ImageVector,
    description: String,
    size: Dp,
    background: Color,
    edge: Color,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(background)
            .border(1.dp, edge, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = Color.White, modifier = Modifier.size(size / 2))
    }
}
