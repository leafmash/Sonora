package com.sonora.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.withFrameMillis
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.LrcParser
import com.sonora.player.data.LyricLine
import com.sonora.player.data.LyricsState
import com.sonora.player.data.Track
import com.sonora.player.ui.components.SonoraMark
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlin.math.abs
import kotlin.math.exp

private val LyricInk = Color(0xFF0B0A10)
private val LyricSoft = Color.White.copy(alpha = 0.7f)
private const val LeadMs = 220L
private const val FadeMs = 180
private const val HoldMs = 3000L
private const val FollowStiffness = 30f
private const val MaxFollowGap = 1400f
private const val ImmersiveBoost = 1.3f
private const val ToolbarIdleMs = 3000L

@Composable
fun LyricsPanel(
    vm: PlayerViewModel,
    track: Track,
    state: LyricsState,
    onImport: () -> Unit,
    modifier: Modifier = Modifier,
    onFullscreen: (() -> Unit)? = null,
    showToolbar: Boolean = true,
    immersive: Boolean = false,
    activeColor: Color = Color.White,
    immersiveSize: TextUnit = 42.sp,
    onNotFoundTimeout: (() -> Unit)? = null
) {
    var searching by remember { mutableStateOf(false) }
    val lifecycleOwner = LocalLifecycleOwner.current
    val timeoutAction by rememberUpdatedState(onNotFoundTimeout)
    val armed = state is LyricsState.NotFound && !searching && onNotFoundTimeout != null
    LaunchedEffect(armed, track.id) {
        if (!armed) return@LaunchedEffect
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            delay(3000)
            timeoutAction?.invoke()
        }
    }
    val settings by vm.settings.collectAsStateWithLifecycle()
    val scale = settings.lyricsScale

    val hasLyrics = state is LyricsState.Synced || state is LyricsState.Plain

    var touches by remember { mutableIntStateOf(0) }
    var toolbarVisible by remember { mutableStateOf(true) }
    LaunchedEffect(touches) {
        toolbarVisible = true
        delay(ToolbarIdleMs)
        toolbarVisible = false
    }

    Box(
        modifier.pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    if (event.type == PointerEventType.Press) touches++
                }
            }
        }
    ) {
        Box(Modifier.fillMaxSize()) {
            when (state) {
                LyricsState.Idle, LyricsState.Loading -> LoadingMessage()
                is LyricsState.Synced -> SyncedLyrics(vm, state.lines, scale, immersive, activeColor, immersiveSize)
                is LyricsState.Plain -> PlainLyrics(state.text, scale * if (immersive) ImmersiveBoost else 1f)
                LyricsState.NotFound -> EmptyMessage(
                    title = "No lyrics found",
                    message = "Search by title and artist, or import an .lrc file for this song.",
                    onSearch = { searching = true },
                    onRetry = vm::retryLyrics,
                    onImport = onImport
                )
                LyricsState.Failed -> EmptyMessage(
                    title = "Can't reach the lyrics service",
                    message = "Check your connection, try again, or search by title and artist.",
                    onSearch = { searching = true },
                    onRetry = vm::retryLyrics,
                    onImport = onImport
                )
            }
        }
        if (hasLyrics && showToolbar) {
            AnimatedVisibility(
                visible = toolbarVisible,
                enter = fadeIn(tween(250)),
                exit = fadeOut(tween(450)),
                modifier = Modifier.align(Alignment.TopCenter)
            ) {
                LyricsToolbar(
                    onFullscreen = onFullscreen,
                    onSearch = { searching = true },
                    onImport = onImport,
                    onRetry = vm::retryLyrics
                )
            }
        }
    }

    if (searching) {
        LyricsSearchSheet(vm = vm, track = track, onDismiss = { searching = false })
    }
}

@Composable
private fun LyricsToolbar(
    onFullscreen: (() -> Unit)?,
    onSearch: () -> Unit,
    onImport: () -> Unit,
    onRetry: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 2.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.Center
    ) {
        Row(
            Modifier
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.1f))
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onFullscreen != null) {
                ToolbarButton(SonoraIcons.Expand, "Full screen lyrics", onFullscreen)
            }
            ToolbarButton(Icons.Rounded.Search, "Search lyrics", onSearch)
            ToolbarButton(Icons.Rounded.UploadFile, "Import .lrc", onImport)
            ToolbarButton(Icons.Rounded.Refresh, "Search again", onRetry)
        }
    }
}

@Composable
private fun ToolbarButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(42.dp)) {
        Icon(icon, contentDescription = description, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun LoadingMessage() {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp, modifier = Modifier.size(32.dp))
        Spacer(Modifier.height(16.dp))
        Text("Finding lyrics", style = MaterialTheme.typography.bodyLarge, color = LyricSoft)
    }
}

@Composable
private fun EmptyMessage(
    title: String,
    message: String,
    onSearch: () -> Unit,
    onRetry: () -> Unit,
    onImport: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.Lyrics, contentDescription = null, tint = LyricSoft, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, color = Color.White, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = LyricSoft, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onSearch,
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = LyricInk)
        ) {
            Icon(Icons.Rounded.Search, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.size(8.dp))
            Text("Search Lyrics Online")
        }
        TextButton(
            onClick = onRetry,
            colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
        ) {
            Text("Search again")
        }
        TextButton(
            onClick = onImport,
            colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
        ) {
            Text("Import .lrc file")
        }
    }
}

@Composable
private fun PlainLyrics(text: String, scale: Float) {
    Column(
        Modifier
            .fillMaxSize()
            .fadingEdges()
            .verticalScroll(rememberScrollState())
            .padding(top = 24.dp, bottom = 48.dp, start = 12.dp, end = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium.let {
                it.copy(fontSize = it.fontSize * scale, fontWeight = FontWeight.Medium, lineHeight = 32.sp * scale)
            },
            color = Color.White.copy(alpha = 0.92f),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun SyncedLyrics(vm: PlayerViewModel, lines: List<LyricLine>, scale: Float, immersive: Boolean, activeColor: Color, immersiveSize: TextUnit) {
    var active by remember(lines) { mutableIntStateOf(-1) }
    val nowState by vm.now.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    var holding by remember { mutableStateOf(false) }
    var placed by remember { mutableStateOf(false) }
    val glideVelocity = remember { floatArrayOf(0f) }

    LaunchedEffect(lines) {
        while (true) {
            if (vm.isPlayingNow()) {
                withFrameMillis { }
            } else {
                delay(120)
            }
            val next = LrcParser.indexAt(lines, vm.livePosition() + LeadMs)
            if (next != active) active = next
        }
    }

    LaunchedEffect(listState) {
        listState.interactionSource.interactions.collectLatest { interaction ->
            when (interaction) {
                is DragInteraction.Start -> holding = true
                is DragInteraction.Stop, is DragInteraction.Cancel -> {
                    snapshotFlow { listState.isScrollInProgress }.first { !it }
                    delay(HoldMs)
                    holding = false
                }
            }
        }
    }

    LaunchedEffect(active, holding, scale) {
        if (holding || active < 0) return@LaunchedEffect
        if (!placed) {
            val atStart = active == 0 && listState.firstVisibleItemIndex == 0
            if (!atStart) {
                if (listState.layoutInfo.visibleItemsInfo.none { it.index == active }) {
                    listState.scrollToItem(active)
                }
                centerDelta(listState, active)?.let { listState.scrollBy(it) }
                placed = true
                return@LaunchedEffect
            }
            placed = true
        }
        listState.scroll {
            var last = 0L
            var stalled = 0
            var remaining = centerDelta(listState, active) ?: return@scroll
            while (true) {
                val now = withFrameNanos { it }
                val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                last = now
                val exact = exactCenterDelta(listState, active)
                if (exact != null) {
                    remaining = exact
                } else if (abs(remaining) < 24f) {
                    centerDelta(listState, active)?.let { remaining = it }
                }
                val x0 = -remaining.coerceIn(-MaxFollowGap, MaxFollowGap)
                val v0 = glideVelocity[0]
                val b = v0 + FollowStiffness * x0
                val decay = exp(-FollowStiffness * dt)
                val x1 = (x0 + b * dt) * decay
                glideVelocity[0] = (v0 - FollowStiffness * b * dt) * decay
                if (abs(remaining) < 0.6f && abs(glideVelocity[0]) < 25f) {
                    scrollBy(remaining)
                    glideVelocity[0] = 0f
                    break
                }
                val moved = scrollBy(x1 - x0)
                remaining -= moved
                if (abs(moved) < 0.01f) {
                    stalled++
                    if (stalled > 6) {
                        glideVelocity[0] = 0f
                        break
                    }
                } else {
                    stalled = 0
                }
            }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .fadingEdges(if (immersive) 0.24f else 0.1f),
            contentPadding = PaddingValues(top = maxHeight / 2, bottom = maxHeight / 2)
        ) {
            itemsIndexed(lines, key = { index, _ -> index }) { index, line ->
                val distance = if (active < 0) minOf(index + 1, 3) else minOf(abs(index - active), 3)
                val seekTime = line.timeMs
                LyricRow(
                    text = line.text,
                    distance = distance,
                    playing = nowState.isPlaying,
                    scale = scale,
                    immersive = immersive,
                    activeColor = activeColor,
                    immersiveSize = immersiveSize,
                    onClick = { vm.seekTo(seekTime) }
                )
            }
        }
    }
}

private fun exactCenterDelta(listState: androidx.compose.foundation.lazy.LazyListState, index: Int): Float? {
    val info = listState.layoutInfo
    val item = info.visibleItemsInfo.firstOrNull { it.index == index } ?: return null
    return item.offset + item.size / 2f + info.beforeContentPadding - info.viewportSize.height / 2f
}

private fun centerDelta(listState: androidx.compose.foundation.lazy.LazyListState, index: Int): Float? {
    val info = listState.layoutInfo
    val visible = info.visibleItemsInfo
    if (visible.isEmpty()) return null
    val exact = visible.firstOrNull { it.index == index }
    val offset: Float
    val size: Float
    if (exact != null) {
        offset = exact.offset.toFloat()
        size = exact.size.toFloat()
    } else {
        val first = visible.first()
        size = visible.sumOf { it.size }.toFloat() / visible.size
        offset = first.offset + (index - first.index) * size
    }
    return offset + size / 2f + info.beforeContentPadding - info.viewportSize.height / 2f
}

@Composable
private fun LyricRow(
    text: String,
    distance: Int,
    playing: Boolean,
    scale: Float,
    immersive: Boolean,
    activeColor: Color,
    immersiveSize: TextUnit,
    onClick: () -> Unit
) {
    val alpha by animateFloatAsState(
        targetValue = when (distance) {
            0 -> 1f
            1 -> 0.55f
            2 -> 0.4f
            else -> 0.27f
        },
        animationSpec = tween(FadeMs),
        label = "lyricAlpha"
    )
    val emphasis by animateFloatAsState(
        targetValue = if (distance == 0) 1f else if (immersive) 0.64f else 0.78f,
        animationSpec = tween(FadeMs),
        label = "lyricScale"
    )
    val textColor by animateColorAsState(
        targetValue = if (immersive && distance == 0) activeColor else Color.White,
        animationSpec = tween(FadeMs),
        label = "lyricColor"
    )
    val glow by animateFloatAsState(
        targetValue = if (immersive && distance == 0) 0.55f else 0f,
        animationSpec = tween(FadeMs),
        label = "lyricGlow"
    )
    val base = if (immersive) {
        MaterialTheme.typography.headlineLarge.copy(
            fontSize = immersiveSize * scale,
            lineHeight = immersiveSize * 1.2f * scale,
            fontWeight = FontWeight.Medium,
            letterSpacing = (-0.3).sp,
            textAlign = TextAlign.Center
        )
    } else {
        MaterialTheme.typography.headlineSmall.let { it.copy(fontSize = it.fontSize * scale) }.copy(
            fontWeight = FontWeight.Bold,
            lineHeight = 36.sp * scale,
            textAlign = TextAlign.Center
        )
    }
    val style = base.copy(
        color = textColor,
        shadow = if (glow > 0.01f) Shadow(color = activeColor.copy(alpha = glow), blurRadius = 26f) else null
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                this.alpha = alpha
                compositingStrategy = CompositingStrategy.ModulateAlpha
                scaleX = emphasis
                scaleY = emphasis
                transformOrigin = TransformOrigin.Center
            }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(vertical = if (immersive) 12.dp else 10.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        if (text.isBlank()) {
            SonoraMark(
                size = if (immersive) 52.dp * scale else 34.dp * scale,
                tint = textColor,
                dancing = distance == 0 && playing
            )
        } else {
            Text(text = text, style = style, textAlign = TextAlign.Center)
        }
    }
}

private fun Modifier.fadingEdges(edge: Float = 0.1f): Modifier =
    this
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            drawRect(
                brush = Brush.verticalGradient(
                    0f to Color.Transparent,
                    edge to Color.Black,
                    (1f - edge) to Color.Black,
                    1f to Color.Transparent
                ),
                blendMode = BlendMode.DstIn
            )
        }
