package com.sonora.player.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.LrcParser
import com.sonora.player.data.LyricsState
import com.sonora.player.ui.components.Artwork
import com.sonora.player.ui.components.rememberSpin
import com.sonora.player.ui.theme.brandBrush

@Composable
fun MiniPlayer(vm: PlayerViewModel, onClick: () -> Unit) {
    val now by vm.now.collectAsStateWithLifecycle()
    val position by vm.position.collectAsStateWithLifecycle()
    val lyrics by vm.lyrics.collectAsStateWithLifecycle()
    val scheme = MaterialTheme.colorScheme
    val brush = brandBrush()
    val art by rememberArtColors(now.track)
    val tint by animateColorAsState(art?.bright ?: scheme.primary, tween(600), label = "miniTint")
    val track = now.track ?: return
    val liveLine = (lyrics as? LyricsState.Synced)
        ?.let { synced -> synced.lines.getOrNull(LrcParser.indexAt(synced.lines, position + 150))?.text }
        ?.takeIf { it.isNotBlank() }
    val fraction = if (now.durationMs > 0) (position.toFloat() / now.durationMs).coerceIn(0f, 1f) else 0f

    Surface(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .pointerInput(Unit) {
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (total < -120f) vm.next() else if (total > 120f) vm.previous()
                    },
                    onDragCancel = { total = 0f },
                    onHorizontalDrag = { _, delta -> total += delta }
                )
            },
        shape = RoundedCornerShape(30.dp),
        color = scheme.surfaceContainerHigh,
        shadowElevation = 10.dp
    ) {
        Column(Modifier.background(Brush.horizontalGradient(listOf(tint.copy(alpha = 0.3f), Color.Transparent)))) {
            Row(
                Modifier.padding(start = 10.dp, end = 8.dp, top = 10.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Artwork(
                    track = track,
                    modifier = Modifier.size(50.dp),
                    shape = CircleShape,
                    current = true,
                    playing = now.isPlaying
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Crossfade(targetState = liveLine, label = "miniLine") { line ->
                        Text(
                            text = line ?: track.artist,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (line != null) scheme.primary else scheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(brush)
                        .clickable(onClick = vm::togglePlay),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (now.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (now.isPlaying) "Pause" else "Play",
                        tint = scheme.onPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }
                IconButton(onClick = vm::next) {
                    Icon(Icons.Rounded.SkipNext, contentDescription = "Next", modifier = Modifier.size(28.dp))
                }
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 18.dp, end = 18.dp, bottom = 10.dp)
                    .height(3.dp)
                    .clip(CircleShape)
                    .background(scheme.onSurface.copy(alpha = 0.1f))
            ) {
                Box(
                    Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fraction)
                        .background(brush)
                )
            }
        }
    }
}
