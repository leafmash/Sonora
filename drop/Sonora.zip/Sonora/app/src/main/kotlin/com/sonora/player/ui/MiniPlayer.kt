package com.sonora.player.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.LrcParser
import com.sonora.player.data.LyricsState
import com.sonora.player.ui.components.Artwork
import com.sonora.player.ui.components.rememberSpin
import com.sonora.player.ui.theme.brandBrush
import kotlin.math.abs

@Composable
fun MiniPlayer(vm: PlayerViewModel, onClick: () -> Unit) {
    val now by vm.now.collectAsStateWithLifecycle()
    val position by vm.position.collectAsStateWithLifecycle()
    val lyrics by vm.lyrics.collectAsStateWithLifecycle()
    val scheme = MaterialTheme.colorScheme
    val brush = brandBrush()
    val art by rememberArtColors(now.track)
    val tint by animateColorAsState(art?.bright ?: scheme.primary, tween(600), label = "miniTint")
    var drag by remember { mutableFloatStateOf(0f) }
    var direction by remember { mutableIntStateOf(1) }
    val density = LocalDensity.current
    val travel = with(density) { 96.dp.toPx() }
    val threshold = with(density) { 56.dp.toPx() }
    val dragState = rememberDraggableState { delta -> drag = (drag + delta * 0.8f).coerceIn(-travel, travel) }
    val track = now.track ?: return
    val liveLine = (lyrics as? LyricsState.Synced)
        ?.let { synced -> synced.lines.getOrNull(LrcParser.indexAt(synced.lines, position + 150))?.text }
        ?.takeIf { it.isNotBlank() }
    val fraction = if (now.durationMs > 0) (position.toFloat() / now.durationMs).coerceIn(0f, 1f) else 0f

    Surface(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .draggable(
                state = dragState,
                orientation = Orientation.Horizontal,
                onDragStopped = {
                    val released = drag
                    if (released <= -threshold) {
                        direction = 1
                        vm.next()
                    } else if (released >= threshold) {
                        direction = -1
                        vm.previous()
                    }
                    animate(
                        initialValue = released,
                        targetValue = 0f,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)
                    ) { value, _ -> drag = value }
                }
            ),
        shape = RoundedCornerShape(30.dp),
        color = scheme.surfaceContainerHigh,
        shadowElevation = 10.dp
    ) {
        Column(Modifier.background(Brush.horizontalGradient(listOf(tint.copy(alpha = 0.3f), Color.Transparent)))) {
            Row(
                Modifier.padding(start = 10.dp, end = 8.dp, top = 10.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AnimatedContent(
                    targetState = track,
                    contentKey = { it.id },
                    modifier = Modifier
                        .weight(1f)
                        .graphicsLayer {
                            translationX = drag
                            alpha = 1f - (abs(drag) / travel).coerceIn(0f, 1f) * 0.45f
                        },
                    transitionSpec = {
                        val dir = direction
                        (slideInHorizontally(tween(280)) { dir * it / 3 } + fadeIn(tween(280))) togetherWith
                            (slideOutHorizontally(tween(220)) { -dir * it / 3 } + fadeOut(tween(160)))
                    },
                    label = "miniTrack"
                ) { shown ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Artwork(
                            track = shown,
                            modifier = Modifier.size(50.dp),
                            shape = CircleShape,
                            current = true,
                            playing = now.isPlaying
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = shown.title,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Crossfade(targetState = liveLine, label = "miniLine") { line ->
                                Text(
                                    text = line ?: shown.artist,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (line != null) scheme.primary else scheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(brush)
                        .clickable(onClick = vm::togglePlay),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (now.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (now.isPlaying) "Pause" else "Play",
                        tint = scheme.onPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }
                IconButton(onClick = {
                    direction = 1
                    vm.next()
                }) {
                    Icon(Icons.Rounded.SkipNext, contentDescription = "Next", modifier = Modifier.size(28.dp))
                }
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 18.dp, end = 18.dp, bottom = 10.dp)
                    .height(3.dp)
                    .clip(CircleShape)
                    .background(scheme.onSurface.copy(alpha = 0.1f))
            ) {
                Box(
                    Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fraction)
                        .background(brush)
                )
            }
        }
    }
}
