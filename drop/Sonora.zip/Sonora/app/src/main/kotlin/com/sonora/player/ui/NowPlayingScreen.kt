package com.sonora.player.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import kotlin.math.PI
import kotlin.math.sin
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeOut
import androidx.compose.animation.fadeIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import com.sonora.player.ui.components.JumpToCurrentButton
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.NowPlaying
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.Track
import com.sonora.player.ui.components.Artwork
import com.sonora.player.ui.components.LyricsBadge
import androidx.media3.common.Player
import kotlin.math.abs

private val Ink = Color(0xFF0B0A10)
private val Pink = Color(0xFFFF9AD5)

@Composable
fun NowPlayingScreen(
    vm: PlayerViewModel,
    onCollapse: () -> Unit,
    onAddToPlaylist: (Track) -> Unit,
    onOpenEqualizer: () -> Unit
) {
    val now by vm.now.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val sleep by vm.sleepRemaining.collectAsStateWithLifecycle()
    val track = now.track
    val art by rememberArtColors(track)
    val top by animateColorAsState(
        targetValue = lerp(Ink, art?.deep ?: Color(0xFF4A3B8C), 0.75f),
        animationSpec = tween(700),
        label = "top"
    )
    val bright by animateColorAsState(
        targetValue = art?.bright ?: Pink,
        animationSpec = tween(700),
        label = "bright"
    )
    val glow = lerp(bright, Color.White, 0.3f)
    var showQueue by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var fullLyrics by remember { mutableStateOf(false) }
    val settings by vm.settings.collectAsStateWithLifecycle()
    val lyrics by vm.lyrics.collectAsStateWithLifecycle()
    val showLyrics = settings.lyricsMode
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importLyrics(uri)
    }

    LaunchedEffect(track == null) {
        if (track == null) onCollapse()
    }
    if (track == null) return

    val favorite = track.id in favorites
    val white = Color.White
    val soft = Color.White.copy(alpha = 0.7f)

    Box(
        Modifier
            .fillMaxSize()
            .nowPlayingBackdrop(top, bright)
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total > 220f) onCollapse() },
                    onDragCancel = { total = 0f },
                    onVerticalDrag = { _, delta -> total += delta }
                )
            }
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onCollapse) {
                    Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Close", tint = white, modifier = Modifier.size(32.dp))
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "NOW PLAYING",
                        style = MaterialTheme.typography.labelSmall,
                        color = soft,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = track.album,
                        style = MaterialTheme.typography.labelLarge,
                        color = white,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = { onAddToPlaylist(track) }) {
                    Icon(Icons.Rounded.PlaylistAdd, contentDescription = "Add to playlist", tint = white)
                }
            }

            Crossfade(
                targetState = showLyrics,
                animationSpec = tween(300),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                label = "lyricsToggle"
            ) { lyricsOn ->
                if (lyricsOn) {
                    LyricsPanel(
                        vm = vm,
                        track = track,
                        state = lyrics,
                        onImport = { importLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.fillMaxSize(),
                        onFullscreen = { fullLyrics = true },
                        onNotFoundTimeout = if (fullLyrics) null else {
                            { vm.updateSettings { it.copy(lyricsMode = false) } }
                        }
                    )
                } else {
                    BoxWithConstraints(
                        Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        val side = minOf(maxWidth, maxHeight)
                        val scale by animateFloatAsState(
                            targetValue = if (now.isPlaying) 1f else 0.88f,
                            animationSpec = spring(dampingRatio = 0.65f, stiffness = Spring.StiffnessLow),
                            label = "scale"
                        )
                        Crossfade(targetState = track, animationSpec = tween(350), label = "art") { shown ->
                            Artwork(
                                track = shown,
                                modifier = Modifier
                                    .size(side)
                                    .graphicsLayer {
                                        scaleX = scale
                                        scaleY = scale
                                    }
                                    .shadow(32.dp, RoundedCornerShape(32.dp), ambientColor = bright, spotColor = bright)
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = null
                                    ) { vm.updateSettings { it.copy(lyricsMode = true) } },
                                shape = RoundedCornerShape(32.dp),
                                current = true,
                                playing = now.isPlaying,
                                animated = false
                            )
                        }
                    }
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        style = MaterialTheme.typography.headlineSmall,
                        color = white,
                        maxLines = 1,
                        modifier = Modifier.basicMarquee()
                    )
                    Text(
                        text = track.artist,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Normal,
                        color = soft,
                        maxLines = 1,
                        modifier = Modifier.basicMarquee()
                    )
                }
                IconButton(onClick = { vm.toggleFavorite(track) }) {
                    Icon(
                        imageVector = if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (favorite) glow else white,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            SeekBar(vm, now.durationMs, track.id, now.isPlaying, glow)
            Spacer(Modifier.height(4.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = vm::toggleShuffle) {
                    Icon(
                        Icons.Rounded.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (now.shuffle) glow else soft,
                        modifier = Modifier.size(26.dp)
                    )
                }
                IconButton(onClick = vm::previous, modifier = Modifier.size(64.dp)) {
                    Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous", tint = white, modifier = Modifier.size(42.dp))
                }
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .shadow(20.dp, CircleShape, ambientColor = bright, spotColor = bright)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color.White, lerp(Color.White, bright, 0.55f))))
                        .clickable(onClick = vm::togglePlay),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (now.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (now.isPlaying) "Pause" else "Play",
                        tint = Ink,
                        modifier = Modifier.size(44.dp)
                    )
                }
                IconButton(onClick = vm::next, modifier = Modifier.size(64.dp)) {
                    Icon(Icons.Rounded.SkipNext, contentDescription = "Next", tint = white, modifier = Modifier.size(42.dp))
                }
                IconButton(onClick = vm::cycleRepeat) {
                    Icon(
                        imageVector = if (now.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        contentDescription = "Repeat",
                        tint = if (now.repeat == Player.REPEAT_MODE_OFF) soft else glow,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            sleep?.let {
                Text(
                    text = "Sleep timer · ${formatTime(it)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = glow,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    textAlign = TextAlign.Center
                )
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(onClick = { vm.updateSettings { it.copy(lyricsMode = !it.lyricsMode) } }) {
                    Icon(Icons.Rounded.Lyrics, contentDescription = "Lyrics", tint = if (showLyrics) glow else soft)
                }
                IconButton(onClick = { showSpeed = true }) {
                    Icon(Icons.Rounded.Speed, contentDescription = "Speed", tint = if (abs(now.speed - 1f) > 0.01f) glow else soft)
                }
                IconButton(onClick = { showSleep = true }) {
                    Icon(Icons.Rounded.Bedtime, contentDescription = "Sleep timer", tint = if (sleep != null) glow else soft)
                }
                IconButton(onClick = onOpenEqualizer) {
                    Icon(Icons.Rounded.Equalizer, contentDescription = "Equalizer", tint = soft)
                }
                IconButton(onClick = { showQueue = true }) {
                    Icon(Icons.Rounded.QueueMusic, contentDescription = "Queue", tint = soft)
                }
            }
        }
    }

    AnimatedVisibility(
        visible = fullLyrics,
        enter = fadeIn(tween(350)),
        exit = fadeOut(tween(300))
    ) {
        LyricsFullScreen(
            vm = vm,
            track = track,
            state = lyrics,
            top = top,
            bright = bright,
            onImport = { importLauncher.launch(arrayOf("*/*")) },
            onClose = { fullLyrics = false },
            onNotFoundTimeout = {
                fullLyrics = false
                vm.updateSettings { it.copy(lyricsMode = false) }
            }
        )
    }
    if (showQueue) QueueSheet(vm, now) { showQueue = false }
    if (showSpeed) SpeedDialog(vm, now.speed) { showSpeed = false }
    if (showSleep) SleepDialog(vm, sleep != null) { showSleep = false }
}

@Composable
private fun SeekBar(vm: PlayerViewModel, duration: Long, seed: Long, playing: Boolean, accent: Color) {
    val position by vm.position.collectAsStateWithLifecycle()
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val fraction = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
    val shown = if (dragging) dragValue else fraction
    val label = if (dragging) (dragValue * duration).toLong() else position

    Column {
        WaveBars(
            seed = seed,
            fraction = shown,
            playing = playing && !dragging,
            accent = accent,
            onScrub = {
                dragging = true
                dragValue = it
            },
            onCommit = {
                vm.seekTo((it * duration).toLong())
                dragging = false
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(formatTime(label), style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.7f))
            Text(formatTime(duration), style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.7f))
        }
    }
}

@Composable
private fun WaveBars(
    seed: Long,
    fraction: Float,
    playing: Boolean,
    accent: Color,
    onScrub: (Float) -> Unit,
    onCommit: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val heights = remember(seed) { waveHeights(seed, WaveBarCount) }
    val transition = rememberInfiniteTransition(label = "wave")
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart),
        label = "pulse"
    )
    val inactive = Color.White.copy(alpha = 0.22f)

    val currentScrub by rememberUpdatedState(onScrub)
    val currentCommit by rememberUpdatedState(onCommit)

    Canvas(
        modifier.pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val width = size.width.toFloat().coerceAtLeast(1f)
                var last = (down.position.x / width).coerceIn(0f, 1f)
                currentScrub(last)
                drag(down.id) { change ->
                    last = (change.position.x / width).coerceIn(0f, 1f)
                    currentScrub(last)
                    change.consume()
                }
                currentCommit(last)
            }
        }
    ) {
        val count = heights.size
        val step = size.width / count
        val barWidth = step * 0.56f
        val minHeight = 4.dp.toPx()
        val cursor = fraction * count
        for (index in 0 until count) {
            val near = if (playing) (1f - abs(index - cursor) / 4f).coerceIn(0f, 1f) else 0f
            val wobble = near * 0.18f * sin(pulse * 2f * PI.toFloat() + index)
            val height = (size.height * (0.22f + 0.78f * heights[index]) * (1f + wobble))
                .coerceIn(minHeight, size.height)
            val played = index + 0.5f <= cursor
            drawRoundRect(
                color = if (played) lerp(accent, Color.White, index.toFloat() / count) else inactive,
                topLeft = Offset(step * index + (step - barWidth) / 2f, (size.height - height) / 2f),
                size = Size(barWidth, height),
                cornerRadius = CornerRadius(barWidth / 2f)
            )
        }
        val headWidth = 3.dp.toPx()
        drawRoundRect(
            color = Color.White,
            topLeft = Offset((fraction * size.width - headWidth / 2f).coerceIn(0f, size.width - headWidth), 0f),
            size = Size(headWidth, size.height),
            cornerRadius = CornerRadius(headWidth / 2f)
        )
    }
}

private const val WaveBarCount = 54

private fun waveHeights(seed: Long, count: Int): FloatArray {
    val random = java.util.Random(seed * 7919L + 13L)
    val raw = FloatArray(count) { random.nextFloat() }
    return FloatArray(count) { index ->
        val previous = raw[(index - 1).coerceAtLeast(0)]
        val next = raw[(index + 1).coerceAtMost(count - 1)]
        val smooth = (previous + raw[index] * 2f + next) / 4f
        ((smooth - 0.5f) * 1.7f + 0.5f).coerceIn(0.06f, 1f)
    }
}

@Composable
internal fun Modifier.nowPlayingBackdrop(deep: Color, bright: Color, animated: Boolean = true): Modifier {
    val transition = rememberInfiniteTransition(label = "aurora")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse),
        label = "drift"
    )
    val second = lerp(bright, Pink, 0.5f)
    return drawBehind {
        val phase = if (animated) drift else 0.5f
        drawRect(Brush.verticalGradient(listOf(deep, Ink)))
        drawRect(
            Brush.radialGradient(
                listOf(bright.copy(alpha = 0.45f), Color.Transparent),
                center = Offset(size.width * (0.15f + 0.5f * phase), size.height * 0.18f),
                radius = size.width * 0.9f
            )
        )
        drawRect(
            Brush.radialGradient(
                listOf(second.copy(alpha = 0.3f), Color.Transparent),
                center = Offset(size.width * (0.95f - 0.6f * phase), size.height * 0.62f),
                radius = size.width
            )
        )
    }
}

@Composable
private fun QueueSheet(vm: PlayerViewModel, now: NowPlaying, onDismiss: () -> Unit) {
    val lyricsAvailable by vm.lyricsAvailable.collectAsStateWithLifecycle()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Text(
            text = "Up next · ${now.queue.size} songs",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
        val listState = rememberLazyListState(initialFirstVisibleItemIndex = (now.queueIndex - 1).coerceAtLeast(0))
        val scope = rememberCoroutineScope()
        val currentVisible by remember {
            derivedStateOf { listState.layoutInfo.visibleItemsInfo.any { it.index == now.queueIndex } }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.8f)
        ) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize()
        ) {
            itemsIndexed(now.queue, key = { index, item -> "$index-${item.id}" }) { index, item ->
                val current = index == now.queueIndex
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { vm.playQueueIndex(index) }
                        .padding(start = 24.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Artwork(
                        track = item,
                        modifier = Modifier.size(46.dp),
                        shape = RoundedCornerShape(10.dp),
                        current = current,
                        playing = now.isPlaying
                    )
                    Column(
                        Modifier
                            .weight(1f)
                            .padding(horizontal = 14.dp)
                    ) {
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (item.id in lyricsAvailable) {
                                LyricsBadge()
                                Spacer(Modifier.width(6.dp))
                            }
                            Text(
                                text = item.artist,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                        }
                    }
                    if (!current) {
                        IconButton(onClick = { vm.removeFromQueue(index) }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Remove", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        JumpToCurrentButton(
            visible = now.queueIndex >= 0 && !currentVisible,
            onClick = {
                scope.launch {
                    listState.animateScrollToItem(now.queueIndex, -(listState.layoutInfo.viewportSize.height / 3))
                }
            },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 16.dp)
        )
        }
    }
}

@Composable
private fun SpeedDialog(vm: PlayerViewModel, current: Float, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Playback speed") },
        text = {
            Column {
                listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { speed ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                vm.setSpeed(speed)
                                onDismiss()
                            }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = abs(current - speed) < 0.01f, onClick = null)
                        Spacer(Modifier.width(14.dp))
                        Text("${speed}x", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun SleepDialog(vm: PlayerViewModel, active: Boolean, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sleep timer") },
        text = {
            Column {
                listOf(5, 10, 15, 30, 45, 60).forEach { minutes ->
                    Text(
                        text = "$minutes minutes",
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                vm.startSleepTimer(minutes)
                                onDismiss()
                            }
                            .padding(vertical = 12.dp)
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        dismissButton = {
            if (active) {
                TextButton(onClick = {
                    vm.cancelSleepTimer()
                    onDismiss()
                }) { Text("Turn off timer") }
            }
        }
    )
}
