package com.sonora.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sonora.player.ui.components.SonoraMark
import com.sonora.player.ui.theme.auroraBackdrop
import com.sonora.player.ui.theme.brandBrush
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

private data class Perk(val icon: ImageVector, val title: String, val text: String)

private enum class Demo { Welcome, Library, NowPlaying, Gestures, Lyrics, Collections, Sound, Sleep, Personal }

private data class TourPage(
    val demo: Demo,
    val kicker: String,
    val title: String,
    val lead: String,
    val perks: List<Perk>
)

private val TourPages = listOf(
    TourPage(
        demo = Demo.Welcome,
        kicker = "Welcome",
        title = "Meet Sonora",
        lead = "A music player that looks as good as it sounds. Take a 1-minute tour of everything inside.",
        perks = listOf(
            Perk(Icons.Rounded.LibraryMusic, "Plays your own music", "Every song already on your phone, nothing to upload."),
            Perk(Icons.Rounded.Palette, "Colors from your cover art", "The whole screen glows in the colors of the song."),
            Perk(Icons.Rounded.Lyrics, "Synced lyrics", "Sing along with lines that follow the music."),
            Perk(Icons.Rounded.History, "Pick up where you left off", "Your queue and position are restored when you reopen Sonora.")
        )
    ),
    TourPage(
        demo = Demo.Library,
        kicker = "Library",
        title = "Find anything fast",
        lead = "Browse your music four ways, or just search for it.",
        perks = listOf(
            Perk(Icons.Rounded.LibraryMusic, "Songs, Albums, Artists, Folders", "Switch views with the pills at the top of Library. Come back from a folder and you land right where you were."),
            Perk(Icons.Rounded.Search, "Instant search", "Type a song, album or artist in the Search tab."),
            Perk(Icons.Rounded.Shuffle, "Sort and shuffle", "Change the order or shuffle everything with one tap."),
            Perk(Icons.Rounded.SelectAll, "Select many songs", "Long-press a song to select more, then queue them, add them to a playlist or delete them together."),
            Perk(Icons.Rounded.TouchApp, "Song menu", "Tap the three dots to play next, queue, favorite, add to a playlist, edit info, change cover, go to album or artist, or delete.")
        )
    ),
    TourPage(
        demo = Demo.NowPlaying,
        kicker = "Now Playing",
        title = "Mini player, big stage",
        lead = "The player lives at the bottom of every screen.",
        perks = listOf(
            Perk(Icons.Rounded.TouchApp, "Tap to expand", "Open the full player. Swipe down to close it."),
            Perk(Icons.Rounded.FastForward, "Swipe the mini player", "Left for the next song, right for the previous one. The track glides away and the new one slides in."),
            Perk(Icons.Rounded.GraphicEq, "Waveform seek bar", "Drag along the waves to jump anywhere in the song."),
            Perk(Icons.Rounded.VolumeUp, "Volume keys", "Your hardware keys show Sonora's own volume bar."),
            Perk(Icons.Rounded.Notifications, "Controls everywhere", "Notification, lock screen and Bluetooth buttons work too.")
        )
    ),
    TourPage(
        demo = Demo.Gestures,
        kicker = "Gestures",
        title = "Control it with your thumb",
        lead = "Everything you need is on the cover art.",
        perks = listOf(
            Perk(Icons.Rounded.PlayArrow, "Tap to play or pause", "A single tap on the cover pauses or resumes the music."),
            Perk(Icons.Rounded.FastForward, "Double-tap to skip", "Left side goes back, right side goes forward. Tap again quickly to keep skipping."),
            Perk(Icons.Rounded.Tune, "Choose your interval", "5, 10, 15 or 30 seconds in Settings."),
            Perk(Icons.Rounded.Album, "Swipe the cover", "Left for next song, right for previous song."),
            Perk(Icons.Rounded.Image, "Press and hold", "Long-press the cover to pick a new artwork.")
        )
    ),
    TourPage(
        demo = Demo.Lyrics,
        kicker = "Lyrics",
        title = "Sing along",
        lead = "Sonora finds synced lyrics for your songs automatically.",
        perks = listOf(
            Perk(Icons.Rounded.Lyrics, "Current line under the cover", "Tap it, or the lyrics button in the player, to open the lyrics."),
            Perk(Icons.Rounded.TouchApp, "Tap a line to jump", "Tap any synced line and the song seeks to that moment."),
            Perk(Icons.Rounded.Fullscreen, "Full-screen lyrics", "Expand the lyrics for a landscape stage with big text, drifting snow and the colors of the cover. The screen stays awake."),
            Perk(Icons.Rounded.Lock, "Lock the screen", "In full screen, tap the lock so stray touches do nothing. Controls fade after a few seconds and return when you touch."),
            Perk(Icons.Rounded.Search, "Search or import", "Wrong lyrics? Search again, or import your own .lrc file."),
            Perk(Icons.Rounded.Notifications, "Lyrics in the notification", "See the current line on your lock screen and notification shade."),
            Perk(Icons.Rounded.Edit, "Clean song names", "Messy file names are tidied before searching, and a good lyrics match can fill in the proper title and artist.")
        )
    ),
    TourPage(
        demo = Demo.Collections,
        kicker = "Collections",
        title = "Keep what you love",
        lead = "Favorites, playlists and a queue you fully control.",
        perks = listOf(
            Perk(Icons.Rounded.Favorite, "Favorites", "Tap the heart under the cover. All hearts live in Playlists."),
            Perk(Icons.Rounded.PlaylistAdd, "Playlists", "Create your own and add songs from any menu."),
            Perk(Icons.Rounded.QueueMusic, "Queue", "Reorder by dragging, remove songs, or save the queue as a playlist."),
            Perk(Icons.Rounded.Album, "Recently added and Most played", "Smart lists that build themselves.")
        )
    ),
    TourPage(
        demo = Demo.Sound,
        kicker = "Sound",
        title = "Make it sound right",
        lead = "Fine-tune playback to your ears and your headphones.",
        perks = listOf(
            Perk(Icons.Rounded.Equalizer, "Equalizer and bass boost", "Presets, individual bands and extra low end."),
            Perk(Icons.Rounded.VolumeUp, "Volume leveling", "Keeps loud and quiet songs at a similar level."),
            Perk(Icons.Rounded.FastForward, "Skip silence", "Jumps over silent gaps inside songs."),
            Perk(Icons.Rounded.Speed, "Playback speed", "From 0.5x to 2x, right from the player.")
        )
    ),
    TourPage(
        demo = Demo.Sleep,
        kicker = "Sleep timer",
        title = "Fall asleep to music",
        lead = "Set it once and Sonora stops by itself.",
        perks = listOf(
            Perk(Icons.Rounded.Bedtime, "5 to 60 minutes", "Tap the moon in the player. Choose 5, 10, 15, 30, 45 or 60. The countdown shows right on the icon."),
            Perk(Icons.Rounded.Pause, "Pauses when time is up", "Playback stops at zero. Tap the moon again to turn the timer off early.")
        )
    ),
    TourPage(
        demo = Demo.Personal,
        kicker = "Make it yours",
        title = "Your music, your rules",
        lead = "Everything is in the Settings tab whenever you want it.",
        perks = listOf(
            Perk(Icons.Rounded.Palette, "Themes and dynamic colors", "Light, dark, AMOLED, or match your wallpaper."),
            Perk(Icons.Rounded.CloudDownload, "Online lookups are optional", "Lyrics and missing covers come from lrclib.net, iTunes and Deezer. Turn off anytime."),
            Perk(Icons.Rounded.Backup, "Backup and restore", "Move favorites, playlists and settings to a new phone."),
            Perk(Icons.Rounded.Tune, "Hide short clips", "Audio shorter than 30 seconds stays out of your library. Switch it off in Settings."),
            Perk(Icons.Rounded.Edit, "Your files stay untouched", "Edited titles and artists are saved inside Sonora. The audio files are never modified."),
            Perk(Icons.Rounded.Folder, "Replay this tour", "Settings has an App tour row if you ever want it again.")
        )
    )
)

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val pagerState = rememberPagerState(pageCount = { TourPages.size })
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val scheme = MaterialTheme.colorScheme
    val last = pagerState.currentPage == TourPages.lastIndex

    BackHandler {
        if (pagerState.currentPage > 0) {
            scope.launch { pagerState.animateScrollToPage(pagerState.currentPage - 1) }
        } else {
            onFinish()
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(scheme.background)
            .auroraBackdrop()
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${pagerState.currentPage + 1} / ${TourPages.size}",
                    style = MaterialTheme.typography.labelLarge,
                    color = scheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                AnimatedVisibility(visible = !last, enter = fadeIn(), exit = fadeOut()) {
                    Text(
                        text = "Skip",
                        style = MaterialTheme.typography.labelLarge,
                        color = scheme.primary,
                        modifier = Modifier
                            .clip(CircleShape)
                            .clickable { onFinish() }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) { index ->
                val offset = (pagerState.currentPage - index) + pagerState.currentPageOffsetFraction
                TourPageContent(
                    page = TourPages[index],
                    active = pagerState.currentPage == index,
                    modifier = Modifier.graphicsLayer {
                        val distance = abs(offset).coerceIn(0f, 1f)
                        alpha = 1f - 0.6f * distance
                        translationX = -offset * size.width * 0.12f
                        scaleX = 1f - 0.05f * distance
                        scaleY = 1f - 0.05f * distance
                    }
                )
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    repeat(TourPages.size) { index ->
                        val selected = pagerState.currentPage == index
                        val width by animateFloatAsState(if (selected) 22f else 7f, tween(260), label = "dotWidth")
                        val color by animateColorAsState(
                            if (selected) scheme.primary else scheme.onSurface.copy(alpha = 0.22f),
                            tween(260),
                            label = "dotColor"
                        )
                        Box(
                            Modifier
                                .height(7.dp)
                                .width(width.dp)
                                .clip(CircleShape)
                                .background(color)
                        )
                    }
                }
                val onBrand = scheme.onPrimary
                Row(
                    Modifier
                        .clip(CircleShape)
                        .background(brandBrush(), CircleShape)
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            if (last) {
                                onFinish()
                            } else {
                                scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                            }
                        }
                        .padding(horizontal = 26.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (last) "Start listening" else "Next",
                        color = onBrand,
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 15.sp)
                    )
                    if (last) {
                        Icon(Icons.Rounded.Check, contentDescription = null, tint = onBrand, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun TourPageContent(page: TourPage, active: Boolean, modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme
    Column(
        modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .weight(0.46f),
            contentAlignment = Alignment.Center
        ) {
            DemoStage(page.demo, active)
        }
        Column(
            Modifier
                .fillMaxWidth()
                .weight(0.54f)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = page.kicker.uppercase(),
                style = MaterialTheme.typography.labelMedium.copy(brush = brandBrush(), letterSpacing = 1.8.sp)
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = page.title,
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = scheme.onBackground
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = page.lead,
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))
            page.perks.forEachIndexed { index, perk ->
                var shown by remember(page.demo) { mutableIntStateOf(0) }
                LaunchedEffect(active) {
                    if (active) {
                        delay(120L + index * 110L)
                        shown = 1
                    } else {
                        shown = 0
                    }
                }
                AnimatedVisibility(
                    visible = shown == 1,
                    enter = fadeIn(tween(320)) + slideInVertically(tween(320, easing = FastOutSlowInEasing)) { it / 2 }
                ) {
                    PerkRow(perk)
                }
            }
        }
    }
}

@Composable
private fun PerkRow(perk: Perk) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(scheme.primary.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(perk.icon, contentDescription = null, tint = scheme.primary, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(perk.title, style = MaterialTheme.typography.titleMedium.copy(fontSize = 15.sp), color = scheme.onBackground)
            Text(
                perk.text,
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun DemoStage(demo: Demo, active: Boolean) {
    val scheme = MaterialTheme.colorScheme
    Box(
        Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.92f)
            .clip(RoundedCornerShape(32.dp))
            .background(scheme.surfaceContainerHigh.copy(alpha = 0.72f))
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        listOf(scheme.primary.copy(alpha = 0.22f), Color.Transparent),
                        center = Offset(size.width * 0.2f, 0f),
                        radius = size.width * 0.9f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(scheme.secondary.copy(alpha = 0.18f), Color.Transparent),
                        center = Offset(size.width, size.height),
                        radius = size.width * 0.9f
                    )
                )
            },
        contentAlignment = Alignment.Center
    ) {
        when (demo) {
            Demo.Welcome -> WelcomeDemo()
            Demo.Library -> LibraryDemo(active)
            Demo.NowPlaying -> NowPlayingDemo()
            Demo.Gestures -> GesturesDemo()
            Demo.Lyrics -> LyricsDemo()
            Demo.Collections -> CollectionsDemo()
            Demo.Sound -> SoundDemo()
            Demo.Sleep -> SleepDemo()
            Demo.Personal -> PersonalDemo()
        }
    }
}

@Composable
private fun loop(periodMs: Int, easing: androidx.compose.animation.core.Easing = LinearEasing): Float {
    val transition = rememberInfiniteTransition(label = "demoLoop")
    val value by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(periodMs, easing = easing), RepeatMode.Restart),
        label = "demoValue"
    )
    return value
}

@Composable
private fun pingPong(periodMs: Int): Float {
    val transition = rememberInfiniteTransition(label = "demoPing")
    val value by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(periodMs, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "demoPingValue"
    )
    return value
}

@Composable
private fun WelcomeDemo() {
    val scheme = MaterialTheme.colorScheme
    val t = loop(2600)
    Box(contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(220.dp)) {
            for (ring in 0 until 3) {
                val phase = (t + ring / 3f) % 1f
                drawCircle(
                    color = scheme.primary.copy(alpha = (1f - phase) * 0.35f),
                    radius = size.minDimension * (0.28f + 0.22f * phase),
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
        SonoraMark(size = 96.dp, dancing = true)
    }
}

@Composable
private fun LibraryDemo(active: Boolean) {
    val scheme = MaterialTheme.colorScheme
    val labels = listOf("Songs", "Albums", "Artists", "Folders")
    var selected by remember { mutableIntStateOf(0) }
    LaunchedEffect(active) {
        if (!active) return@LaunchedEffect
        while (true) {
            delay(1500)
            selected = (selected + 1) % labels.size
        }
    }
    Column(
        Modifier
            .fillMaxWidth()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(CircleShape)
                .background(scheme.surfaceContainerHighest)
                .padding(4.dp)
        ) {
            labels.forEachIndexed { index, label ->
                val on = index == selected
                val fill by animateFloatAsState(if (on) 1f else 0f, tween(260), label = "demoPill")
                val tint by animateColorAsState(
                    if (on) scheme.onPrimary else scheme.onSurfaceVariant,
                    tween(260),
                    label = "demoPillTint"
                )
                Box(
                    Modifier
                        .weight(1f)
                        .clip(CircleShape)
                        .background(brandBrush(), CircleShape, alpha = fill)
                        .padding(vertical = 9.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, color = tint, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                }
            }
        }
        val icons = listOf(Icons.Rounded.LibraryMusic, Icons.Rounded.Album, Icons.Rounded.Person, Icons.Rounded.Folder)
        repeat(3) { row ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(if (selected == 2) 23.dp else 12.dp))
                        .background(Brush.linearGradient(listOf(scheme.primary.copy(alpha = 0.55f), scheme.secondary.copy(alpha = 0.55f)))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icons[selected], contentDescription = null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        Modifier
                            .fillMaxWidth(0.62f - row * 0.1f)
                            .height(9.dp)
                            .clip(CircleShape)
                            .background(scheme.onSurface.copy(alpha = 0.55f))
                    )
                    Box(
                        Modifier
                            .fillMaxWidth(0.4f)
                            .height(7.dp)
                            .clip(CircleShape)
                            .background(scheme.onSurface.copy(alpha = 0.22f))
                    )
                }
            }
        }
    }
}

@Composable
private fun NowPlayingDemo() {
    val scheme = MaterialTheme.colorScheme
    val swipe = pingPong(1800)
    val dx = (swipe - 0.5f) * 2f
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .graphicsLayer { translationX = dx * 36.dp.toPx() }
                    .clip(RoundedCornerShape(30.dp))
                    .background(scheme.surfaceContainerHighest)
                    .background(Brush.horizontalGradient(listOf(scheme.primary.copy(alpha = 0.3f), Color.Transparent)))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(scheme.primary, scheme.secondary)))
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        Modifier
                            .fillMaxWidth(0.6f)
                            .height(9.dp)
                            .clip(CircleShape)
                            .background(scheme.onSurface.copy(alpha = 0.6f))
                    )
                    Box(
                        Modifier
                            .fillMaxWidth(0.35f)
                            .height(7.dp)
                            .clip(CircleShape)
                            .background(scheme.onSurface.copy(alpha = 0.25f))
                    )
                }
                Icon(Icons.Rounded.FastForward, contentDescription = null, tint = scheme.onSurface.copy(alpha = 0.7f))
            }
            Box(
                Modifier
                    .graphicsLayer { translationX = dx * 90.dp.toPx() }
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.35f))
            )
        }
        WaveStrip(progress = loop(5200))
    }
}

@Composable
private fun WaveStrip(progress: Float) {
    val scheme = MaterialTheme.colorScheme
    val count = 40
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
    ) {
        val step = size.width / count
        val barWidth = step * 0.56f
        val cursor = progress * count
        for (i in 0 until count) {
            val shape = 0.35f + 0.65f * abs(sin(i * 0.55f) * sin(i * 0.17f + 1f))
            val barHeight = (size.height * shape).coerceAtLeast(4.dp.toPx())
            drawRoundRect(
                color = if (i + 0.5f <= cursor) scheme.primary else scheme.onSurface.copy(alpha = 0.2f),
                topLeft = Offset(step * i + (step - barWidth) / 2f, (size.height - barHeight) / 2f),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2f)
            )
        }
        val head = 3.dp.toPx()
        drawRoundRect(
            color = scheme.onSurface,
            topLeft = Offset((progress * size.width - head / 2f).coerceIn(0f, size.width - head), 0f),
            size = Size(head, size.height),
            cornerRadius = CornerRadius(head / 2f)
        )
    }
}

@Composable
private fun GesturesDemo() {
    val scheme = MaterialTheme.colorScheme
    val t = loop(3200)
    val leftOn = t < 0.5f
    val local = if (leftOn) t / 0.5f else (t - 0.5f) / 0.5f
    val pulse = (1f - abs(local - 0.35f) * 2.2f).coerceIn(0f, 1f)
    Box(
        Modifier
            .size(190.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(scheme.primary, scheme.secondary, scheme.tertiary)))
    ) {
        Row(Modifier.fillMaxSize()) {
            repeat(2) { side ->
                val lit = (side == 0) == leftOn
                val strength = if (lit) pulse else 0f
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(SkipShape(left = side == 0))
                        .background(Color.Black.copy(alpha = 0.38f * strength)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.alpha(strength)
                    ) {
                        Icon(
                            imageVector = if (side == 0) Icons.Rounded.FastRewind else Icons.Rounded.FastForward,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(34.dp)
                        )
                        Text(
                            text = if (side == 0) "-10s" else "+10s",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
        Box(
            Modifier
                .align(if (leftOn) Alignment.CenterStart else Alignment.CenterEnd)
                .padding(horizontal = 34.dp)
                .size((26f + 8f * pulse).dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.55f))
        )
    }
}

@Composable
private fun LyricsDemo() {
    val scheme = MaterialTheme.colorScheme
    val lines = listOf("Lights are fading slow", "Hold the moment close", "Let the music show", "Where the night goes")
    val t = loop(lines.size * 1800)
    val position = t * lines.size
    val current = position.toInt().coerceIn(0, lines.lastIndex)
    val glide = ((position - current) * 3f).coerceIn(0f, 1f)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 26.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        lines.forEachIndexed { index, line ->
            val distance = abs(index - current)
            val isCurrent = index == current
            val target = when {
                isCurrent -> 1f
                distance == 1 -> 0.4f
                else -> 0.2f
            }
            val alpha by animateFloatAsState(target, tween(400), label = "lyricAlpha")
            Text(
                text = line,
                color = if (isCurrent) scheme.onSurface else scheme.onSurface.copy(alpha = alpha),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontSize = if (isCurrent) 24.sp else 19.sp,
                    fontWeight = FontWeight.Bold
                ),
                modifier = Modifier.graphicsLayer {
                    translationY = if (isCurrent) (1f - glide) * 6.dp.toPx() else 0f
                }
            )
        }
    }
}

@Composable
private fun CollectionsDemo() {
    val scheme = MaterialTheme.colorScheme
    val t = loop(2400)
    val pop = if (t < 0.25f) sin(t / 0.25f * PI.toFloat()) else 0f
    val filled = t in 0.12f..0.9f
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(scheme.secondary.copy(alpha = if (filled) 0.22f else 0.1f))
            )
            Icon(
                imageVector = Icons.Rounded.Favorite,
                contentDescription = null,
                tint = if (filled) scheme.secondary else scheme.onSurface.copy(alpha = 0.35f),
                modifier = Modifier
                    .size(52.dp)
                    .graphicsLayer {
                        val scale = 1f + 0.45f * pop
                        scaleX = scale
                        scaleY = scale
                    }
            )
        }
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            repeat(3) { index ->
                val reveal = ((t * 3f) - index * 0.35f).coerceIn(0f, 1f)
                Row(
                    Modifier
                        .width(124.dp)
                        .graphicsLayer {
                            alpha = 0.35f + 0.65f * reveal
                            translationX = (1f - reveal) * 14.dp.toPx()
                        }
                        .clip(RoundedCornerShape(14.dp))
                        .background(scheme.surfaceContainerHighest)
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(26.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Brush.linearGradient(listOf(scheme.primary, scheme.secondary)))
                    )
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier
                            .fillMaxWidth(0.9f - index * 0.18f)
                            .height(7.dp)
                            .clip(CircleShape)
                            .background(scheme.onSurface.copy(alpha = 0.45f))
                    )
                }
            }
        }
    }
}

@Composable
private fun SoundDemo() {
    val scheme = MaterialTheme.colorScheme
    val t = loop(2200)
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(140.dp)
            .padding(horizontal = 28.dp)
    ) {
        val count = 9
        val step = size.width / count
        val barWidth = step * 0.5f
        for (i in 0 until count) {
            val wave = 0.5f + 0.5f * sin((t * 2f * PI.toFloat()) + i * 0.8f)
            val capped = size.height * (0.2f + 0.7f * wave).coerceIn(0.2f, 1f)
            drawRoundRect(
                brush = Brush.verticalGradient(
                    listOf(scheme.secondary, scheme.primary),
                    startY = size.height - capped,
                    endY = size.height
                ),
                topLeft = Offset(step * i + (step - barWidth) / 2f, size.height - capped),
                size = Size(barWidth, capped),
                cornerRadius = CornerRadius(barWidth / 2f)
            )
        }
    }
}

@Composable
private fun SleepDemo() {
    val scheme = MaterialTheme.colorScheme
    val t = loop(9000)
    val total = 15 * 60
    val remaining = (total * (1f - t)).toInt()
    val text = "%d:%02d".format(remaining / 60, remaining % 60)
    Box(contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(170.dp)) {
            val stroke = 8.dp.toPx()
            drawCircle(
                color = scheme.onSurface.copy(alpha = 0.12f),
                radius = (size.minDimension - stroke) / 2f,
                style = Stroke(width = stroke)
            )
            drawArc(
                brush = Brush.sweepGradient(listOf(scheme.primary, scheme.secondary, scheme.primary)),
                startAngle = -90f,
                sweepAngle = 360f * (1f - t),
                useCenter = false,
                topLeft = Offset(stroke / 2f, stroke / 2f),
                size = Size(size.width - stroke, size.height - stroke),
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Rounded.Bedtime, contentDescription = null, tint = scheme.primary, modifier = Modifier.size(34.dp))
            Spacer(Modifier.height(4.dp))
            Text(text, style = MaterialTheme.typography.headlineSmall, color = scheme.onSurface)
        }
    }
}

@Composable
private fun PersonalDemo() {
    val scheme = MaterialTheme.colorScheme
    val palettes = listOf(
        listOf(Color(0xFFC9B6FF), Color(0xFFFFA6DA), Color(0xFF8FE0D0)),
        listOf(Color(0xFFFFB86B), Color(0xFFFF7A90), Color(0xFFFFE08A)),
        listOf(Color(0xFF7CC4FF), Color(0xFF7AF0C8), Color(0xFFB7A6FF)),
        listOf(Color(0xFFA5E887), Color(0xFFFFD36B), Color(0xFF6FD6C4))
    )
    var index by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1700)
            index = (index + 1) % palettes.size
        }
    }
    val first by animateColorAsState(palettes[index][0], tween(600), label = "paletteA")
    val second by animateColorAsState(palettes[index][1], tween(600), label = "paletteB")
    val third by animateColorAsState(palettes[index][2], tween(600), label = "paletteC")
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Box(
            Modifier
                .size(width = 200.dp, height = 96.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(Brush.linearGradient(listOf(first, second, third)))
        ) {
            Row(
                Modifier
                    .align(Alignment.Center)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.3f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Palette, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Dynamic colors", color = Color.White, style = MaterialTheme.typography.labelMedium)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            palettes.forEachIndexed { i, colors ->
                val selected = i == index
                val scale by animateFloatAsState(if (selected) 1.2f else 1f, tween(300), label = "swatch")
                Box(
                    Modifier
                        .size(30.dp)
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                        }
                        .clip(CircleShape)
                        .background(Brush.linearGradient(colors))
                        .background(if (selected) Color.Transparent else scheme.surface.copy(alpha = 0.25f))
                )
            }
        }
    }
}
