package com.sonora.player.ui

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.sonora.player.PlayerViewModel

@Composable
fun PartySheet(vm: PlayerViewModel, onDismiss: () -> Unit) {
    val state by vm.party.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 24.dp)
                .padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Party mode", style = MaterialTheme.typography.titleLarge)
            val url = state.url
            if (!state.running || url == null) {
                Text(
                    text = "Let friends on the same Wi-Fi or your hotspot request songs from their own phones. They only scan a QR code. No app and no internet needed.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = scheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                state.error?.let {
                    Text(it, style = MaterialTheme.typography.bodyMedium, color = scheme.error, textAlign = TextAlign.Center)
                }
                Button(onClick = { vm.startParty() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Start party")
                }
            } else {
                QrCode(content = url, size = 250.dp)
                Text(
                    text = "Friends scan this with their phone camera, then request songs and vote. A song with 2 or more votes jumps ahead in the queue.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = url,
                    style = MaterialTheme.typography.labelMedium,
                    color = scheme.primary,
                    textAlign = TextAlign.Center
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(
                        onClick = {
                            val send = Intent(Intent.ACTION_SEND)
                                .setType("text/plain")
                                .putExtra(Intent.EXTRA_TEXT, "Join my Sonora party and request songs: $url")
                            context.startActivity(Intent.createChooser(send, "Share party link"))
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Share link") }
                    Button(onClick = { vm.stopParty() }, modifier = Modifier.weight(1f)) { Text("Stop party") }
                }
                if (state.requests.isNotEmpty()) {
                    Text(
                        text = "Requests",
                        style = MaterialTheme.typography.labelLarge,
                        color = scheme.primary,
                        modifier = Modifier.fillMaxWidth()
                    )
                    state.requests.take(8).forEach { request ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(scheme.surfaceVariant.copy(alpha = 0.5f))
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(request.title, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    request.artist,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = scheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text("\u25B2 ${request.votes}", style = MaterialTheme.typography.labelLarge, color = scheme.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QrCode(content: String, size: Dp) {
    val matrix = remember(content) {
        runCatching {
            QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, 0, 0, mapOf(EncodeHintType.MARGIN to 1))
        }.getOrNull()
    }
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(22.dp))
            .background(Color.White)
            .padding(14.dp)
    ) {
        if (matrix != null) {
            Canvas(Modifier.fillMaxSize()) {
                val cell = this.size.width / matrix.width
                for (y in 0 until matrix.height) {
                    for (x in 0 until matrix.width) {
                        if (matrix.get(x, y)) {
                            drawRect(
                                color = Color(0xFF1B1A4B),
                                topLeft = Offset(x * cell, y * cell),
                                size = Size(cell + 0.6f, cell + 0.6f)
                            )
                        }
                    }
                }
            }
        }
    }
}
