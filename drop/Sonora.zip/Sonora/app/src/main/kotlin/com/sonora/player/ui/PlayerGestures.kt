package com.sonora.player.ui

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.AbsoluteRoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.onLongClick
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.sonora.player.PlayerViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

private const val SkipWindowMs = 700L
private const val SkipHoldMs = 650L
private const val SwipeCommitFraction = 0.25f

@Stable
internal class PlayerGestureState {
    var dragX by mutableFloatStateOf(0f)
    var widthPx by mutableFloatStateOf(1f)
    var side by mutableIntStateOf(0)
        private set
    var seconds by mutableIntStateOf(0)
        private set
    var zone by mutableStateOf(Rect.Zero)
        private set
    val alpha = Animatable(0f)
    var rootCoords: LayoutCoordinates? = null
    var coverCoords: LayoutCoordinates? = null
    private var lastAt = 0L
    private var job: Job? = null

    fun coverRect(): Rect? {
        val root = rootCoords ?: return null
        val cover = coverCoords ?: return null
        if (!root.isAttached || !cover.isAttached) return null
        return root.localBoundingBoxOf(cover, false)
    }

    fun chains(direction: Int, at: Long): Boolean =
        side == direction && at - lastAt in 0L..SkipWindowMs

    fun register(direction: Int, step: Int, scope: CoroutineScope) {
        val now = SystemClock.uptimeMillis()
        seconds = if (chains(direction, now)) seconds + step else step
        side = direction
        lastAt = now
        val base = coverRect() ?: rootCoords?.size?.let {
            Rect(0f, it.height * 0.25f, it.width.toFloat(), it.height * 0.75f)
        } ?: Rect.Zero
        val half = base.width / 2f
        zone = if (direction < 0) {
            Rect(base.left, base.top, base.left + half, base.bottom)
        } else {
            Rect(base.left + half, base.top, base.right, base.bottom)
        }
        job?.cancel()
        job = scope.launch {
            alpha.snapTo(1f)
            delay(SkipHoldMs)
            alpha.animateTo(0f, tween(260))
        }
    }
}

@Composable
internal fun Modifier.playerGestures(
    vm: PlayerViewModel,
    state: PlayerGestureState,
    skipSeconds: Int,
    onCoverLongPress: () -> Unit
): Modifier {
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    var settleJob by remember { mutableStateOf<Job?>(null) }
    val step by rememberUpdatedState(skipSeconds)
    val currentLongPress by rememberUpdatedState(onCoverLongPress)

    val skip: (Int) -> Unit = { direction ->
        state.register(direction, step, scope)
        vm.seekBy(direction * step * 1000L)
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }
    val currentSkip by rememberUpdatedState(skip)

    val settle: () -> Unit = {
        settleJob?.cancel()
        settleJob = scope.launch {
            animate(
                initialValue = state.dragX,
                targetValue = 0f,
                animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)
            ) { value, _ -> state.dragX = value }
        }
    }
    val currentSettle by rememberUpdatedState(settle)

    return this
        .onSizeChanged { state.widthPx = it.width.toFloat().coerceAtLeast(1f) }
        .onGloballyPositioned { state.rootCoords = it }
        .pointerInput(Unit) {
            detectTapGestures(
                onTap = { offset ->
                    val direction = if (offset.x < size.width / 2f) -1 else 1
                    val tappedAt = SystemClock.uptimeMillis() - viewConfiguration.doubleTapTimeoutMillis
                    if (state.chains(direction, tappedAt)) {
                        currentSkip(direction)
                    } else {
                        vm.togglePlay()
                    }
                },
                onDoubleTap = { offset ->
                    currentSkip(if (offset.x < size.width / 2f) -1 else 1)
                },
                onLongPress = { offset ->
                    if (state.coverRect()?.contains(offset) == true) currentLongPress()
                }
            )
        }
        .pointerInput(Unit) {
            val tracker = VelocityTracker()
            detectHorizontalDragGestures(
                onDragStart = {
                    settleJob?.cancel()
                    tracker.resetTracking()
                },
                onDragEnd = {
                    val velocity = tracker.calculateVelocity().x
                    val distance = state.dragX
                    val byDistance = abs(distance) > state.widthPx * SwipeCommitFraction
                    val byFling = abs(velocity) > 900.dp.toPx() &&
                        abs(distance) > 24.dp.toPx() &&
                        velocity * distance > 0f
                    if (byDistance || byFling) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        if (distance < 0f) vm.next() else vm.previous()
                    }
                    currentSettle()
                },
                onDragCancel = { currentSettle() },
                onHorizontalDrag = { change, amount ->
                    tracker.addPosition(change.uptimeMillis, change.position)
                    change.consume()
                    state.dragX = (state.dragX + amount).coerceIn(-state.widthPx, state.widthPx)
                }
            )
        }
}

internal fun Modifier.swipeFollow(state: PlayerGestureState): Modifier = graphicsLayer {
    val progress = (abs(state.dragX) / state.widthPx).coerceIn(0f, 1f)
    val shrink = 1f - 0.08f * progress
    translationX = state.dragX
    alpha = 1f - 0.45f * progress
    scaleX = shrink
    scaleY = shrink
}

internal fun Modifier.coverSemantics(
    vm: PlayerViewModel,
    skipSeconds: Int,
    playing: Boolean,
    onLongPress: () -> Unit
): Modifier = semantics {
    contentDescription = "Album cover"
    onClick(label = if (playing) "Pause" else "Play") {
        vm.togglePlay()
        true
    }
    onLongClick(label = "Change cover art") {
        onLongPress()
        true
    }
    customActions = listOf(
        CustomAccessibilityAction(if (playing) "Pause" else "Play") {
            vm.togglePlay()
            true
        },
        CustomAccessibilityAction("Seek back $skipSeconds seconds") {
            vm.seekBy(-skipSeconds * 1000L)
            true
        },
        CustomAccessibilityAction("Seek forward $skipSeconds seconds") {
            vm.seekBy(skipSeconds * 1000L)
            true
        },
        CustomAccessibilityAction("Next song") {
            vm.next()
            true
        },
        CustomAccessibilityAction("Previous song") {
            vm.previous()
            true
        }
    )
}

@Composable
internal fun BoxScope.SkipOverlay(state: PlayerGestureState) {
    val density = LocalDensity.current
    val left = state.side < 0
    val zone = state.zone
    val shape = if (left) {
        AbsoluteRoundedCornerShape(26.dp, 14.dp, 14.dp, 26.dp)
    } else {
        AbsoluteRoundedCornerShape(14.dp, 26.dp, 26.dp, 14.dp)
    }
    Box(
        Modifier
            .align(AbsoluteAlignment.TopLeft)
            .absoluteOffset { IntOffset(zone.left.roundToInt(), zone.top.roundToInt()) }
            .size(with(density) { zone.width.toDp() }, with(density) { zone.height.toDp() })
            .padding(6.dp)
            .graphicsLayer { alpha = state.alpha.value }
            .clip(shape)
            .background(Color.White.copy(alpha = 0.22f))
            .clearAndSetSemantics { },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = if (left) Icons.Rounded.FastRewind else Icons.Rounded.FastForward,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(40.dp)
            )
            Text(
                text = "${if (left) "-" else "+"}${state.seconds}s",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
