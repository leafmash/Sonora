package com.sonora.player.ui

import android.os.Build
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.sonora.player.ui.components.SonoraMark
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.BuildConfig
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.Route
import androidx.compose.ui.unit.sp
import com.sonora.player.data.ThemeMode
import com.sonora.player.ui.components.PillTabs
import com.sonora.player.ui.components.ScreenHeader

@Composable
fun SettingsScreen(vm: PlayerViewModel, scrollState: ScrollState) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val library by vm.library.collectAsStateWithLifecycle()

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(scrollState)
            .padding(bottom = 24.dp)
    ) {
        ScreenHeader(title = "Settings", kicker = "Make it yours")

        SectionLabel("Appearance")
        PillTabs(
            labels = ThemeMode.entries.map { if (it == ThemeMode.Amoled) "AMOLED" else it.name },
            selected = settings.themeMode.ordinal,
            onSelect = { index -> vm.updateSettings { it.copy(themeMode = ThemeMode.entries[index]) } },
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            SettingRow(
                title = "Dynamic colors",
                subtitle = "Match the app to your wallpaper",
                onClick = { vm.updateSettings { it.copy(dynamicColor = !it.dynamicColor) } }
            ) {
                Switch(
                    checked = settings.dynamicColor,
                    onCheckedChange = { value -> vm.updateSettings { it.copy(dynamicColor = value) } }
                )
            }
        }

        SectionLabel("Library")
        SettingRow(
            title = "Hide short clips",
            subtitle = "Skip audio shorter than 30 seconds",
            onClick = { vm.updateSettings { it.copy(hideShort = !it.hideShort) } }
        ) {
            Switch(
                checked = settings.hideShort,
                onCheckedChange = { value -> vm.updateSettings { it.copy(hideShort = value) } }
            )
        }
        SettingRow(
            title = "Find lyrics online",
            subtitle = "Sends song title and artist to lrclib.net",
            onClick = { vm.updateSettings { it.copy(onlineLyrics = !it.onlineLyrics) } }
        ) {
            Switch(
                checked = settings.onlineLyrics,
                onCheckedChange = { value -> vm.updateSettings { it.copy(onlineLyrics = value) } }
            )
        }
        SettingRow(
            title = "Find cover art online",
            subtitle = "Fills songs without artwork using title and artist (iTunes, Deezer)",
            onClick = { vm.updateSettings { it.copy(onlineCovers = !it.onlineCovers) } }
        ) {
            Switch(
                checked = settings.onlineCovers,
                onCheckedChange = { value -> vm.updateSettings { it.copy(onlineCovers = value) } }
            )
        }
        SettingRow(
            title = "Rescan library",
            subtitle = "${library.tracks.size} songs  ·  ${library.albums.size} albums  ·  ${library.artists.size} artists",
            onClick = vm::refresh
        )

        SectionLabel("Playback")
        SettingRow(
            title = "Skip silence",
            subtitle = "Jump over silent parts inside songs",
            onClick = { vm.updateSettings { it.copy(skipSilence = !it.skipSilence) } }
        ) {
            Switch(
                checked = settings.skipSilence,
                onCheckedChange = { value -> vm.updateSettings { it.copy(skipSilence = value) } }
            )
        }
        SettingRow(
            title = "Volume leveling",
            subtitle = "Keep loud and quiet songs at a similar level",
            onClick = { vm.updateSettings { it.copy(normalizeVolume = !it.normalizeVolume) } }
        ) {
            Switch(
                checked = settings.normalizeVolume,
                onCheckedChange = { value -> vm.updateSettings { it.copy(normalizeVolume = value) } }
            )
        }
        SettingRow(
            title = "Lyrics in notification",
            subtitle = "Show the current line instead of the artist name",
            onClick = { vm.updateSettings { it.copy(notificationLyrics = !it.notificationLyrics) } }
        ) {
            Switch(
                checked = settings.notificationLyrics,
                onCheckedChange = { value -> vm.updateSettings { it.copy(notificationLyrics = value) } }
            )
        }
        SettingRow(
            title = "Equalizer",
            subtitle = "Presets, bands, bass boost",
            onClick = { vm.open(Route.EqualizerRoute) }
        )

        SectionLabel("About")
        SettingRow(
            title = "About Sonora",
            subtitle = "Version ${BuildConfig.VERSION_NAME}  ·  App and developer details",
            onClick = { vm.open(Route.AboutRoute) },
            trailing = { SonoraMark(size = 36.dp) }
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        letterSpacing = 1.6.sp,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 4.dp)
    )
}

@Composable
private fun SettingRow(
    title: String,
    subtitle: String? = null,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit = {}
) {
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        trailing()
    }
}
