package com.sonora.player.ui

import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.sonora.player.data.BackupCodec
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.sonora.player.ui.components.SonoraMark
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.BuildConfig
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.BatchIdentify
import com.sonora.player.data.Route
import com.sonora.player.data.isUnidentified
import com.sonora.player.data.SkipSecondsOptions
import androidx.compose.ui.unit.sp
import com.sonora.player.data.ThemeMode
import com.sonora.player.ui.components.PillTabs
import com.sonora.player.ui.components.ScreenHeader
import com.sonora.player.data.CrossfadeOptions
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.text.style.TextOverflow

@Composable
fun SettingsScreen(vm: PlayerViewModel, scrollState: ScrollState) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val library by vm.library.collectAsStateWithLifecycle()
    var confirmRestore by remember { mutableStateOf(false) }
    var showHidden by remember { mutableStateOf(false) }
    var showParty by remember { mutableStateOf(false) }
    var showKey by remember { mutableStateOf(false) }
    var showBatch by remember { mutableStateOf(false) }
    val edits by vm.edits.collectAsStateWithLifecycle()
    val unidentified = remember(library, edits) { library.tracks.count { it.id !in edits && isUnidentified(it) } }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> uri?.let(vm::exportBackup) }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let(vm::importBackup) }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(scrollState)
            .padding(bottom = 24.dp)
    ) {
        ScreenHeader(title = "Settings", kicker = "Make it yours")

        SectionLabel("Appearance")
        PillTabs(
            labels = ThemeMode.entries.map { if (it == ThemeMode.Amoled) "AMOLED" else it.name },
            selected = settings.themeMode.ordinal,
            onSelect = { index -> vm.updateSettings { it.copy(themeMode = ThemeMode.entries[index]) } },
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            SettingRow(
                title = "Dynamic colors",
                subtitle = "Match the app to your wallpaper",
                onClick = { vm.updateSettings { it.copy(dynamicColor = !it.dynamicColor) } }
            ) {
                Switch(
                    checked = settings.dynamicColor,
                    onCheckedChange = { value -> vm.updateSettings { it.copy(dynamicColor = value) } }
                )
            }
        }

        SectionLabel("Library")
        SettingRow(
            title = "Hide short clips",
            subtitle = "Skip audio shorter than 30 seconds",
            onClick = { vm.updateSettings { it.copy(hideShort = !it.hideShort) } }
        ) {
            Switch(
                checked = settings.hideShort,
                onCheckedChange = { value -> vm.updateSettings { it.copy(hideShort = value) } }
            )
        }
        SettingRow(
            title = "Party mode",
            subtitle = "Let friends request songs from their own phones",
            onClick = { showParty = true }
        )
        SettingRow(
            title = "Hidden folders",
            subtitle = if (settings.hiddenFolders.isEmpty()) {
                "Hide folders like voice notes from your library"
            } else {
                "${settings.hiddenFolders.size} hidden  ·  Tap to manage"
            },
            onClick = { showHidden = true }
        )
        SettingRow(
            title = "Find lyrics online",
            subtitle = "Sends song title and artist to lrclib.net",
            onClick = { vm.updateSettings { it.copy(onlineLyrics = !it.onlineLyrics) } }
        ) {
            Switch(
                checked = settings.onlineLyrics,
                onCheckedChange = { value -> vm.updateSettings { it.copy(onlineLyrics = value) } }
            )
        }
        SettingRow(
            title = "Find cover art online",
            subtitle = "Fills songs without artwork using title and artist (iTunes, Deezer)",
            onClick = { vm.updateSettings { it.copy(onlineCovers = !it.onlineCovers) } }
        ) {
            Switch(
                checked = settings.onlineCovers,
                onCheckedChange = { value -> vm.updateSettings { it.copy(onlineCovers = value) } }
            )
        }
        SettingRow(
            title = "Re-check covers",
            subtitle = "Search again for songs where no cover was found",
            onClick = vm::recheckCovers
        )
        SettingRow(
            title = "Song identification",
            subtitle = when {
                BuildConfig.ACOUSTID_KEY.isNotEmpty() -> "Ready to use  ·  Use Identify song from a song's menu"
                settings.acoustidKey.isBlank() -> "Add a free AcoustID key to identify songs by sound"
                else -> "AcoustID key saved  ·  Use Identify song from a song's menu"
            },
            onClick = { showKey = true }
        )
        SettingRow(
            title = "Identify unknown songs",
            subtitle = if (unidentified == 0) {
                "No songs with a missing artist or album"
            } else {
                "$unidentified songs with a missing artist or album  ·  Fix them by sound"
            },
            onClick = { showBatch = true }
        )
        SettingRow(
            title = "Rescan library",
            subtitle = "${library.tracks.size} songs  ·  ${library.albums.size} albums  ·  ${library.artists.size} artists",
            onClick = vm::refresh
        )

        SectionLabel("Playback")
        SettingRow(
            title = "Skip silence",
            subtitle = "Jump over silent parts inside songs",
            onClick = { vm.updateSettings { it.copy(skipSilence = !it.skipSilence) } }
        ) {
            Switch(
                checked = settings.skipSilence,
                onCheckedChange = { value -> vm.updateSettings { it.copy(skipSilence = value) } }
            )
        }
        SettingRow(
            title = "Volume leveling",
            subtitle = "Keep loud and quiet songs at a similar level",
            onClick = { vm.updateSettings { it.copy(normalizeVolume = !it.normalizeVolume) } }
        ) {
            Switch(
                checked = settings.normalizeVolume,
                onCheckedChange = { value -> vm.updateSettings { it.copy(normalizeVolume = value) } }
            )
        }
        SettingRow(
            title = "Fade between songs",
            subtitle = "Fade out the end of a song and fade in the next one"
        )
        PillTabs(
            labels = CrossfadeOptions.map { if (it == 0) "Off" else "${it}s" },
            selected = CrossfadeOptions.indexOf(settings.crossfadeSeconds).coerceAtLeast(0),
            onSelect = { index -> vm.updateSettings { it.copy(crossfadeSeconds = CrossfadeOptions[index]) } },
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
        )
        SettingRow(
            title = "Skip interval",
            subtitle = "Used by double-tap on the cover, notification and Bluetooth controls"
        )
        PillTabs(
            labels = SkipSecondsOptions.map { "${it}s" },
            selected = SkipSecondsOptions.indexOf(settings.skipSeconds).coerceAtLeast(0),
            onSelect = { index -> vm.updateSettings { it.copy(skipSeconds = SkipSecondsOptions[index]) } },
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
        )
        SettingRow(
            title = "Show skip buttons",
            subtitle = "Add back and forward buttons next to the seek bar on Now Playing",
            onClick = { vm.updateSettings { it.copy(showSkipButtons = !it.showSkipButtons) } }
        ) {
            Switch(
                checked = settings.showSkipButtons,
                onCheckedChange = { value -> vm.updateSettings { it.copy(showSkipButtons = value) } }
            )
        }
        SettingRow(
            title = "Lyrics in notification",
            subtitle = "Show the current line instead of the artist name",
            onClick = { vm.updateSettings { it.copy(notificationLyrics = !it.notificationLyrics) } }
        ) {
            Switch(
                checked = settings.notificationLyrics,
                onCheckedChange = { value -> vm.updateSettings { it.copy(notificationLyrics = value) } }
            )
        }
        SettingRow(
            title = "Equalizer",
            subtitle = "Presets, bands, bass boost",
            onClick = { vm.open(Route.EqualizerRoute) }
        )

        SectionLabel("Backup")
        SettingRow(
            title = "Back up data",
            subtitle = "Save favorites, playlists, play counts, song edits and settings to a file",
            onClick = { exportLauncher.launch(BackupCodec.fileName()) }
        )
        SettingRow(
            title = "Restore data",
            subtitle = "Replace current data with a Sonora backup file",
            onClick = { confirmRestore = true }
        )

        SectionLabel("About")
        SettingRow(
            title = "App tour",
            subtitle = "Replay the quick introduction to every feature",
            onClick = { vm.updateSettings { it.copy(onboarded = false) } }
        )
        SettingRow(
            title = "Check for updates",
            subtitle = "Version ${BuildConfig.VERSION_NAME}  ·  Tap to look for a newer version",
            onClick = { vm.checkForUpdate(true) }
        )
        SettingRow(
            title = "About Sonora",
            subtitle = "Version ${BuildConfig.VERSION_NAME}  ·  App and developer details",
            onClick = { vm.open(Route.AboutRoute) },
            trailing = { SonoraMark(size = 36.dp) }
        )
    }

    if (showParty) PartySheet(vm = vm, onDismiss = { showParty = false })

    if (showBatch) {
        val batch by vm.batch.collectAsStateWithLifecycle()
        BatchIdentifyDialog(
            batch = batch,
            candidates = unidentified,
            onStart = vm::identifyUnknown,
            onStop = vm::cancelBatch,
            onClose = {
                vm.resetBatch()
                showBatch = false
            }
        )
    }

    if (showKey) {
        var draft by remember { mutableStateOf(settings.acoustidKey) }
        AlertDialog(
            onDismissRequest = { showKey = false },
            title = { Text("AcoustID key") },
            text = {
                Column {
                    Text(
                        text = if (BuildConfig.ACOUSTID_KEY.isNotEmpty()) {
                            "Song identification already works with the key built into Sonora. Add your own key below only if identification stops working."
                        } else {
                            "Sonora fingerprints the audio on your phone and asks AcoustID (free, open) who it is. AcoustID needs an application key: register one at acoustid.org/new-application and paste it here."
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { draft = it },
                        singleLine = true,
                        label = { Text("Application API key") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.updateSettings { it.copy(acoustidKey = draft.trim()) }
                    showKey = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showKey = false }) { Text("Cancel") } }
        )
    }

    if (showHidden) {
        AlertDialog(
            onDismissRequest = { showHidden = false },
            title = { Text("Hidden folders") },
            text = {
                if (settings.hiddenFolders.isEmpty()) {
                    Text("No folders are hidden. Use the menu on a folder in Library to hide it.")
                } else {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        settings.hiddenFolders.sorted().forEach { path ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        text = hiddenFolderName(path),
                                        style = MaterialTheme.typography.bodyLarge,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = hiddenFolderLocation(path),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                TextButton(onClick = {
                                    vm.updateSettings { it.copy(hiddenFolders = it.hiddenFolders - path) }
                                }) { Text("Show") }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showHidden = false }) { Text("Done") } }
        )
    }

    if (confirmRestore) {
        AlertDialog(
            onDismissRequest = { confirmRestore = false },
            title = { Text("Restore backup?") },
            text = {
                Text("Your current favorites, playlists, play counts, song edits and settings will be replaced with the contents of the backup file.")
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmRestore = false
                    importLauncher.launch(arrayOf("*/*"))
                }) { Text("Choose file") }
            },
            dismissButton = { TextButton(onClick = { confirmRestore = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        letterSpacing = 1.6.sp,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 4.dp)
    )
}

@Composable
private fun SettingRow(
    title: String,
    subtitle: String? = null,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit = {}
) {
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        trailing()
    }
}

private fun hiddenFolderName(path: String): String = path.substringAfterLast('/').ifBlank { "Unknown folder" }

private fun hiddenFolderLocation(path: String): String =
    path.removePrefix("/storage/emulated/0").trim('/').ifBlank { "Unknown location" }

@Composable
private fun BatchIdentifyDialog(
    batch: BatchIdentify,
    candidates: Int,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onClose: () -> Unit
) {
    AlertDialog(
        onDismissRequest = { if (!batch.running) onClose() },
        title = { Text("Identify unknown songs") },
        text = {
            Column {
                when {
                    batch.running -> {
                        Text("Listening to ${batch.done + 1} of ${batch.total}. Keep Sonora open.", style = MaterialTheme.typography.bodyMedium)
                        LinearProgressIndicator(
                            progress = { if (batch.total == 0) 0f else batch.done.toFloat() / batch.total },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 16.dp)
                        )
                        Text(
                            text = "${batch.applied} fixed so far",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                    batch.finished -> {
                        val summary = when {
                            batch.needsKey -> "Add your AcoustID key first, then run this again."
                            batch.offline -> "Lost the connection. ${batch.applied} songs were fixed before it stopped."
                            batch.total == 0 -> "Nothing to fix."
                            else -> "Checked ${batch.done} songs and fixed ${batch.applied}. Only matches AcoustID is very sure about are applied; use Identify song on the rest."
                        }
                        Text(summary, style = MaterialTheme.typography.bodyMedium)
                    }
                    else -> Text(
                        text = if (candidates == 0) {
                            "Every song already has an artist and album."
                        } else {
                            "Sonora will listen to $candidates songs with a missing artist or album and fill in the details when AcoustID is very sure. Your audio files are never changed. This can take a few minutes."
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        },
        confirmButton = {
            when {
                batch.running -> TextButton(onClick = onStop) { Text("Stop") }
                batch.finished -> TextButton(onClick = onClose) { Text("Done") }
                else -> TextButton(onClick = onStart, enabled = candidates > 0) { Text("Start") }
            }
        },
        dismissButton = {
            if (!batch.running && !batch.finished) TextButton(onClick = onClose) { Text("Cancel") }
        }
    )
}
