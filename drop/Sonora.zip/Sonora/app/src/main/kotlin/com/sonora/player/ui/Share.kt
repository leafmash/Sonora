package com.sonora.player.ui

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.sonora.player.data.Track

fun shareTracks(context: Context, tracks: List<Track>) {
    if (tracks.isEmpty()) return
    val uris = ArrayList<Uri>(tracks.map { it.uri })
    val label = if (tracks.size == 1) "${tracks[0].title} - ${tracks[0].artist}" else "${tracks.size} songs"
    val send = if (tracks.size == 1) {
        Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
    }
    send.type = "audio/*"
    send.putExtra(Intent.EXTRA_SUBJECT, label)
    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    val clip = ClipData.newRawUri(label, uris[0])
    uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
    send.clipData = clip
    val chooser = Intent.createChooser(send, "Share")
    if (context !is Activity) chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(chooser) }
        .onFailure { Toast.makeText(context, "Couldn't share this song", Toast.LENGTH_SHORT).show() }
}

fun shareTrack(context: Context, track: Track) = shareTracks(context, listOf(track))
