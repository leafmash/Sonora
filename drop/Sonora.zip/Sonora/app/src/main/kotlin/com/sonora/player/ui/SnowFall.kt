package com.sonora.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.runtime.withFrameNanos
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

private class Flake(
    val x: Float,
    val y: Float,
    val depth: Float,
    val swayAmp: Float,
    val swayFreq: Float,
    val phase: Float,
    val twinkle: Float
)

private fun flakeSet(count: Int, seed: Int): List<Flake> {
    val random = Random(seed)
    return List(count) {
        val depth = random.nextFloat().let { it * it }
        Flake(
            x = random.nextFloat(),
            y = random.nextFloat(),
            depth = depth,
            swayAmp = 0.012f + random.nextFloat() * 0.03f,
            swayFreq = 0.25f + random.nextFloat() * 0.6f,
            phase = random.nextFloat() * (2f * PI.toFloat()),
            twinkle = 0.6f + random.nextFloat() * 1.4f
        )
    }
}

@Composable
fun SnowFall(
    modifier: Modifier = Modifier,
    count: Int = 90,
    accent: Color = Color.White
) {
    val tint = lerp(accent, Color.White, 0.8f)
    val flakes = remember(count) { flakeSet(count, 7) }
    val clock = remember { mutableFloatStateOf(0f) }
    val density = LocalDensity.current.density

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) clock.floatValue += (now - last) / 1_000_000_000f
                last = now
            }
        }
    }

    Canvas(modifier) {
        val t = clock.floatValue
        val w = size.width
        val h = size.height
        val gust = 0.5f + 0.5f * sin(t * 0.17f)
        flakes.forEach { flake ->
            val speed = 0.035f + flake.depth * 0.11f
            val fall = (flake.y + t * speed) % 1f
            val sway = sin(t * flake.swayFreq + flake.phase) * flake.swayAmp
            val drift = t * 0.004f * (0.4f + flake.depth) + gust * 0.05f * flake.depth
            val px = (((flake.x + sway + drift) % 1f) + 1f) % 1f * w
            val py = fall * (h + 24f * density) - 12f * density
            val radius = (0.55f + flake.depth * 1.5f) * density
            val edge = minOf(fall / 0.08f, (1f - fall) / 0.12f, 1f).coerceIn(0f, 1f)
            val pulse = 0.78f + 0.22f * sin(t * flake.twinkle + flake.phase)
            val base = (0.28f + flake.depth * 0.6f) * pulse * edge
            val center = Offset(px, py)
            if (flake.depth > 0.7f) {
                drawCircle(accent.copy(alpha = base * 0.07f), radius * 3.2f, center)
                drawCircle(accent.copy(alpha = base * 0.12f), radius * 2.2f, center)
                drawCircle(accent.copy(alpha = base * 0.2f), radius * 1.4f, center)
            } else if (flake.depth > 0.25f) {
                drawCircle(tint.copy(alpha = base * 0.16f), radius * 2.4f, center)
                drawCircle(tint.copy(alpha = base * 0.28f), radius * 1.6f, center)
            }
            drawCircle(tint.copy(alpha = base), radius, center)
        }
    }
}
