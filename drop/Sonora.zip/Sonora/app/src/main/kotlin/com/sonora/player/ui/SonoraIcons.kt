package com.sonora.player.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

object SonoraIcons {

    val Expand: ImageVector by lazy {
        ImageVector.Builder(
            name = "SonoraExpand",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(4f, 9f)
                verticalLineTo(6.5f)
                quadTo(4f, 4f, 6.5f, 4f)
                horizontalLineTo(9f)
                moveTo(15f, 4f)
                horizontalLineTo(17.5f)
                quadTo(20f, 4f, 20f, 6.5f)
                verticalLineTo(9f)
                moveTo(20f, 15f)
                verticalLineTo(17.5f)
                quadTo(20f, 20f, 17.5f, 20f)
                horizontalLineTo(15f)
                moveTo(9f, 20f)
                horizontalLineTo(6.5f)
                quadTo(4f, 20f, 4f, 17.5f)
                verticalLineTo(15f)
            }
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 8.4f)
                quadTo(12.5f, 11.5f, 15.6f, 12f)
                quadTo(12.5f, 12.5f, 12f, 15.6f)
                quadTo(11.5f, 12.5f, 8.4f, 12f)
                quadTo(11.5f, 11.5f, 12f, 8.4f)
                close()
            }
        }.build()
    }

    val Collapse: ImageVector by lazy {
        ImageVector.Builder(
            name = "SonoraCollapse",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.9f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(9f, 4f)
                verticalLineTo(7f)
                quadTo(9f, 9f, 7f, 9f)
                horizontalLineTo(4f)
                moveTo(15f, 4f)
                verticalLineTo(7f)
                quadTo(15f, 9f, 17f, 9f)
                horizontalLineTo(20f)
                moveTo(15f, 20f)
                verticalLineTo(17f)
                quadTo(15f, 15f, 17f, 15f)
                horizontalLineTo(20f)
                moveTo(9f, 20f)
                verticalLineTo(17f)
                quadTo(9f, 15f, 7f, 15f)
                horizontalLineTo(4f)
            }
            path(fill = SolidColor(Color.Black)) {
                moveTo(12f, 10.2f)
                quadTo(12.3f, 11.7f, 13.8f, 12f)
                quadTo(12.3f, 12.3f, 12f, 13.8f)
                quadTo(11.7f, 12.3f, 10.2f, 12f)
                quadTo(11.7f, 11.7f, 12f, 10.2f)
                close()
            }
        }.build()
    }
}
