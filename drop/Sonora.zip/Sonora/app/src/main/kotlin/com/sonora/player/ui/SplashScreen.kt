package com.sonora.player.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val SplashLavender = Color(0xFFC9B6FF)
private val SplashPink = Color(0xFFFF9AD5)
private val SplashText = Color(0xFFECE6F5)
private val BarTargets = listOf(0.3f, 0.68f, 1f, 0.58f, 0.26f)
private val BreathDurations = listOf(520, 640, 460, 580, 700)

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val entrance = remember { List(BarTargets.size) { Animatable(0f) } }
    val glow = remember { Animatable(0f) }
    val title = remember { Animatable(0f) }
    val tagline = remember { Animatable(0f) }
    val transition = rememberInfiniteTransition(label = "breath")
    val breath = BreathDurations.mapIndexed { index, duration ->
        transition.animateFloat(
            initialValue = 0.78f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(duration, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "bar$index"
        )
    }

    LaunchedEffect(Unit) {
        launch { glow.animateTo(1f, tween(1000)) }
        entrance.forEachIndexed { index, bar ->
            launch {
                delay(index * 80L)
                bar.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow))
            }
        }
        launch {
            delay(650)
            title.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
        }
        launch {
            delay(1050)
            tagline.animateTo(1f, tween(550))
        }
        delay(2300)
        onFinished()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0E0C14), Color(0xFF1A1230), Color(0xFF0E0C14))))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val amount = glow.value
            val center = Offset(size.width / 2f, size.height / 2f - 50.dp.toPx())
            val radius = 230.dp.toPx() * (0.6f + 0.4f * amount)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFFB69CFF).copy(alpha = 0.3f * amount), Color.Transparent),
                    center = center,
                    radius = radius
                ),
                radius = radius,
                center = center
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(Modifier.size(DpSize(170.dp, 130.dp))) {
                val spacing = 30.dp.toPx()
                val stroke = 14.dp.toPx()
                BarTargets.forEachIndexed { index, target ->
                    val height = size.height * target * entrance[index].value.coerceAtLeast(0f) * breath[index].value
                    if (height >= 1f) {
                        val x = size.width / 2f + (index - 2) * spacing
                        val top = size.height / 2f - height / 2f
                        val bottom = size.height / 2f + height / 2f
                        drawLine(
                            brush = Brush.verticalGradient(
                                colors = listOf(SplashLavender, SplashPink),
                                startY = top,
                                endY = bottom
                            ),
                            start = Offset(x, top),
                            end = Offset(x, bottom),
                            strokeWidth = stroke,
                            cap = StrokeCap.Round
                        )
                    }
                }
            }
            Spacer(Modifier.height(28.dp))
            Text(
                text = "Sonora",
                color = SplashText,
                fontSize = 42.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (14f - 8f * title.value).sp,
                modifier = Modifier.graphicsLayer {
                    alpha = title.value
                    translationY = (1f - title.value) * 28.dp.toPx()
                }
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "Feel every lyric",
                color = SplashLavender.copy(alpha = 0.8f),
                fontSize = 15.sp,
                letterSpacing = 2.sp,
                modifier = Modifier.graphicsLayer { alpha = tagline.value }
            )
        }
    }
}
