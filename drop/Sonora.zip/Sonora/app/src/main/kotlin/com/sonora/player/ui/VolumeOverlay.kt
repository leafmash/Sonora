package com.sonora.player.ui

import android.media.AudioManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private const val HideDelayMs = 2200L
private val TrackHeight = 176.dp
private val KnobRadius = 11.dp

class VolumeController(private val audio: AudioManager) {

    val maxLevel: Int = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)

    var level by mutableIntStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC))
        private set

    var pulse by mutableIntStateOf(0)
        private set

    fun step(direction: Int) {
        runCatching {
            audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (direction > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                0
            )
        }
        refresh()
        pulse++
    }

    fun set(value: Int) {
        runCatching { audio.setStreamVolume(AudioManager.STREAM_MUSIC, value.coerceIn(0, maxLevel), 0) }
        refresh()
        pulse++
    }

    fun refresh() {
        level = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
    }
}

@Composable
fun VolumeOverlay(controller: VolumeController, modifier: Modifier = Modifier) {
    var visible by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    val pulse = controller.pulse

    LaunchedEffect(pulse, dragging) {
        if (pulse == 0) return@LaunchedEffect
        visible = true
        if (dragging) return@LaunchedEffect
        delay(HideDelayMs)
        visible = false
    }

    val fraction by animateFloatAsState(
        targetValue = controller.level.toFloat() / controller.maxLevel,
        animationSpec = tween(140),
        label = "volumeFraction"
    )

    Box(
        modifier
            .fillMaxSize()
            .displayCutoutPadding()
            .systemBarsPadding(),
        contentAlignment = Alignment.CenterEnd
    ) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(220)) + slideInHorizontally(tween(260)) { it / 2 } + scaleIn(tween(260), initialScale = 0.92f),
            exit = fadeOut(tween(260)) + slideOutHorizontally(tween(260)) { it / 2 } + scaleOut(tween(260), targetScale = 0.92f)
        ) {
            VolumeCard(controller, fraction) { dragging = it }
        }
    }
}

@Composable
private fun VolumeCard(controller: VolumeController, fraction: Float, onDragging: (Boolean) -> Unit) {
    val percent = (controller.level * 100f / controller.maxLevel).roundToInt()
    val icon = when {
        controller.level == 0 -> Icons.Rounded.VolumeOff
        fraction < 0.5f -> Icons.Rounded.VolumeDown
        else -> Icons.Rounded.VolumeUp
    }
    Surface(
        modifier = Modifier.padding(end = 14.dp),
        shape = RoundedCornerShape(32.dp),
        color = Color(0xFF14121C).copy(alpha = 0.92f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
        shadowElevation = 14.dp
    ) {
        Column(
            Modifier
                .width(64.dp)
                .padding(vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "$percent%",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(Modifier.height(10.dp))
            VolumeTrack(controller, fraction, onDragging)
            Spacer(Modifier.height(10.dp))
            Crossfade(targetState = icon, animationSpec = tween(180), label = "volumeIcon") { current ->
                Icon(current, contentDescription = null, tint = Color.White.copy(alpha = 0.92f), modifier = Modifier.size(24.dp))
            }
        }
    }
}

@Composable
private fun VolumeTrack(controller: VolumeController, fraction: Float, onDragging: (Boolean) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val primary = scheme.primary
    val secondary = scheme.secondary

    Canvas(
        Modifier
            .width(44.dp)
            .height(TrackHeight)
            .pointerInput(controller) {
                detectTapGestures { offset -> controller.set(levelAt(offset.y, controller.maxLevel)) }
            }
            .pointerInput(controller) {
                detectVerticalDragGestures(
                    onDragStart = { offset ->
                        onDragging(true)
                        controller.set(levelAt(offset.y, controller.maxLevel))
                    },
                    onDragEnd = { onDragging(false) },
                    onDragCancel = { onDragging(false) },
                    onVerticalDrag = { change, _ ->
                        change.consume()
                        controller.set(levelAt(change.position.y, controller.maxLevel))
                    }
                )
            }
    ) {
        val trackWidth = 10.dp.toPx()
        val left = (size.width - trackWidth) / 2f
        val radius = CornerRadius(trackWidth / 2f)
        val knob = KnobRadius.toPx()
        val travel = size.height - knob * 2f
        val knobY = size.height - knob - travel * fraction

        drawRoundRect(
            color = Color.White.copy(alpha = 0.16f),
            topLeft = Offset(left, 0f),
            size = Size(trackWidth, size.height),
            cornerRadius = radius
        )
        if (fraction > 0.001f) {
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(primary, secondary), startY = knobY, endY = size.height),
                topLeft = Offset(left, knobY),
                size = Size(trackWidth, size.height - knobY),
                cornerRadius = radius
            )
        }
        drawCircle(Color.White.copy(alpha = 0.2f), knob * 1.55f, Offset(size.width / 2f, knobY))
        drawCircle(Color.White, knob * 0.78f, Offset(size.width / 2f, knobY))
    }
}

private fun PointerInputScope.levelAt(y: Float, max: Int): Int {
    val pad = KnobRadius.toPx()
    val fraction = 1f - ((y - pad) / (size.height - pad * 2f)).coerceIn(0f, 1f)
    return (fraction * max).roundToInt()
}
