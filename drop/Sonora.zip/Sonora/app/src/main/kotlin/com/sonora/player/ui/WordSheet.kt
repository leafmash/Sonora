package com.sonora.player.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sonora.player.data.WordLookup
import com.sonora.player.data.WordMeaning

private sealed interface WordState {
    data object Loading : WordState
    data object Failed : WordState
    class Ready(val meaning: WordMeaning) : WordState
}

private sealed interface LineState {
    data object Idle : LineState
    data object Loading : LineState
    data object Failed : LineState
    class Ready(val text: String?) : LineState
}

private val Targets = listOf("bn" to "\u09AC\u09BE\u0982\u09B2\u09BE", "en" to "English")

fun isWordChar(c: Char): Boolean =
    Character.isLetterOrDigit(c) ||
        c == '\'' || c == '\u2019' || c == '-' || c == '\u200C' || c == '\u200D' ||
        Character.getType(c).let { it == Character.NON_SPACING_MARK.toInt() || it == Character.COMBINING_SPACING_MARK.toInt() }

fun wordAt(text: String, offset: Int): String? {
    if (text.isEmpty()) return null
    var index = offset.coerceIn(0, text.length - 1)
    if (!isWordChar(text[index])) {
        if (index > 0 && isWordChar(text[index - 1])) index-- else return null
    }
    var start = index
    while (start > 0 && isWordChar(text[start - 1])) start--
    var end = index + 1
    while (end < text.length && isWordChar(text[end])) end++
    return text.substring(start, end).trim('\'', '\u2019', '-').takeIf { word -> word.any { it.isLetter() } }
}

fun lineAt(text: String, offset: Int): String {
    val at = offset.coerceIn(0, text.length)
    val start = text.lastIndexOf('\n', at - 1) + 1
    val end = text.indexOf('\n', at).let { if (it < 0) text.length else it }
    return text.substring(start, end).trim()
}

@Composable
fun WordSheet(word: String, line: String, onDismiss: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val source = remember(word) { WordLookup.sourceLanguage(word) }
    var target by remember(word) { mutableStateOf(if (source == "bn") "en" else "bn") }
    var showLine by remember(word) { mutableStateOf(false) }

    val state by produceState<WordState>(WordState.Loading, word, target) {
        value = WordState.Loading
        value = runCatching { WordLookup.lookup(word, source, target) }
            .fold({ WordState.Ready(it) }, { WordState.Failed })
    }
    val lineState by produceState<LineState>(LineState.Idle, showLine, target) {
        if (!showLine) {
            value = LineState.Idle
        } else {
            value = LineState.Loading
            value = runCatching { WordLookup.translateLine(line, WordLookup.sourceLanguage(line), target) }
                .fold({ LineState.Ready(it) }, { LineState.Failed })
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 24.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            val current = state
            Text(word, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            if (current is WordState.Ready && current.meaning.phonetic != null) {
                Text(current.meaning.phonetic, style = MaterialTheme.typography.bodyMedium, color = scheme.onSurfaceVariant)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Targets.forEach { (code, label) ->
                    FilterChip(selected = target == code, onClick = { target = code }, label = { Text(label) })
                }
            }
            when (current) {
                WordState.Loading -> CircularProgressIndicator(Modifier.size(28.dp))
                WordState.Failed -> Text(
                    "Couldn't look this up. Check your connection and try again.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurfaceVariant
                )
                is WordState.Ready -> {
                    val meaning = current.meaning
                    if (meaning.translation != null) {
                        Surface(shape = RoundedCornerShape(20.dp), color = scheme.primaryContainer) {
                            Text(
                                text = meaning.translation,
                                style = MaterialTheme.typography.titleLarge,
                                color = scheme.onPrimaryContainer,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                            )
                        }
                    }
                    meaning.definitions.forEach { definition ->
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            if (definition.partOfSpeech.isNotBlank()) {
                                Text(definition.partOfSpeech, style = MaterialTheme.typography.labelLarge, color = scheme.primary)
                            }
                            Text(definition.text, style = MaterialTheme.typography.bodyLarge)
                            if (definition.example != null) {
                                Text(
                                    text = "\u201C${definition.example}\u201D",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontStyle = FontStyle.Italic,
                                    color = scheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    if (meaning.translation == null && meaning.definitions.isEmpty()) {
                        Text(
                            "No meaning found for this word.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = scheme.onSurfaceVariant
                        )
                    }
                }
            }
            if (line.isNotBlank()) {
                OutlinedButton(onClick = { showLine = !showLine }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (showLine) "Hide line translation" else "Translate this line")
                }
                when (val translated = lineState) {
                    LineState.Idle -> Unit
                    LineState.Loading -> CircularProgressIndicator(Modifier.size(24.dp))
                    LineState.Failed -> Text(
                        "Couldn't translate this line.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = scheme.onSurfaceVariant
                    )
                    is LineState.Ready -> Surface(shape = RoundedCornerShape(18.dp), color = scheme.surfaceVariant) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(line, style = MaterialTheme.typography.bodyMedium, color = scheme.onSurfaceVariant)
                            Text(
                                text = translated.text ?: "No translation found for this line.",
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }
                }
            }
            Text(
                "Meanings come from MyMemory and the Free Dictionary API. Only the word or line you pressed is sent.",
                style = MaterialTheme.typography.labelSmall,
                color = scheme.onSurfaceVariant
            )
        }
    }
}
