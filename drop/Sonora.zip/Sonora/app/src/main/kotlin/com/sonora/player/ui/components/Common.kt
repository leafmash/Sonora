package com.sonora.player.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.sp
import com.sonora.player.ui.theme.brandBrush
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.RingVolume
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.compose.AsyncImagePainter
import com.sonora.player.data.Album
import com.sonora.player.data.ArtModel
import com.sonora.player.data.CoverStore
import com.sonora.player.data.Track
import com.sonora.player.ui.formatTime
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.rounded.Share
import com.sonora.player.ui.shareTrack

private val DanceBackdrop = listOf(Color(0xFF241B3D), Color(0xFF15111F))

@Composable
fun Artwork(
    track: Track?,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(12.dp),
    current: Boolean = false,
    playing: Boolean = false,
    animated: Boolean = true,
    smooth: Boolean = false,
    onArtState: ((Boolean) -> Unit)? = null
) {
    var hasArt by remember(track?.id, track?.albumId) { mutableStateOf(false) }
    val scheme = MaterialTheme.colorScheme
    val reveal = if (smooth) {
        animateFloatAsState(if (hasArt) 1f else 0f, tween(240), label = "artReveal").value
    } else {
        1f
    }
    val placeholder = if (smooth) !(hasArt && reveal >= 0.99f) else !hasArt
    val dance = current && placeholder
    Box(
        modifier
            .clip(shape)
            .background(
                Brush.linearGradient(
                    if (dance) DanceBackdrop else listOf(scheme.primaryContainer, scheme.secondaryContainer)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        if (current && placeholder) {
            if (animated) {
                SonoraMark(
                    modifier = Modifier.fillMaxSize(0.5f),
                    dancing = playing
                )
            } else {
                SonoraMark(modifier = Modifier.fillMaxSize(0.5f))
            }
        } else if (!current) {
            SonoraMark(
                modifier = Modifier.fillMaxSize(0.4f),
                tint = scheme.onPrimaryContainer.copy(alpha = 0.55f)
            )
        }
        if (track != null) {
            val stamps by CoverStore.stamps.collectAsState()
            val cover = stamps[track.id] ?: 0L
            val model = remember(track.id, track.albumId, cover) { ArtModel(track.uri, track.albumId, track.id, cover) }
            AsyncImage(
                model = model,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = if (smooth) Modifier.fillMaxSize().graphicsLayer { alpha = reveal } else Modifier.fillMaxSize(),
                onState = { state ->
                    val loaded = state is AsyncImagePainter.State.Success
                    hasArt = loaded
                    onArtState?.invoke(loaded)
                }
            )
        }
        if (current && hasArt && animated) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f)),
                contentAlignment = Alignment.Center
            ) {
                SonoraMark(
                    modifier = Modifier.fillMaxSize(0.5f),
                    dancing = playing
                )
            }
        }
    }
}

@Composable
fun PlayingBars(color: Color, active: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "bars")
    val first = transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(420, easing = LinearEasing), RepeatMode.Reverse),
        label = "first"
    )
    val second = transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(560, easing = LinearEasing), RepeatMode.Reverse, StartOffset(120)),
        label = "second"
    )
    val third = transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(490, easing = LinearEasing), RepeatMode.Reverse, StartOffset(240)),
        label = "third"
    )
    Row(
        modifier.height(16.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        listOf(first, second, third).forEach { value ->
            Box(
                Modifier
                    .width(3.dp)
                    .fillMaxHeight()
                    .graphicsLayer {
                        scaleY = if (active) value.value else 0.55f
                        transformOrigin = TransformOrigin(0.5f, 1f)
                    }
                    .clip(RoundedCornerShape(1.5.dp))
                    .background(color)
            )
        }
    }
}

@Composable
fun TrackRow(
    track: Track,
    current: Boolean,
    playing: Boolean,
    favorite: Boolean,
    index: Int?,
    onClick: () -> Unit,
    onPlayNext: () -> Unit,
    onEnqueue: () -> Unit,
    onFavorite: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onOpenAlbum: () -> Unit,
    onOpenArtist: () -> Unit,
    onRemove: (() -> Unit)?,
    modifier: Modifier = Modifier,
    onEdit: (() -> Unit)? = null,
    onChangeCover: (() -> Unit)? = null,
    onIdentify: (() -> Unit)? = null,
    onInfo: (() -> Unit)? = null,
    onSetRingtone: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null,
    hasLyrics: Boolean = false,
    selecting: Boolean = false,
    selected: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    dragHandle: Modifier? = null,
    dragging: Boolean = false
) {
    var menuOpen by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    val rowShape = RoundedCornerShape(20.dp)
    val highlight by animateColorAsState(
        targetValue = when {
            selected -> scheme.primary.copy(alpha = 0.2f)
            current -> scheme.primary.copy(alpha = 0.12f)
            else -> Color.Transparent
        },
        animationSpec = tween(300),
        label = "rowHighlight"
    )
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 1.dp)
            .then(if (dragging) Modifier.shadow(8.dp, rowShape) else Modifier)
            .clip(rowShape)
            .background(if (dragging) scheme.surfaceContainerHigh else highlight)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(start = 8.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (index != null) {
            Text(
                text = "${index + 1}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.width(30.dp)
            )
        }
        Box(contentAlignment = Alignment.Center) {
            Artwork(
                track = track,
                modifier = Modifier.size(52.dp),
                shape = RoundedCornerShape(12.dp),
                current = current,
                playing = playing
            )
            if (selecting) {
                Box(
                    Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black.copy(alpha = if (selected) 0.55f else 0.25f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (selected) Icons.Rounded.Check else Icons.Rounded.RadioButtonUnchecked,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }
        Column(
            Modifier
                .weight(1f)
                .padding(horizontal = 14.dp)
        ) {
            Text(
                text = track.title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (current) FontWeight.Bold else FontWeight.Medium,
                color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (hasLyrics) {
                    LyricsBadge()
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    text = "${track.artist}  ·  ${formatTime(track.durationMs)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
            }
        }
        if (favorite && !dragging) {
            Icon(
                imageVector = Icons.Rounded.Favorite,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(18.dp)
            )
        }
        if (dragHandle != null) {
            Box(
                Modifier
                    .size(40.dp)
                    .then(dragHandle),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.DragHandle,
                    contentDescription = "Reorder",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (selecting) {
            Spacer(Modifier.width(12.dp))
        } else {
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = "More", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    MenuEntry("Play next", Icons.Rounded.SkipNext) { menuOpen = false; onPlayNext() }
                    MenuEntry("Add to queue", Icons.Rounded.QueueMusic) { menuOpen = false; onEnqueue() }
                    MenuEntry(
                        if (favorite) "Remove from favorites" else "Add to favorites",
                        if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder
                    ) { menuOpen = false; onFavorite() }
                    MenuEntry("Add to playlist", Icons.Rounded.PlaylistAdd) { menuOpen = false; onAddToPlaylist() }
                    MenuEntry("Share", Icons.Rounded.Share) { menuOpen = false; shareTrack(context, track) }
                    MenuEntry("Go to album", Icons.Rounded.Album) { menuOpen = false; onOpenAlbum() }
                    MenuEntry("Go to artist", Icons.Rounded.Person) { menuOpen = false; onOpenArtist() }
                    if (onChangeCover != null) {
                        MenuEntry("Change cover art", Icons.Rounded.Image) { menuOpen = false; onChangeCover() }
                    }
                    if (onIdentify != null) {
                        MenuEntry("Identify song", Icons.Rounded.Fingerprint) { menuOpen = false; onIdentify() }
                    }
                    if (onEdit != null) {
                        MenuEntry("Edit info", Icons.Rounded.Edit) { menuOpen = false; onEdit() }
                    }
                    if (onInfo != null) {
                        MenuEntry("Song info", Icons.Rounded.Info) { menuOpen = false; onInfo() }
                    }
                    if (onSetRingtone != null) {
                        MenuEntry("Set as ringtone", Icons.Rounded.RingVolume) { menuOpen = false; onSetRingtone() }
                    }
                    if (onRemove != null) {
                        MenuEntry("Remove from playlist", Icons.Rounded.Delete) { menuOpen = false; onRemove() }
                    }
                    if (onDelete != null) {
                        MenuEntry("Delete from device", Icons.Rounded.Delete) { menuOpen = false; onDelete() }
                    }
                }
            }
        }
    }
}

@Composable
fun JumpToCurrentButton(visible: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = fadeIn(tween(180)) + scaleIn(tween(180), initialScale = 0.7f),
        exit = fadeOut(tween(140)) + scaleOut(tween(140), targetScale = 0.7f)
    ) {
        SmallFloatingActionButton(
            onClick = onClick,
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        ) {
            Icon(Icons.Rounded.MyLocation, contentDescription = "Go to playing song", modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
fun LyricsBadge(modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme
    Row(
        modifier
            .clip(RoundedCornerShape(6.dp))
            .background(scheme.primary.copy(alpha = 0.16f))
            .padding(horizontal = 5.dp, vertical = 1.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Icon(
            imageVector = Icons.Rounded.Lyrics,
            contentDescription = "Has lyrics",
            tint = scheme.primary,
            modifier = Modifier.size(11.dp)
        )
        Text(
            text = "LYRICS",
            color = scheme.primary,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.6.sp,
            maxLines = 1
        )
    }
}

@Composable
internal fun MenuEntry(label: String, icon: ImageVector, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(label) },
        leadingIcon = { Icon(icon, contentDescription = null) },
        onClick = onClick
    )
}

@Composable
fun AlbumCard(album: Album, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
    ) {
        Artwork(
            album.cover,
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f),
            RoundedCornerShape(24.dp)
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = album.name,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
        Text(
            text = album.artist,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 4.dp, end = 4.dp, bottom = 4.dp)
        )
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Row(
        modifier.padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(width = 4.dp, height = 20.dp)
                .clip(CircleShape)
                .background(brandBrush())
        )
        Spacer(Modifier.width(10.dp))
        Text(text = text, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    useMark: Boolean = false
) {
    Column(
        modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(88.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.linearGradient(
                        listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.secondaryContainer)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            if (useMark) {
                SonoraMark(size = 44.dp)
            } else {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(40.dp))
            }
        }
        Spacer(Modifier.height(20.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun ScreenHeader(
    title: String,
    modifier: Modifier = Modifier,
    kicker: String? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 8.dp, top = 14.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            if (kicker != null) {
                Text(
                    text = kicker.uppercase(),
                    style = MaterialTheme.typography.labelMedium.copy(brush = brandBrush(), letterSpacing = 1.6.sp)
                )
            }
            Text(text = title, style = MaterialTheme.typography.headlineLarge)
        }
        actions()
    }
}

@Composable
fun PillTabs(
    labels: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val brush = brandBrush()
    Row(
        modifier
            .fillMaxWidth()
            .clip(CircleShape)
            .background(scheme.surfaceContainerHigh)
            .padding(4.dp)
    ) {
        labels.forEachIndexed { index, label ->
            val on = index == selected
            val fill by animateFloatAsState(if (on) 1f else 0f, tween(260), label = "pillFill")
            val tint by animateColorAsState(
                if (on) scheme.onPrimary else scheme.onSurfaceVariant,
                tween(260),
                label = "pillTint"
            )
            Box(
                Modifier
                    .weight(1f)
                    .clip(CircleShape)
                    .background(brush, CircleShape, alpha = fill)
                    .clickable { onSelect(index) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(text = label, color = tint, style = MaterialTheme.typography.labelLarge, maxLines = 1)
            }
        }
    }
}

@Composable
fun BrandButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val onBrand = MaterialTheme.colorScheme.onPrimary
    Row(
        modifier
            .clip(CircleShape)
            .background(brandBrush(), CircleShape, alpha = if (enabled) 1f else 0.4f)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(icon, contentDescription = null, tint = onBrand, modifier = Modifier.size(20.dp))
        Text(text = text, color = onBrand, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun rememberSpin(playing: Boolean, periodMs: Int = 16000): Animatable<Float, AnimationVector1D> {
    val angle = remember { Animatable(0f) }
    LaunchedEffect(playing) {
        if (!playing) return@LaunchedEffect
        while (true) {
            angle.snapTo(angle.value % 360f)
            angle.animateTo(angle.value + 360f, tween(periodMs, easing = LinearEasing))
        }
    }
    return angle
}
