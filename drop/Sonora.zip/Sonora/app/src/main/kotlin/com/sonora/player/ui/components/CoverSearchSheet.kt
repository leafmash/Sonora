package com.sonora.player.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.CoverOption
import com.sonora.player.data.CoverSearchState
import com.sonora.player.data.CoverStore
import com.sonora.player.data.Track
import kotlinx.coroutines.launch

@Composable
fun CoverSearchSheet(
    vm: PlayerViewModel,
    track: Track,
    onDismiss: () -> Unit
) {
    val state by vm.coverSearch.collectAsStateWithLifecycle()
    val stamps by CoverStore.stamps.collectAsStateWithLifecycle()
    val library by vm.library.collectAsStateWithLifecycle()
    var query by remember(track.id) { mutableStateOf(vm.coverQuery(track)) }
    var wholeAlbum by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    val albumCount = remember(library, track.id) {
        if (track.albumId > 0) library.tracks.count { it.albumId == track.albumId && it.album == track.album } else 0
    }
    val canSearch = query.isNotBlank() && !busy

    val finish = {
        vm.resetCoverSearch()
        onDismiss()
    }
    val submit = {
        focus.clearFocus()
        vm.searchCovers(query)
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val saved = vm.applyCoverImage(track, uri, wholeAlbum)
                busy = false
                if (saved) finish()
            }
        }
    }

    LaunchedEffect(Unit) { vm.searchCovers(query) }

    ModalBottomSheet(
        onDismissRequest = finish,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .imePadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Cover art", style = MaterialTheme.typography.titleLarge)
            Text(
                text = "${track.title}  ·  ${track.artist}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                label = { Text("Search") },
                trailingIcon = {
                    IconButton(onClick = { submit() }, enabled = canSearch) {
                        Icon(Icons.Rounded.Search, contentDescription = "Search")
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { if (canSearch) submit() }),
                modifier = Modifier.fillMaxWidth()
            )
            if (albumCount > 1) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { wholeAlbum = !wholeAlbum },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = wholeAlbum, onCheckedChange = { wholeAlbum = it })
                    Text(
                        text = "Use for all $albumCount songs in this album",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { picker.launch("image/*") }, enabled = !busy) {
                    Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("From gallery")
                }
                Spacer(Modifier.weight(1f))
                if (track.id in stamps) {
                    TextButton(
                        onClick = {
                            vm.removeCover(track, wholeAlbum)
                            finish()
                        },
                        enabled = !busy
                    ) {
                        Text("Remove cover", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 120.dp, max = 420.dp)
            ) {
                CoverResults(
                    state = state,
                    enabled = !busy,
                    onPick = { option ->
                        scope.launch {
                            busy = true
                            val saved = vm.applyCover(track, option, wholeAlbum)
                            busy = false
                            if (saved) finish()
                        }
                    }
                )
                if (busy) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
            }
        }
    }
}

@Composable
private fun CoverResults(state: CoverSearchState, enabled: Boolean, onPick: (CoverOption) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    when (state) {
        CoverSearchState.Idle -> Unit
        CoverSearchState.Searching -> Box(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 120.dp),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        CoverSearchState.Empty -> StatusText("No covers found. Try the song or album name.")
        CoverSearchState.Failed -> StatusText("Can't reach the cover services. Check your connection and try again.")
        is CoverSearchState.Results -> LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(state.items, key = { it.fullUrl }) { option ->
                Column(
                    Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(enabled = enabled) { onPick(option) }
                ) {
                    AsyncImage(
                        model = option.previewUrl,
                        contentDescription = option.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(scheme.surfaceContainerHigh)
                    )
                    Text(
                        text = option.title,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Text(
                        text = option.artist,
                        style = MaterialTheme.typography.labelSmall,
                        color = scheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusText(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp)
    )
}
