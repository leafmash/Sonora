package com.sonora.player.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.IdentifyMatch
import com.sonora.player.data.IdentifyState
import com.sonora.player.data.Track
import kotlin.math.roundToInt

@Composable
fun IdentifySheet(
    vm: PlayerViewModel,
    track: Track,
    onDismiss: () -> Unit
) {
    val state by vm.identify.collectAsStateWithLifecycle()

    LaunchedEffect(track.id) { vm.identifyTrack(track) }
    DisposableEffect(track.id) { onDispose { vm.resetIdentify() } }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .imePadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Rounded.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text("Identify song", style = MaterialTheme.typography.titleLarge)
            }
            Text(
                text = "${track.title}  ·  ${track.artist}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            when (val current = state) {
                IdentifyState.Idle,
                IdentifyState.Decoding -> Progress("Reading the audio")
                IdentifyState.Fingerprinting -> Progress("Creating the audio fingerprint")
                IdentifyState.Looking -> Progress("Looking it up on AcoustID")
                is IdentifyState.Found -> Matches(current.matches) { match ->
                    vm.applyIdentified(track, match)
                    onDismiss()
                }
                IdentifyState.NotFound -> Message(
                    "No match found",
                    "AcoustID doesn't know this recording yet. Rare tracks, live versions and remixes are often missing."
                ) { vm.identifyTrack(track) }
                IdentifyState.Unreadable -> Message(
                    "Couldn't read this file",
                    "The audio couldn't be decoded or is too short to fingerprint."
                )
                IdentifyState.Failed -> Message(
                    "Lookup failed",
                    "Check your internet connection and try again."
                ) { vm.identifyTrack(track) }
                IdentifyState.NoKey -> KeyPrompt(vm) { vm.identifyTrack(track) }
            }
        }
    }
}

@Composable
private fun Progress(label: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun Message(title: String, body: String, onRetry: (() -> Unit)? = null) {
    Column(Modifier.padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (onRetry != null) {
            TextButton(onClick = onRetry) { Text("Try again") }
        }
    }
}

@Composable
private fun Matches(matches: List<IdentifyMatch>, onPick: (IdentifyMatch) -> Unit) {
    Text(
        text = "Tap the right one to update the title, artist and album.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        matches.forEach { match ->
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onPick(match) }
            ) {
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = match.title,
                            style = MaterialTheme.typography.bodyLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (match.album.isEmpty()) match.artist else "${match.artist}  ·  ${match.album}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = "${(match.score * 100).roundToInt()}%",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun KeyPrompt(vm: PlayerViewModel, onSaved: () -> Unit) {
    var key by remember { mutableStateOf("") }
    Text("AcoustID key needed", style = MaterialTheme.typography.titleMedium)
    Text(
        text = "Song identification is free, but AcoustID asks every app for its own key. Register an application at acoustid.org/new-application, then paste the key here.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    OutlinedTextField(
        value = key,
        onValueChange = { key = it },
        singleLine = true,
        label = { Text("Application API key") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
        modifier = Modifier.fillMaxWidth()
    )
    Button(
        onClick = {
            vm.updateSettings { it.copy(acoustidKey = key.trim()) }
            onSaved()
        },
        enabled = key.isNotBlank(),
        modifier = Modifier.fillMaxWidth()
    ) { Text("Save and identify") }
}
