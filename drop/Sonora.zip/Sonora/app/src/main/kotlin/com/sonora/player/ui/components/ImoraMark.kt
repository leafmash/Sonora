package com.sonora.player.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke

private val ImoraIndigo = Color(0xFF1B1A4B)
private val ImoraAmber = Color(0xFFFFB547)

@Composable
fun ImoraMark(modifier: Modifier = Modifier) {
    Canvas(modifier.aspectRatio(1f)) {
        val u = size.width / 128f
        val strokeWidth = 11f * u
        val archStroke = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        drawRoundRect(color = ImoraIndigo, cornerRadius = CornerRadius(38f * u))
        drawCircle(color = ImoraAmber, radius = 7.5f * u, center = Offset(33f * u, 38f * u))
        fun leg(x: Float, top: Float, bottom: Float) {
            drawLine(Color.White, Offset(x * u, top * u), Offset(x * u, bottom * u), strokeWidth, StrokeCap.Round)
        }
        fun arch(centerX: Float) {
            drawArc(
                color = Color.White,
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = Offset((centerX - 11f) * u, 61f * u),
                size = Size(22f * u, 22f * u),
                style = archStroke
            )
        }
        leg(33f, 56f, 94f)
        leg(51f, 72f, 94f)
        arch(62f)
        leg(73f, 72f, 94f)
        arch(84f)
        leg(95f, 72f, 94f)
    }
}
