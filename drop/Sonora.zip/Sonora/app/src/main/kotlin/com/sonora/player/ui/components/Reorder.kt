package com.sonora.player.ui.components

import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.delay

private const val EDGE_ZONE_PX = 96f
private const val SCROLL_STEP_PX = 20f
private const val SCROLL_TICK_MS = 16L

@Stable
class ReorderState internal constructor(
    private val listState: LazyListState,
    private val range: () -> IntRange,
    private val onMove: (from: Int, to: Int) -> Unit,
    private val onFinish: (from: Int, to: Int) -> Unit
) {
    var draggingKey by mutableStateOf<Any?>(null)
        private set

    var offset by mutableFloatStateOf(0f)
        private set

    private var startIndex = -1
    private var currentIndex = -1

    fun start(key: Any) {
        val info = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == key } ?: return
        draggingKey = key
        startIndex = info.index
        currentIndex = info.index
        offset = 0f
    }

    fun dragBy(delta: Float) {
        if (draggingKey == null) return
        offset += delta
        swapIfNeeded()
    }

    fun finish() {
        val from = startIndex
        val to = currentIndex
        draggingKey = null
        offset = 0f
        startIndex = -1
        currentIndex = -1
        if (from >= 0 && from != to) onFinish(from, to)
    }

    private fun swapIfNeeded() {
        val key = draggingKey ?: return
        val items = listState.layoutInfo.visibleItemsInfo
        val dragged = items.firstOrNull { it.key == key } ?: return
        if (dragged.index != currentIndex) return
        val center = dragged.offset + offset + dragged.size / 2f
        val allowed = range()
        val target = items.firstOrNull {
            it.index != currentIndex &&
                it.index in allowed &&
                center >= it.offset &&
                center <= it.offset + it.size
        } ?: return
        onMove(currentIndex, target.index)
        offset += dragged.offset - target.offset
        currentIndex = target.index
    }

    internal suspend fun autoScroll() {
        while (true) {
            val key = draggingKey
            if (key != null) {
                val layout = listState.layoutInfo
                val dragged = layout.visibleItemsInfo.firstOrNull { it.key == key }
                if (dragged != null && dragged.index == currentIndex) {
                    val top = dragged.offset + offset
                    val bottom = top + dragged.size
                    val step = when {
                        top < layout.viewportStartOffset + EDGE_ZONE_PX -> -SCROLL_STEP_PX
                        bottom > layout.viewportEndOffset - EDGE_ZONE_PX -> SCROLL_STEP_PX
                        else -> 0f
                    }
                    if (step != 0f) {
                        offset += listState.scrollBy(step)
                        swapIfNeeded()
                    }
                }
            }
            delay(SCROLL_TICK_MS)
        }
    }
}

@Composable
fun rememberReorderState(
    listState: LazyListState,
    range: () -> IntRange,
    onMove: (from: Int, to: Int) -> Unit,
    onFinish: (from: Int, to: Int) -> Unit
): ReorderState {
    val latestRange = rememberUpdatedState(range)
    val latestMove = rememberUpdatedState(onMove)
    val latestFinish = rememberUpdatedState(onFinish)
    val state = remember(listState) {
        ReorderState(
            listState = listState,
            range = { latestRange.value() },
            onMove = { from, to -> latestMove.value(from, to) },
            onFinish = { from, to -> latestFinish.value(from, to) }
        )
    }
    LaunchedEffect(state) { state.autoScroll() }
    return state
}

fun Modifier.reorderHandle(state: ReorderState, key: Any): Modifier =
    pointerInput(key) {
        detectVerticalDragGestures(
            onDragStart = { state.start(key) },
            onDragEnd = { state.finish() },
            onDragCancel = { state.finish() },
            onVerticalDrag = { change, amount ->
                change.consume()
                state.dragBy(amount)
            }
        )
    }
