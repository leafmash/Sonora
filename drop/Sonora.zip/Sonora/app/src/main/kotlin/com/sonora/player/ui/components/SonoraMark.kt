package com.sonora.player.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.isSpecified

private val MarkLavender = Color(0xFFC9B6FF)
private val MarkPink = Color(0xFFFF9AD5)
private val MarkHeight = floatArrayOf(0.40f, 0.76f, 1f, 0.70f, 0.40f)
private val DancePeriod = intArrayOf(520, 410, 600, 460, 560)
private val DanceOffset = intArrayOf(0, 140, 60, 220, 100)

@Composable
fun SonoraMark(
    modifier: Modifier = Modifier,
    size: Dp = Dp.Unspecified,
    tint: Color? = null,
    dancing: Boolean? = null
) {
    val sized = if (size.isSpecified) modifier.size(size) else modifier
    if (dancing == null) {
        MarkCanvas(sized, tint) { MarkHeight[it] }
    } else {
        DancingMark(sized, tint, dancing)
    }
}

@Composable
private fun DancingMark(modifier: Modifier, tint: Color?, active: Boolean) {
    val transition = rememberInfiniteTransition(label = "dance")
    val waves = List(5) { index ->
        transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(DancePeriod[index], easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse,
                initialStartOffset = StartOffset(DanceOffset[index])
            ),
            label = "wave$index"
        )
    }
    val mix by animateFloatAsState(
        targetValue = if (active) 1f else 0f,
        animationSpec = tween(350),
        label = "danceMix"
    )
    MarkCanvas(modifier, tint) { index ->
        val moving = 0.28f + 0.72f * waves[index].value
        MarkHeight[index] + (moving - MarkHeight[index]) * mix
    }
}

@Composable
private fun MarkCanvas(modifier: Modifier, tint: Color?, heightOf: (Int) -> Float) {
    Canvas(modifier) {
        val stroke = this.size.minDimension * 0.15f
        val gap = (this.size.width - stroke) / 4f
        val full = this.size.height - stroke
        for (index in 0 until 5) {
            val fraction = heightOf(index)
            val x = stroke / 2f + gap * index
            val height = full * fraction
            val startY = stroke / 2f + full * (1f - fraction) / 2f
            val color = tint ?: if (index == 2) MarkPink else MarkLavender
            drawLine(
                color = color,
                start = Offset(x, startY),
                end = Offset(x, startY + height),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
        }
    }
}
