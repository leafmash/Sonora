package com.sonora.player.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.RingtoneSaver
import com.sonora.player.data.Track
import com.sonora.player.data.TrackInfo
import com.sonora.player.data.TrackInfoLoader
import com.sonora.player.data.formatFileSize
import com.sonora.player.ui.formatTime

@Composable
fun rememberRingtoneAction(vm: PlayerViewModel): (Track) -> Unit {
    val context = LocalContext.current
    var pending by remember { mutableStateOf<Track?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        val track = pending
        pending = null
        if (track != null) {
            if (RingtoneSaver.canWriteSettings(context)) {
                vm.setAsRingtone(track)
            } else {
                Toast.makeText(context, "Permission needed to change the ringtone", Toast.LENGTH_SHORT).show()
            }
        }
    }
    return { track ->
        if (RingtoneSaver.canWriteSettings(context)) {
            vm.setAsRingtone(track)
        } else {
            pending = track
            Toast.makeText(context, "Allow Sonora to modify system settings, then come back", Toast.LENGTH_LONG).show()
            launcher.launch(permissionIntent(context))
        }
    }
}

private fun permissionIntent(context: Context): Intent =
    Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))

@Composable
fun SongInfoSheet(track: Track, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val info by produceState<TrackInfo?>(null, track.id) {
        value = TrackInfoLoader.load(context, track)
    }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Rounded.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text("Song info", style = MaterialTheme.typography.titleLarge)
            }
            InfoSection {
                InfoRow("Title", track.title)
                InfoRow("Artist", track.artist)
                InfoRow("Album", track.album)
                InfoRow("Duration", formatTime(track.durationMs))
            }
            val loaded = info
            if (loaded != null) {
                InfoSection {
                    InfoRow("Format", loaded.format)
                    InfoRow("Codec", loaded.codec)
                    InfoRow("Bitrate", loaded.bitrate)
                    InfoRow("Sample rate", loaded.sampleRate)
                    InfoRow("Channels", loaded.channels)
                    if (loaded.bitDepth.isNotBlank()) InfoRow("Bit depth", loaded.bitDepth)
                    InfoRow("Size", formatFileSize(loaded.sizeBytes))
                }
                InfoSection {
                    InfoRow("File name", loaded.fileName)
                    InfoRow("Path", loaded.path)
                    InfoRow("Added", loaded.dateAdded)
                    InfoRow("Modified", loaded.dateModified)
                }
            } else {
                Text(
                    "Reading file details…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun InfoSection(content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        content()
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(104.dp)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 6,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
    }
}
