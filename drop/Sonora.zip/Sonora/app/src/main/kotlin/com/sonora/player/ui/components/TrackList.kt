package com.sonora.player.ui.components

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.Route
import com.sonora.player.data.Track

@Composable
fun TrackList(
    tracks: List<Track>,
    vm: PlayerViewModel,
    onAddToPlaylist: (Track) -> Unit,
    modifier: Modifier = Modifier,
    numbered: Boolean = false,
    onRemove: ((Track) -> Unit)? = null,
    header: (LazyListScope.() -> Unit)? = null
) {
    val now by vm.now.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    var editTarget by remember { mutableStateOf<Track?>(null) }
    var deleteTarget by remember { mutableStateOf<Track?>(null) }
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        header?.invoke(this)
        itemsIndexed(tracks, key = { _, track -> track.id }) { index, track ->
            TrackRow(
                track = track,
                current = now.track?.id == track.id,
                playing = now.isPlaying,
                favorite = track.id in favorites,
                index = if (numbered) index else null,
                onClick = { vm.playTracks(tracks, index) },
                onPlayNext = { vm.playNext(track) },
                onEnqueue = { vm.enqueue(track) },
                onFavorite = { vm.toggleFavorite(track) },
                onAddToPlaylist = { onAddToPlaylist(track) },
                onOpenAlbum = { vm.open(Route.AlbumRoute(track.albumId)) },
                onOpenArtist = { vm.open(Route.ArtistRoute(track.artist)) },
                onRemove = onRemove?.let { remove -> { remove(track) } },
                onEdit = { editTarget = track },
                onDelete = { deleteTarget = track }
            )
        }
    }
    editTarget?.let { target ->
        EditTrackDialog(vm = vm, track = target, onDismiss = { editTarget = null })
    }
    deleteTarget?.let { target ->
        DeleteTrackDialog(
            track = target,
            onConfirm = { vm.deleteTracks(listOf(target)) },
            onDismiss = { deleteTarget = null }
        )
    }
}
