package com.sonora.player.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.Route
import com.sonora.player.data.Track
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun TrackList(
    tracks: List<Track>,
    vm: PlayerViewModel,
    onAddToPlaylist: (Track) -> Unit,
    modifier: Modifier = Modifier,
    numbered: Boolean = false,
    onRemove: ((Track) -> Unit)? = null,
    focusCurrent: Boolean = true,
    listState: LazyListState = rememberLazyListState(),
    onMove: ((moved: Track, target: Track) -> Unit)? = null,
    header: (LazyListScope.() -> Unit)? = null
) {
    val now by vm.now.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val lyricsAvailable by vm.lyricsAvailable.collectAsStateWithLifecycle()
    var editTarget by remember { mutableStateOf<Track?>(null) }
    var coverTarget by remember { mutableStateOf<Track?>(null) }
    var deleteTarget by remember { mutableStateOf<Track?>(null) }
    var selectedIds by remember { mutableStateOf(emptySet<Long>()) }
    var playlistTargets by remember { mutableStateOf<List<Track>?>(null) }
    var deleteTargets by remember { mutableStateOf<List<Track>?>(null) }
    val scope = rememberCoroutineScope()
    val currentId = now.track?.id
    val currentIndex = remember(tracks, currentId) { tracks.indexOfFirst { it.id == currentId } }
    val currentVisible by remember(currentId) {
        derivedStateOf { listState.layoutInfo.visibleItemsInfo.any { it.key == currentId } }
    }
    val selecting = selectedIds.isNotEmpty()
    val selectedTracks = remember(tracks, selectedIds) { tracks.filter { it.id in selectedIds } }

    fun headerCount() = (listState.layoutInfo.totalItemsCount - tracks.size).coerceAtLeast(0)

    val jumpToCurrent: suspend () -> Unit = {
        listState.animateScrollToItem(currentIndex + headerCount(), -(listState.layoutInfo.viewportSize.height / 3))
    }

    val reorder = if (onMove != null) {
        rememberReorderState(
            listState = listState,
            range = { headerCount().let { it until it + tracks.size } },
            onMove = { from, to ->
                val offset = headerCount()
                val moved = tracks.getOrNull(from - offset)
                val target = tracks.getOrNull(to - offset)
                if (moved != null && target != null) onMove(moved, target)
            },
            onFinish = { _, _ -> }
        )
    } else {
        null
    }

    BackHandler(enabled = selecting) { selectedIds = emptySet() }

    LaunchedEffect(tracks) {
        val available = tracks.mapTo(HashSet()) { it.id }
        if (!available.containsAll(selectedIds)) selectedIds = selectedIds intersect available
    }

    LaunchedEffect(focusCurrent, currentIndex >= 0) {
        val atTop = listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0
        if (focusCurrent && currentIndex >= 0 && atTop) {
            snapshotFlow { listState.layoutInfo.totalItemsCount }.first { it >= tracks.size }
            listState.scrollToItem(currentIndex + headerCount(), -(listState.layoutInfo.viewportSize.height / 3))
        }
    }

    Box(modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = listState,
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            header?.invoke(this)
            itemsIndexed(tracks, key = { _, track -> track.id }) { index, track ->
                val dragging = reorder?.draggingKey == track.id
                val rowModifier = when {
                    reorder == null -> Modifier
                    dragging -> Modifier
                        .zIndex(1f)
                        .graphicsLayer { translationY = reorder.offset }
                    else -> Modifier.animateItem(fadeInSpec = null, fadeOutSpec = null)
                }
                val toggle = {
                    selectedIds = if (track.id in selectedIds) selectedIds - track.id else selectedIds + track.id
                }
                TrackRow(
                    track = track,
                    current = now.track?.id == track.id,
                    playing = now.isPlaying,
                    favorite = track.id in favorites,
                    hasLyrics = track.id in lyricsAvailable,
                    index = if (numbered) index else null,
                    onClick = { if (selecting) toggle() else vm.playTracks(tracks, index) },
                    onLongClick = toggle,
                    selecting = selecting,
                    selected = track.id in selectedIds,
                    dragging = dragging,
                    dragHandle = if (reorder != null && !selecting) Modifier.reorderHandle(reorder, track.id) else null,
                    onPlayNext = { vm.playNext(track) },
                    onEnqueue = { vm.enqueue(track) },
                    onFavorite = { vm.toggleFavorite(track) },
                    onAddToPlaylist = { onAddToPlaylist(track) },
                    onOpenAlbum = { vm.open(Route.AlbumRoute(track.albumId)) },
                    onOpenArtist = { vm.open(Route.ArtistRoute(track.artist)) },
                    onRemove = onRemove?.let { remove -> { remove(track) } },
                    onEdit = { editTarget = track },
                    onChangeCover = { coverTarget = track },
                    onDelete = { deleteTarget = track },
                    modifier = rowModifier
                )
            }
        }
        JumpToCurrentButton(
            visible = currentIndex >= 0 && !currentVisible && !selecting,
            onClick = { scope.launch { jumpToCurrent() } },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 16.dp)
        )
        AnimatedVisibility(
            visible = selecting,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it }
        ) {
            SelectionBar(
                count = selectedIds.size,
                onClose = { selectedIds = emptySet() },
                onAddToPlaylist = { playlistTargets = selectedTracks },
                onEnqueue = {
                    vm.enqueue(selectedTracks)
                    selectedIds = emptySet()
                },
                onPlayNext = {
                    vm.playNext(selectedTracks)
                    selectedIds = emptySet()
                },
                onSelectAll = { selectedIds = tracks.mapTo(HashSet()) { it.id } },
                onRemove = onRemove?.let { remove ->
                    {
                        selectedTracks.forEach(remove)
                        selectedIds = emptySet()
                    }
                },
                onDelete = { deleteTargets = selectedTracks }
            )
        }
    }
    editTarget?.let { target ->
        EditTrackDialog(vm = vm, track = target, onDismiss = { editTarget = null })
    }
    coverTarget?.let { target ->
        CoverSearchSheet(vm = vm, track = target, onDismiss = { coverTarget = null })
    }
    deleteTarget?.let { target ->
        DeleteTrackDialog(
            track = target,
            onConfirm = { vm.deleteTracks(listOf(target)) },
            onDismiss = { deleteTarget = null }
        )
    }
    playlistTargets?.let { targets ->
        AddToPlaylistDialog(
            vm = vm,
            tracks = targets,
            onDismiss = {
                playlistTargets = null
                selectedIds = emptySet()
            }
        )
    }
    deleteTargets?.let { targets ->
        DeleteTracksDialog(
            count = targets.size,
            onConfirm = {
                vm.deleteTracks(targets)
                selectedIds = emptySet()
            },
            onDismiss = { deleteTargets = null }
        )
    }
}

@Composable
private fun SelectionBar(
    count: Int,
    onClose: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onEnqueue: () -> Unit,
    onPlayNext: () -> Unit,
    onSelectAll: () -> Unit,
    onRemove: (() -> Unit)?,
    onDelete: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
        shadowElevation = 6.dp
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.Close, contentDescription = "Cancel selection")
            }
            Text(
                text = "$count selected",
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onAddToPlaylist) {
                Icon(Icons.Rounded.PlaylistAdd, contentDescription = "Add to playlist")
            }
            IconButton(onClick = onEnqueue) {
                Icon(Icons.Rounded.QueueMusic, contentDescription = "Add to queue")
            }
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = "More")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    MenuEntry("Play next", Icons.Rounded.SkipNext) { menuOpen = false; onPlayNext() }
                    MenuEntry("Select all", Icons.Rounded.SelectAll) { menuOpen = false; onSelectAll() }
                    if (onRemove != null) {
                        MenuEntry("Remove from playlist", Icons.Rounded.Delete) { menuOpen = false; onRemove() }
                    }
                    MenuEntry("Delete from device", Icons.Rounded.Delete) { menuOpen = false; onDelete() }
                }
            }
        }
    }
}
