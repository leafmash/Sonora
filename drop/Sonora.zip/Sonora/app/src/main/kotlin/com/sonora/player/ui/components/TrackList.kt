package com.sonora.player.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.Route
import com.sonora.player.data.Track

@Composable
fun TrackList(
    tracks: List<Track>,
    vm: PlayerViewModel,
    onAddToPlaylist: (Track) -> Unit,
    modifier: Modifier = Modifier,
    numbered: Boolean = false,
    onRemove: ((Track) -> Unit)? = null,
    focusCurrent: Boolean = true,
    header: (LazyListScope.() -> Unit)? = null
) {
    val now by vm.now.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val lyricsAvailable by vm.lyricsAvailable.collectAsStateWithLifecycle()
    var editTarget by remember { mutableStateOf<Track?>(null) }
    var deleteTarget by remember { mutableStateOf<Track?>(null) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val currentId = now.track?.id
    val currentIndex = remember(tracks, currentId) { tracks.indexOfFirst { it.id == currentId } }
    val currentVisible by remember(currentId) {
        derivedStateOf { listState.layoutInfo.visibleItemsInfo.any { it.key == currentId } }
    }
    val jumpToCurrent: suspend () -> Unit = {
        val headerCount = (listState.layoutInfo.totalItemsCount - tracks.size).coerceAtLeast(0)
        listState.animateScrollToItem(currentIndex + headerCount, -(listState.layoutInfo.viewportSize.height / 3))
    }

    LaunchedEffect(focusCurrent, currentIndex >= 0) {
        val atTop = listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0
        if (focusCurrent && currentIndex >= 0 && atTop) {
            snapshotFlow { listState.layoutInfo.totalItemsCount }.first { it >= tracks.size }
            val headerCount = (listState.layoutInfo.totalItemsCount - tracks.size).coerceAtLeast(0)
            listState.scrollToItem(currentIndex + headerCount, -(listState.layoutInfo.viewportSize.height / 3))
        }
    }

    Box(modifier.fillMaxSize()) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        state = listState,
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        header?.invoke(this)
        itemsIndexed(tracks, key = { _, track -> track.id }) { index, track ->
            TrackRow(
                track = track,
                current = now.track?.id == track.id,
                playing = now.isPlaying,
                favorite = track.id in favorites,
                hasLyrics = track.id in lyricsAvailable,
                index = if (numbered) index else null,
                onClick = { vm.playTracks(tracks, index) },
                onPlayNext = { vm.playNext(track) },
                onEnqueue = { vm.enqueue(track) },
                onFavorite = { vm.toggleFavorite(track) },
                onAddToPlaylist = { onAddToPlaylist(track) },
                onOpenAlbum = { vm.open(Route.AlbumRoute(track.albumId)) },
                onOpenArtist = { vm.open(Route.ArtistRoute(track.artist)) },
                onRemove = onRemove?.let { remove -> { remove(track) } },
                onEdit = { editTarget = track },
                onDelete = { deleteTarget = track }
            )
        }
    }
    JumpToCurrentButton(
        visible = currentIndex >= 0 && !currentVisible,
        onClick = { scope.launch { jumpToCurrent() } },
        modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(end = 16.dp, bottom = 16.dp)
    )
    }
    editTarget?.let { target ->
        EditTrackDialog(vm = vm, track = target, onDismiss = { editTarget = null })
    }
    deleteTarget?.let { target ->
        DeleteTrackDialog(
            track = target,
            onConfirm = { vm.deleteTracks(listOf(target)) },
            onDismiss = { deleteTarget = null }
        )
    }
}
