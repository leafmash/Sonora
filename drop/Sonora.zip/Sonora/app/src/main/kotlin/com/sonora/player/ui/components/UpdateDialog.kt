package com.sonora.player.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.UpdateInfo
import com.sonora.player.data.UpdateState
import kotlin.math.roundToInt

@Composable
fun UpdateDialog(vm: PlayerViewModel) {
    val state by vm.update.collectAsStateWithLifecycle()
    when (val current = state) {
        is UpdateState.Available -> AlertDialog(
            onDismissRequest = vm::dismissUpdate,
            title = { Text("Update available") },
            text = { AvailableBody(current.info) },
            confirmButton = { TextButton(onClick = vm::startUpdateDownload) { Text("Update") } },
            dismissButton = { TextButton(onClick = vm::dismissUpdate) { Text("Later") } }
        )
        is UpdateState.Downloading -> AlertDialog(
            onDismissRequest = {},
            title = { Text("Downloading update") },
            text = {
                Column {
                    LinearProgressIndicator(progress = { current.progress }, modifier = Modifier.fillMaxWidth())
                    Text(
                        text = "${(current.progress * 100).roundToInt()}%",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            },
            confirmButton = { TextButton(onClick = vm::cancelUpdate) { Text("Cancel") } }
        )
        is UpdateState.Ready -> AlertDialog(
            onDismissRequest = vm::dismissUpdate,
            title = { Text("Ready to install") },
            text = { Text("Sonora ${current.info.version} has been downloaded. Tap Install to finish updating.") },
            confirmButton = { TextButton(onClick = vm::installUpdate) { Text("Install") } },
            dismissButton = { TextButton(onClick = vm::dismissUpdate) { Text("Later") } }
        )
        is UpdateState.DownloadFailed -> AlertDialog(
            onDismissRequest = vm::dismissUpdate,
            title = { Text("Download failed") },
            text = { Text("Check your internet connection and try again.") },
            confirmButton = { TextButton(onClick = vm::startUpdateDownload) { Text("Retry") } },
            dismissButton = { TextButton(onClick = vm::dismissUpdate) { Text("Cancel") } }
        )
        UpdateState.Idle -> Unit
    }
}

@Composable
private fun AvailableBody(info: UpdateInfo) {
    Column {
        val size = if (info.sizeBytes > 0) "  ·  ${"%.1f".format(info.sizeBytes / 1_048_576.0)} MB" else ""
        Text(
            text = "Sonora ${info.version} is ready to download$size.",
            style = MaterialTheme.typography.bodyMedium
        )
        if (info.notes.isNotBlank()) {
            Text(
                text = "What's new",
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(top = 12.dp)
            )
            Column(
                Modifier
                    .heightIn(max = 200.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = info.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
