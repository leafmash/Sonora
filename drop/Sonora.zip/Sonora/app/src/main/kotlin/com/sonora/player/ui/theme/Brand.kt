package com.sonora.player.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

@Composable
fun brandBrush(): Brush {
    val scheme = MaterialTheme.colorScheme
    return remember(scheme.primary, scheme.secondary) {
        Brush.linearGradient(listOf(scheme.primary, scheme.secondary))
    }
}

@Composable
fun Modifier.auroraBackdrop(): Modifier {
    val scheme = MaterialTheme.colorScheme
    val strength = if (scheme.background.luminance() < 0.5f) 0.2f else 0.14f
    val first = scheme.primary
    val second = scheme.secondary
    val third = scheme.tertiary
    return drawBehind {
        drawRect(
            Brush.radialGradient(
                listOf(second.copy(alpha = strength), Color.Transparent),
                center = Offset(size.width * 0.05f, 0f),
                radius = size.width * 0.95f
            )
        )
        drawRect(
            Brush.radialGradient(
                listOf(first.copy(alpha = strength), Color.Transparent),
                center = Offset(size.width, size.height * 0.12f),
                radius = size.width * 0.85f
            )
        )
        drawRect(
            Brush.radialGradient(
                listOf(third.copy(alpha = strength * 0.7f), Color.Transparent),
                center = Offset(size.width, size.height * 0.58f),
                radius = size.width * 0.7f
            )
        )
    }
}
