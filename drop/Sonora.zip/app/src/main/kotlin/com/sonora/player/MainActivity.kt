package com.sonora.player

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.data.Route
import com.sonora.player.data.Track
import com.sonora.player.ui.AlbumScreen
import com.sonora.player.ui.ArtistScreen
import com.sonora.player.ui.EqualizerScreen
import com.sonora.player.ui.LibraryScreen
import com.sonora.player.ui.MiniPlayer
import com.sonora.player.ui.NowPlayingScreen
import com.sonora.player.ui.PlaylistScreen
import com.sonora.player.ui.PlaylistsScreen
import com.sonora.player.ui.SearchScreen
import com.sonora.player.ui.SettingsScreen
import com.sonora.player.ui.TrackCollectionScreen
import com.sonora.player.ui.components.AddToPlaylistDialog
import com.sonora.player.ui.components.EmptyState
import com.sonora.player.ui.theme.SonoraTheme

class MainActivity : ComponentActivity() {

    private val vm: PlayerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        )
        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            SonoraTheme(mode = settings.themeMode, dynamic = settings.dynamicColor) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    SonoraRoot(vm)
                }
            }
        }
    }
}

private data class Tab(val label: String, val icon: ImageVector)

private val Tabs = listOf(
    Tab("Library", Icons.Rounded.LibraryMusic),
    Tab("Search", Icons.Rounded.Search),
    Tab("Playlists", Icons.Rounded.QueueMusic),
    Tab("Settings", Icons.Rounded.Settings)
)

@Composable
private fun SonoraRoot(vm: PlayerViewModel) {
    val audioPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    var granted by remember { mutableStateOf<Boolean?>(null) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { result ->
        granted = result
        if (result) vm.onAccessGranted()
    }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) {
        val has = androidx.core.content.ContextCompat.checkSelfPermission(context, audioPermission) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        if (has) {
            granted = true
            vm.onAccessGranted()
        } else {
            permissionLauncher.launch(audioPermission)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    if (granted == false) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            EmptyState(
                icon = Icons.Rounded.LibraryMusic,
                title = "Allow music access",
                message = "Sonora needs permission to read the audio files on your device.",
                modifier = Modifier.weight(1f)
            )
            Button(onClick = { permissionLauncher.launch(audioPermission) }) {
                Text("Grant access", textAlign = TextAlign.Center)
            }
        }
        return
    }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var expanded by rememberSaveable { mutableStateOf(false) }
    var playlistTarget by remember { mutableStateOf<List<Track>?>(null) }

    val routes by vm.routes.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val route = routes.lastOrNull()
    val addToPlaylist: (Track) -> Unit = { playlistTarget = listOf(it) }

    BackHandler(enabled = expanded) { expanded = false }
    BackHandler(enabled = !expanded && routes.isNotEmpty()) { vm.back() }
    BackHandler(enabled = !expanded && routes.isEmpty() && tab != 0) { tab = 0 }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                AnimatedContent(
                    targetState = route,
                    transitionSpec = {
                        if (targetState != null && initialState == null) {
                            (slideInHorizontally(tween(280)) { it / 4 } + fadeIn(tween(280))) togetherWith
                                fadeOut(tween(160))
                        } else {
                            fadeIn(tween(200)) togetherWith
                                (slideOutHorizontally(tween(280)) { it / 4 } + fadeOut(tween(200)))
                        }
                    },
                    label = "routes"
                ) { target ->
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background)
                    ) {
                        if (target == null) {
                            when (tab) {
                                0 -> LibraryScreen(vm, addToPlaylist)
                                1 -> SearchScreen(vm, addToPlaylist)
                                2 -> PlaylistsScreen(vm)
                                else -> SettingsScreen(vm)
                            }
                        } else {
                            RouteContent(target, vm, addToPlaylist)
                        }
                    }
                }
            }
            if (now.track != null) {
                MiniPlayer(vm) { expanded = true }
            }
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                Tabs.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = tab == index && routes.isEmpty(),
                        onClick = {
                            tab = index
                            vm.clearRoutes()
                        },
                        icon = { Icon(item.icon, contentDescription = item.label, modifier = Modifier.size(24.dp)) },
                        label = { Text(item.label) }
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = expanded && now.track != null,
            enter = slideInVertically(tween(320)) { it } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(280)) { it } + fadeOut(tween(200))
        ) {
            NowPlayingScreen(
                vm = vm,
                onCollapse = { expanded = false },
                onAddToPlaylist = addToPlaylist,
                onOpenEqualizer = {
                    expanded = false
                    vm.open(Route.EqualizerRoute)
                }
            )
        }
    }

    playlistTarget?.let { targets ->
        AddToPlaylistDialog(vm = vm, tracks = targets, onDismiss = { playlistTarget = null })
    }
}

@Composable
private fun RouteContent(route: Route, vm: PlayerViewModel, onAddToPlaylist: (Track) -> Unit) {
    val library by vm.library.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()

    when (route) {
        is Route.AlbumRoute -> {
            val album = library.albums.firstOrNull { it.id == route.albumId }
            if (album != null) AlbumScreen(album, vm, vm::back, onAddToPlaylist)
        }
        is Route.ArtistRoute -> {
            val artist = library.artists.firstOrNull { it.name == route.name }
            if (artist != null) {
                val albums = library.albums.filter { album -> album.tracks.any { it.artist == artist.name } }
                ArtistScreen(artist, albums, vm, vm::back, onAddToPlaylist)
            }
        }
        is Route.PlaylistRoute -> {
            val playlist = playlists.firstOrNull { it.id == route.id }
            if (playlist != null) {
                val tracks = playlist.trackIds.mapNotNull { library.track(it) }
                PlaylistScreen(playlist, tracks, vm, vm::back, onAddToPlaylist)
            }
        }
        Route.FavoritesRoute -> {
            val tracks = favorites.mapNotNull { library.track(it) }
            TrackCollectionScreen(
                title = "Favorites",
                subtitle = "${tracks.size} songs",
                tracks = tracks,
                cover = tracks.firstOrNull(),
                vm = vm,
                onBack = vm::back,
                onAddToPlaylist = onAddToPlaylist
            )
        }
        Route.RecentRoute -> {
            val tracks = library.tracks.sortedByDescending { it.dateAdded }.take(50)
            TrackCollectionScreen(
                title = "Recently added",
                subtitle = "${tracks.size} songs",
                tracks = tracks,
                cover = tracks.firstOrNull(),
                vm = vm,
                onBack = vm::back,
                onAddToPlaylist = onAddToPlaylist
            )
        }
        Route.EqualizerRoute -> EqualizerScreen(onBack = vm::back)
    }
}
