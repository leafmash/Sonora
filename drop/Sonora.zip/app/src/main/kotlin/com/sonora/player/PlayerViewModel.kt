package com.sonora.player

import android.app.Application
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.sonora.player.data.AppSettings
import com.sonora.player.data.Library
import com.sonora.player.data.LibraryStore
import com.sonora.player.data.MusicRepository
import com.sonora.player.data.Playlist
import com.sonora.player.data.Route
import com.sonora.player.data.SavedSession
import com.sonora.player.data.Track
import com.sonora.player.playback.PlaybackService
import com.sonora.player.playback.SleepTimer
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

data class NowPlaying(
    val track: Track? = null,
    val isPlaying: Boolean = false,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val speed: Float = 1f,
    val queue: List<Track> = emptyList(),
    val queueIndex: Int = -1
)

fun Track.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId))
                .build()
        )
        .build()

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    private val context: Context = app
    private val repository = MusicRepository(app)
    private val store = LibraryStore(app)

    private var controller: MediaController? = null
    private var queueCache: List<Track> = emptyList()
    private var restored = false
    private var hasAccess = false
    private var refreshJob: Job? = null

    private val mutableLibrary = MutableStateFlow(Library())
    private val mutableLoading = MutableStateFlow(false)
    private val mutableNow = MutableStateFlow(NowPlaying())
    private val mutablePosition = MutableStateFlow(0L)
    private val mutableFavorites = MutableStateFlow(store.favorites())
    private val mutablePlaylists = MutableStateFlow(store.playlists())
    private val mutableSettings = MutableStateFlow(store.settings())
    private val mutableRoutes = MutableStateFlow<List<Route>>(emptyList())

    val library: StateFlow<Library> = mutableLibrary.asStateFlow()
    val loading: StateFlow<Boolean> = mutableLoading.asStateFlow()
    val now: StateFlow<NowPlaying> = mutableNow.asStateFlow()
    val position: StateFlow<Long> = mutablePosition.asStateFlow()
    val favorites: StateFlow<Set<Long>> = mutableFavorites.asStateFlow()
    val playlists: StateFlow<List<Playlist>> = mutablePlaylists.asStateFlow()
    val settings: StateFlow<AppSettings> = mutableSettings.asStateFlow()
    val routes: StateFlow<List<Route>> = mutableRoutes.asStateFlow()
    val sleepRemaining: StateFlow<Long?> = SleepTimer.remaining

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            if (hasAccess) scheduleRefresh()
        }
    }

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync(events.contains(Player.EVENT_TIMELINE_CHANGED))
            if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION) ||
                (events.contains(Player.EVENT_IS_PLAYING_CHANGED) && !player.isPlaying)
            ) {
                saveSession()
            }
        }
    }

    init {
        app.contentResolver.registerContentObserver(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, observer)
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            runCatching { future.get() }.getOrNull()?.let { connected ->
                controller = connected
                connected.addListener(listener)
                sync(true)
                restoreSession()
            }
        }, ContextCompat.getMainExecutor(app))
        viewModelScope.launch { tick() }
    }

    fun onAccessGranted() {
        hasAccess = true
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            mutableLoading.value = true
            val loaded = runCatching { repository.load(mutableSettings.value.hideShort) }.getOrNull()
            if (loaded != null) mutableLibrary.value = loaded
            mutableLoading.value = false
            sync(true)
            restoreSession()
        }
    }

    private fun scheduleRefresh() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            delay(1500)
            refresh()
        }
    }

    private suspend fun tick() {
        var elapsed = 0L
        while (true) {
            val c = controller
            if (c != null) {
                mutablePosition.value = c.currentPosition.coerceAtLeast(0L)
                if (c.isPlaying) {
                    elapsed += 250
                    if (elapsed >= 5000) {
                        elapsed = 0
                        saveSession()
                    }
                }
            }
            delay(250)
        }
    }

    private fun sync(rebuildQueue: Boolean = false) {
        val c = controller ?: return
        val lib = mutableLibrary.value
        if (rebuildQueue) {
            queueCache = (0 until c.mediaItemCount).mapNotNull { index ->
                c.getMediaItemAt(index).mediaId.toLongOrNull()?.let { lib.track(it) }
            }
        }
        val current = c.currentMediaItem?.mediaId?.toLongOrNull()?.let { lib.track(it) }
        val duration = c.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: current?.durationMs ?: 0L
        mutableNow.value = NowPlaying(
            track = current,
            isPlaying = c.isPlaying,
            durationMs = duration,
            shuffle = c.shuffleModeEnabled,
            repeat = c.repeatMode,
            speed = c.playbackParameters.speed,
            queue = queueCache,
            queueIndex = c.currentMediaItemIndex
        )
    }

    private fun restoreSession() {
        val c = controller ?: return
        val lib = mutableLibrary.value
        if (restored || lib.tracks.isEmpty()) return
        restored = true
        if (c.mediaItemCount > 0) return
        val saved = store.session() ?: return
        val tracks = saved.ids.mapNotNull { lib.track(it) }
        if (tracks.isEmpty()) return
        c.setMediaItems(tracks.map { it.toMediaItem() }, saved.index.coerceIn(tracks.indices), saved.positionMs)
        c.prepare()
    }

    private fun saveSession() {
        val c = controller ?: return
        if (queueCache.isEmpty()) return
        store.saveSession(SavedSession(queueCache.map { it.id }, c.currentMediaItemIndex, c.currentPosition))
    }

    fun playTracks(tracks: List<Track>, startIndex: Int, shuffle: Boolean = false) {
        val c = controller ?: return
        if (tracks.isEmpty()) return
        c.shuffleModeEnabled = shuffle
        c.setMediaItems(tracks.map { it.toMediaItem() }, startIndex.coerceIn(tracks.indices), 0L)
        c.prepare()
        c.play()
    }

    fun shufflePlay(tracks: List<Track>) {
        if (tracks.isEmpty()) return
        playTracks(tracks, Random.nextInt(tracks.size), shuffle = true)
    }

    fun togglePlay() {
        val c = controller ?: return
        when {
            c.isPlaying -> c.pause()
            c.playbackState == Player.STATE_ENDED -> {
                c.seekToDefaultPosition()
                c.play()
            }
            else -> {
                if (c.playbackState == Player.STATE_IDLE) c.prepare()
                c.play()
            }
        }
    }

    fun next() {
        controller?.seekToNext()
    }

    fun previous() {
        controller?.seekToPrevious()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        mutablePosition.value = ms
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun setSpeed(speed: Float) {
        controller?.setPlaybackSpeed(speed)
    }

    fun playQueueIndex(index: Int) {
        val c = controller ?: return
        if (index in 0 until c.mediaItemCount) {
            c.seekToDefaultPosition(index)
            c.play()
        }
    }

    fun removeFromQueue(index: Int) {
        val c = controller ?: return
        if (index in 0 until c.mediaItemCount) c.removeMediaItem(index)
    }

    fun playNext(track: Track) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            c.setMediaItem(track.toMediaItem())
            c.prepare()
        } else {
            c.addMediaItem(c.currentMediaItemIndex + 1, track.toMediaItem())
        }
    }

    fun enqueue(track: Track) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            c.setMediaItem(track.toMediaItem())
            c.prepare()
        } else {
            c.addMediaItem(track.toMediaItem())
        }
    }

    fun toggleFavorite(track: Track) {
        val updated = mutableFavorites.value.let { if (track.id in it) it - track.id else it + track.id }
        mutableFavorites.value = updated
        store.saveFavorites(updated)
    }

    fun createPlaylist(name: String, initial: List<Long> = emptyList()): Long {
        val id = System.currentTimeMillis()
        val title = name.trim().ifEmpty { "New playlist" }
        updatePlaylists { it + Playlist(id, title, initial.distinct()) }
        return id
    }

    fun renamePlaylist(id: Long, name: String) {
        val title = name.trim()
        if (title.isEmpty()) return
        updatePlaylists { list -> list.map { if (it.id == id) it.copy(name = title) else it } }
    }

    fun deletePlaylist(id: Long) {
        updatePlaylists { list -> list.filterNot { it.id == id } }
    }

    fun addToPlaylist(playlistId: Long, ids: List<Long>) {
        updatePlaylists { list ->
            list.map { if (it.id == playlistId) it.copy(trackIds = (it.trackIds + ids).distinct()) else it }
        }
    }

    fun removeFromPlaylist(playlistId: Long, trackId: Long) {
        updatePlaylists { list ->
            list.map { if (it.id == playlistId) it.copy(trackIds = it.trackIds - trackId) else it }
        }
    }

    private fun updatePlaylists(transform: (List<Playlist>) -> List<Playlist>) {
        val updated = transform(mutablePlaylists.value)
        mutablePlaylists.value = updated
        store.savePlaylists(updated)
    }

    fun startSleepTimer(minutes: Int) {
        SleepTimer.start(minutes)
    }

    fun cancelSleepTimer() {
        SleepTimer.cancel()
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val old = mutableSettings.value
        val updated = transform(old)
        mutableSettings.value = updated
        store.saveSettings(updated)
        if (old.hideShort != updated.hideShort && hasAccess) refresh()
    }

    fun open(route: Route) {
        mutableRoutes.value = mutableRoutes.value + route
    }

    fun back() {
        val current = mutableRoutes.value
        if (current.isNotEmpty()) mutableRoutes.value = current.dropLast(1)
    }

    fun clearRoutes() {
        mutableRoutes.value = emptyList()
    }

    override fun onCleared() {
        saveSession()
        context.contentResolver.unregisterContentObserver(observer)
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
