package com.sonora.player.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class LibraryStore(context: Context) {

    private val prefs = context.getSharedPreferences("sonora", Context.MODE_PRIVATE)

    fun favorites(): Set<Long> =
        prefs.getStringSet("favorites", emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()

    fun saveFavorites(ids: Set<Long>) {
        prefs.edit().putStringSet("favorites", ids.map { it.toString() }.toSet()).apply()
    }

    fun playlists(): List<Playlist> {
        val raw = prefs.getString("playlists", null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val obj = array.getJSONObject(i)
                val ids = obj.getJSONArray("tracks")
                Playlist(
                    id = obj.getLong("id"),
                    name = obj.getString("name"),
                    trackIds = (0 until ids.length()).map { ids.getLong(it) }
                )
            }
        }.getOrDefault(emptyList())
    }

    fun savePlaylists(list: List<Playlist>) {
        val array = JSONArray()
        list.forEach { playlist ->
            array.put(
                JSONObject()
                    .put("id", playlist.id)
                    .put("name", playlist.name)
                    .put("tracks", JSONArray(playlist.trackIds))
            )
        }
        prefs.edit().putString("playlists", array.toString()).apply()
    }

    fun settings(): AppSettings = AppSettings(
        themeMode = runCatching { ThemeMode.valueOf(prefs.getString("theme", "") ?: "") }.getOrDefault(ThemeMode.System),
        dynamicColor = prefs.getBoolean("dynamic", true),
        hideShort = prefs.getBoolean("hide_short", true),
        sort = runCatching { SortOrder.valueOf(prefs.getString("sort", "") ?: "") }.getOrDefault(SortOrder.Title),
        onlineLyrics = prefs.getBoolean("online_lyrics", true),
        lyricsMode = prefs.getBoolean("lyrics_mode", false)
    )

    fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putString("theme", settings.themeMode.name)
            .putBoolean("dynamic", settings.dynamicColor)
            .putBoolean("hide_short", settings.hideShort)
            .putString("sort", settings.sort.name)
            .putBoolean("online_lyrics", settings.onlineLyrics)
            .putBoolean("lyrics_mode", settings.lyricsMode)
            .apply()
    }

    fun session(): SavedSession? {
        val ids = prefs.getString("session_ids", null)
            ?.split(',')
            ?.mapNotNull { it.toLongOrNull() }
            .orEmpty()
        if (ids.isEmpty()) return null
        return SavedSession(ids, prefs.getInt("session_index", 0), prefs.getLong("session_position", 0L))
    }

    fun saveSession(session: SavedSession) {
        prefs.edit()
            .putString("session_ids", session.ids.joinToString(","))
            .putInt("session_index", session.index)
            .putLong("session_position", session.positionMs)
            .apply()
    }
}
