package com.sonora.player.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

class LyricsRepository(context: Context) {

    private val dir = File(context.filesDir, "lyrics").apply { mkdirs() }

    private data class Hit(val synced: String?, val plain: String?)

    suspend fun load(track: Track, online: Boolean, force: Boolean): LyricsState =
        withContext(Dispatchers.IO) { loadBlocking(track, online, force) }

    suspend fun saveImported(trackId: Long, text: String): LyricsState =
        withContext(Dispatchers.IO) {
            val clean = text.take(300_000)
            val lines = LrcParser.parse(clean)
            if (lines.isNotEmpty()) {
                store(trackId, "lrc", clean)
                LyricsState.Synced(lines)
            } else {
                val plain = clean.trim()
                store(trackId, "txt", plain)
                LyricsState.Plain(plain)
            }
        }

    private fun loadBlocking(track: Track, online: Boolean, force: Boolean): LyricsState {
        val cached = readCache(track.id)
        if (cached != null && !force) return cached
        val cachedLyrics = cached?.takeIf { it is LyricsState.Synced || it is LyricsState.Plain }
        if (!online) return cachedLyrics ?: LyricsState.NotFound

        val hit = try {
            fetch(track)
        } catch (e: Exception) {
            return cachedLyrics ?: LyricsState.Failed
        }

        if (hit != null) {
            val lines = hit.synced?.let { LrcParser.parse(it) }.orEmpty()
            if (lines.isNotEmpty()) {
                store(track.id, "lrc", hit.synced.orEmpty())
                return LyricsState.Synced(lines)
            }
            val plain = hit.plain?.trim().orEmpty()
            if (plain.isNotEmpty()) {
                if (cachedLyrics is LyricsState.Synced) return cachedLyrics
                store(track.id, "txt", plain)
                return LyricsState.Plain(plain)
            }
        }

        if (cachedLyrics != null) return cachedLyrics
        store(track.id, "none", "")
        return LyricsState.NotFound
    }

    private fun readCache(id: Long): LyricsState? {
        val synced = File(dir, "$id.lrc")
        if (synced.exists()) {
            val lines = LrcParser.parse(synced.readText())
            if (lines.isNotEmpty()) return LyricsState.Synced(lines)
        }
        val plainFile = File(dir, "$id.txt")
        if (plainFile.exists()) {
            val text = plainFile.readText().trim()
            if (text.isNotEmpty()) return LyricsState.Plain(text)
        }
        val none = File(dir, "$id.none")
        if (none.exists() && System.currentTimeMillis() - none.lastModified() < NONE_TTL_MS) {
            return LyricsState.NotFound
        }
        return null
    }

    private fun store(id: Long, extension: String, text: String) {
        listOf("lrc", "txt", "none").forEach { other ->
            if (other != extension) File(dir, "$id.$other").delete()
        }
        File(dir, "$id.$extension").writeText(text)
    }

    private fun fetch(track: Track): Hit? {
        val seconds = (track.durationMs / 1000).toInt()
        val knownArtist = track.artist != "Unknown artist"
        val knownAlbum = track.album != "Unknown album"

        if (knownArtist && knownAlbum) {
            val url = "$BASE/get?track_name=${enc(track.title)}&artist_name=${enc(track.artist)}" +
                "&album_name=${enc(track.album)}&duration=$seconds"
            get(url)?.let { body ->
                hitFrom(JSONObject(body))?.let { return it }
            }
        }

        val queries = buildList {
            if (knownArtist) add("track_name=${enc(track.title)}&artist_name=${enc(track.artist)}")
            val words = if (knownArtist) "${track.title} ${track.artist}" else track.title
            add("q=${enc(words)}")
        }
        for (query in queries) {
            val body = get("$BASE/search?$query") ?: continue
            val array = JSONArray(body)
            val entries = (0 until array.length()).map { array.getJSONObject(it) }
            best(entries, seconds)?.let { return it }
        }
        return null
    }

    private fun best(entries: List<JSONObject>, seconds: Int): Hit? {
        val close = entries
            .filter { abs(it.optDouble("duration", -1000.0) - seconds) <= 6.0 }
            .sortedBy { abs(it.optDouble("duration", 0.0) - seconds) }
        if (close.isEmpty()) return null
        close.firstOrNull { !text(it, "syncedLyrics").isNullOrBlank() }?.let {
            return Hit(text(it, "syncedLyrics"), text(it, "plainLyrics"))
        }
        close.firstOrNull { !text(it, "plainLyrics").isNullOrBlank() }?.let {
            return Hit(null, text(it, "plainLyrics"))
        }
        return null
    }

    private fun hitFrom(obj: JSONObject): Hit? {
        val synced = text(obj, "syncedLyrics")
        val plain = text(obj, "plainLyrics")
        if (synced.isNullOrBlank() && plain.isNullOrBlank()) return null
        return Hit(synced, plain)
    }

    private fun text(obj: JSONObject, key: String): String? =
        if (obj.isNull(key)) null else obj.getString(key)

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun get(url: String): String? {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 8000
            connection.readTimeout = 10000
            connection.setRequestProperty("User-Agent", "Sonora/1.0 (Android music player)")
            val code = connection.responseCode
            if (code == 404) return null
            if (code !in 200..299) throw IOException("HTTP $code")
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private companion object {
        const val BASE = "https://lrclib.net/api"
        const val NONE_TTL_MS = 3L * 24 * 60 * 60 * 1000
    }
}
