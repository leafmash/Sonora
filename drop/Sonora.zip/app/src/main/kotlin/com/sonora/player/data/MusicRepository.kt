package com.sonora.player.data

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MusicRepository(private val context: Context) {

    suspend fun load(hideShort: Boolean, edits: Map<Long, TrackEdit> = emptyMap()): Library = withContext(Dispatchers.IO) {
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATA
        )
        val minDuration = if (hideShort) 30_000L else 1_000L
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= ?"
        val order = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        val tracks = ArrayList<Track>()

        context.contentResolver.query(collection, projection, selection, arrayOf(minDuration.toString()), order)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val addedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val rawArtist = cursor.getString(artistCol)
                    ?.takeUnless { it == MediaStore.UNKNOWN_STRING || it.isBlank() }
                val rawTitle = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                val shown = TrackNameCleaner.display(rawTitle, rawArtist)
                val artist = shown.artist ?: "Unknown artist"
                val album = cursor.getString(albumCol)
                    ?.takeUnless { it.isBlank() || it == MediaStore.UNKNOWN_STRING }
                    ?: "Unknown album"
                val path = cursor.getString(dataCol).orEmpty()
                val edit = edits[id]
                tracks += Track(
                    id = id,
                    title = edit?.title ?: shown.title.takeIf { it.isNotBlank() } ?: rawTitle ?: "Unknown title",
                    artist = edit?.artist ?: artist,
                    album = edit?.album ?: album,
                    albumId = cursor.getLong(albumIdCol),
                    durationMs = cursor.getLong(durationCol),
                    uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                    dateAdded = cursor.getLong(addedCol),
                    folder = path.substringBeforeLast('/', "").substringAfterLast('/')
                )
            }
        }

        val albums = tracks
            .groupBy { it.albumId }
            .map { (albumId, list) ->
                Album(
                    id = albumId,
                    name = list.first().album,
                    artist = list.groupingBy { it.artist }.eachCount().maxByOrNull { it.value }?.key ?: list.first().artist,
                    tracks = list
                )
            }
            .sortedBy { it.name.lowercase() }

        val artists = tracks
            .groupBy { it.artist }
            .map { (name, list) -> Artist(name, list, list.map { it.albumId }.distinct().size) }
            .sortedBy { it.name.lowercase() }

        Library(tracks, albums, artists)
    }
}
