package com.sonora.player.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.Album
import com.sonora.player.data.Artist
import com.sonora.player.data.Playlist
import com.sonora.player.data.Route
import com.sonora.player.data.Track
import com.sonora.player.ui.components.AlbumCard
import com.sonora.player.ui.components.Artwork
import com.sonora.player.ui.components.SectionTitle
import com.sonora.player.ui.components.TextPromptDialog
import com.sonora.player.ui.components.TrackList

@Composable
fun TrackCollectionScreen(
    title: String,
    subtitle: String,
    tracks: List<Track>,
    cover: Track?,
    vm: PlayerViewModel,
    onBack: () -> Unit,
    onAddToPlaylist: (Track) -> Unit,
    circleCover: Boolean = false,
    numbered: Boolean = false,
    onRemove: ((Track) -> Unit)? = null,
    actions: @Composable () -> Unit = {},
    extraHeader: (LazyListScope.() -> Unit)? = null
) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Back")
            }
            Spacer(Modifier.weight(1f))
            actions()
        }
        TrackList(
            tracks = tracks,
            vm = vm,
            onAddToPlaylist = onAddToPlaylist,
            numbered = numbered,
            onRemove = onRemove,
            header = {
                item {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Artwork(
                            track = cover,
                            modifier = Modifier.size(200.dp),
                            shape = if (circleCover) CircleShape else RoundedCornerShape(28.dp)
                        )
                        Spacer(Modifier.height(18.dp))
                        Text(
                            text = title,
                            style = MaterialTheme.typography.headlineSmall,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(18.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = { vm.playTracks(tracks, 0) },
                                enabled = tracks.isNotEmpty()
                            ) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Play")
                            }
                            FilledTonalButton(
                                onClick = { vm.shufflePlay(tracks) },
                                enabled = tracks.isNotEmpty()
                            ) {
                                Icon(Icons.Rounded.Shuffle, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Shuffle")
                            }
                        }
                    }
                }
                extraHeader?.invoke(this)
                if (tracks.isEmpty()) {
                    item {
                        Text(
                            text = "Nothing here yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp)
                        )
                    }
                }
            }
        )
    }
}

@Composable
fun AlbumScreen(
    album: Album,
    vm: PlayerViewModel,
    onBack: () -> Unit,
    onAddToPlaylist: (Track) -> Unit
) {
    val total = remember(album) { album.tracks.sumOf { it.durationMs } }
    TrackCollectionScreen(
        title = album.name,
        subtitle = "${album.artist}  ·  ${album.tracks.size} songs  ·  ${formatTotal(total)}",
        tracks = album.tracks,
        cover = album.cover,
        vm = vm,
        onBack = onBack,
        onAddToPlaylist = onAddToPlaylist,
        numbered = true
    )
}

@Composable
fun ArtistScreen(
    artist: Artist,
    albums: List<Album>,
    vm: PlayerViewModel,
    onBack: () -> Unit,
    onAddToPlaylist: (Track) -> Unit
) {
    TrackCollectionScreen(
        title = artist.name,
        subtitle = "${artist.tracks.size} songs  ·  ${artist.albumCount} albums",
        tracks = artist.tracks,
        cover = artist.tracks.first(),
        vm = vm,
        onBack = onBack,
        onAddToPlaylist = onAddToPlaylist,
        circleCover = true,
        extraHeader = {
            if (albums.isNotEmpty()) {
                item { SectionTitle("Albums") }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        items(albums, key = { it.id }) { album ->
                            AlbumCard(
                                album = album,
                                onClick = { vm.open(Route.AlbumRoute(album.id)) },
                                modifier = Modifier.width(140.dp)
                            )
                        }
                    }
                }
                item { SectionTitle("Songs") }
            }
        }
    )
}

@Composable
fun PlaylistScreen(
    playlist: Playlist,
    tracks: List<Track>,
    vm: PlayerViewModel,
    onBack: () -> Unit,
    onAddToPlaylist: (Track) -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    TrackCollectionScreen(
        title = playlist.name,
        subtitle = "${tracks.size} songs",
        tracks = tracks,
        cover = tracks.firstOrNull(),
        vm = vm,
        onBack = onBack,
        onAddToPlaylist = onAddToPlaylist,
        onRemove = { vm.removeFromPlaylist(playlist.id, it.id) },
        actions = {
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = "More")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Rename") },
                        onClick = {
                            menuOpen = false
                            renaming = true
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete playlist") },
                        onClick = {
                            menuOpen = false
                            deleting = true
                        }
                    )
                }
            }
        }
    )

    if (renaming) {
        TextPromptDialog(
            title = "Rename playlist",
            initial = playlist.name,
            confirmLabel = "Save",
            onConfirm = { vm.renamePlaylist(playlist.id, it) },
            onDismiss = { renaming = false }
        )
    }
    if (deleting) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            title = { Text("Delete playlist?") },
            text = { Text("\"${playlist.name}\" will be removed. Your songs stay on the device.") },
            confirmButton = {
                TextButton(onClick = {
                    deleting = false
                    vm.deletePlaylist(playlist.id)
                    vm.back()
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = false }) { Text("Cancel") } }
        )
    }
}
