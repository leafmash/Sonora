package com.sonora.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.TextDecrease
import androidx.compose.material.icons.rounded.TextIncrease
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.LyricsState
import com.sonora.player.data.Track
import kotlin.math.roundToInt

private const val MinScale = 0.7f
private const val MaxScale = 1.7f
private const val ScaleStep = 0.1f

@Composable
fun LyricsFullScreen(
    vm: PlayerViewModel,
    track: Track,
    state: LyricsState,
    isPlaying: Boolean,
    top: Color,
    bright: Color,
    onImport: () -> Unit,
    onClose: () -> Unit
) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val position by vm.position.collectAsStateWithLifecycle()
    val scale = settings.lyricsScale
    val view = LocalView.current

    BackHandler(onBack = onClose)

    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    fun changeScale(delta: Float) {
        vm.updateSettings {
            val next = ((it.lyricsScale + delta) * 10f).roundToInt() / 10f
            it.copy(lyricsScale = next.coerceIn(MinScale, MaxScale))
        }
    }

    val soft = Color.White.copy(alpha = 0.7f)
    val fraction = if (track.durationMs > 0) (position.toFloat() / track.durationMs).coerceIn(0f, 1f) else 0f

    Box(
        Modifier
            .fillMaxSize()
            .nowPlayingBackdrop(top, bright)
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Rounded.FullscreenExit, contentDescription = "Exit full screen", tint = Color.White)
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = track.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = track.artist,
                        style = MaterialTheme.typography.labelMedium,
                        color = soft,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = { changeScale(-ScaleStep) }, enabled = scale > MinScale + 0.01f) {
                    Icon(
                        Icons.Rounded.TextDecrease,
                        contentDescription = "Smaller text",
                        tint = if (scale > MinScale + 0.01f) Color.White else soft.copy(alpha = 0.3f)
                    )
                }
                IconButton(onClick = { changeScale(ScaleStep) }, enabled = scale < MaxScale - 0.01f) {
                    Icon(
                        Icons.Rounded.TextIncrease,
                        contentDescription = "Larger text",
                        tint = if (scale < MaxScale - 0.01f) Color.White else soft.copy(alpha = 0.3f)
                    )
                }
            }

            LyricsPanel(
                vm = vm,
                track = track,
                state = state,
                onImport = onImport,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            )

            Box(
                Modifier
                    .padding(top = 12.dp)
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.2f))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(fraction)
                        .height(3.dp)
                        .background(Color.White)
                )
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = vm::previous) {
                    Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous", tint = Color.White, modifier = Modifier.size(36.dp))
                }
                Box(
                    Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .clickable(onClick = vm::togglePlay),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color(0xFF0B0A10),
                        modifier = Modifier.size(34.dp)
                    )
                }
                IconButton(onClick = vm::next) {
                    Icon(Icons.Rounded.SkipNext, contentDescription = "Next", tint = Color.White, modifier = Modifier.size(36.dp))
                }
            }
        }
    }
}
