package com.sonora.player.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.LrcParser
import com.sonora.player.data.LyricLine
import com.sonora.player.data.LyricsState
import com.sonora.player.data.Track
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlin.math.abs

private val LyricInk = Color(0xFF0B0A10)
private val LyricSoft = Color.White.copy(alpha = 0.7f)

@Composable
fun LyricsPanel(
    vm: PlayerViewModel,
    track: Track,
    state: LyricsState,
    onImport: () -> Unit,
    modifier: Modifier = Modifier,
    onFullscreen: (() -> Unit)? = null
) {
    var searching by remember { mutableStateOf(false) }
    val settings by vm.settings.collectAsStateWithLifecycle()
    val scale = settings.lyricsScale

    Box(modifier) {
        when (state) {
            LyricsState.Idle, LyricsState.Loading -> LoadingMessage()
            is LyricsState.Synced -> SyncedLyrics(vm, state.lines, scale)
            is LyricsState.Plain -> PlainLyrics(state.text, scale)
            LyricsState.NotFound -> EmptyMessage(
                title = "No lyrics found",
                message = "Search by title and singer, or import an .lrc file for this song.",
                onSearch = { searching = true },
                onRetry = vm::retryLyrics,
                onImport = onImport
            )
            LyricsState.Failed -> EmptyMessage(
                title = "Can't reach the lyrics service",
                message = "Check your connection, try again, or search by title and singer.",
                onSearch = { searching = true },
                onRetry = vm::retryLyrics,
                onImport = onImport
            )
        }
        if (state is LyricsState.Synced || state is LyricsState.Plain) {
            Row(Modifier.align(Alignment.TopEnd)) {
                if (onFullscreen != null) {
                    IconButton(onClick = onFullscreen) {
                        Icon(Icons.Rounded.Fullscreen, contentDescription = "Full screen lyrics", tint = LyricSoft)
                    }
                }
                IconButton(onClick = { searching = true }) {
                    Icon(Icons.Rounded.Search, contentDescription = "Search lyrics", tint = LyricSoft)
                }
                IconButton(onClick = onImport) {
                    Icon(Icons.Rounded.UploadFile, contentDescription = "Import .lrc", tint = LyricSoft)
                }
                IconButton(onClick = vm::retryLyrics) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Search again", tint = LyricSoft)
                }
            }
        }
    }

    if (searching) {
        LyricsSearchSheet(vm = vm, track = track, onDismiss = { searching = false })
    }
}

@Composable
private fun LoadingMessage() {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp, modifier = Modifier.size(32.dp))
        Spacer(Modifier.height(16.dp))
        Text("Finding lyrics", style = MaterialTheme.typography.bodyLarge, color = LyricSoft)
    }
}

@Composable
private fun EmptyMessage(
    title: String,
    message: String,
    onSearch: () -> Unit,
    onRetry: () -> Unit,
    onImport: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.Lyrics, contentDescription = null, tint = LyricSoft, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, color = Color.White, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = LyricSoft, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onSearch,
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = LyricInk)
        ) {
            Icon(Icons.Rounded.Search, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.size(8.dp))
            Text("Search lyrics")
        }
        TextButton(
            onClick = onRetry,
            colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
        ) {
            Text("Search again")
        }
        TextButton(
            onClick = onImport,
            colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
        ) {
            Text("Import .lrc file")
        }
    }
}

@Composable
private fun PlainLyrics(text: String, scale: Float) {
    Column(
        Modifier
            .fillMaxSize()
            .fadingEdges()
            .verticalScroll(rememberScrollState())
            .padding(top = 24.dp, bottom = 48.dp, start = 12.dp, end = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium.let {
                it.copy(fontSize = it.fontSize * scale, fontWeight = FontWeight.Medium, lineHeight = 32.sp * scale)
            },
            color = Color.White.copy(alpha = 0.92f),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun SyncedLyrics(vm: PlayerViewModel, lines: List<LyricLine>, scale: Float) {
    val position by vm.position.collectAsStateWithLifecycle()
    val active = LrcParser.indexAt(lines, position + 150)
    val listState = rememberLazyListState()
    var holding by remember { mutableStateOf(false) }
    var placed by remember { mutableStateOf(false) }

    LaunchedEffect(listState) {
        listState.interactionSource.interactions.collectLatest { interaction ->
            when (interaction) {
                is DragInteraction.Start -> holding = true
                is DragInteraction.Stop, is DragInteraction.Cancel -> {
                    delay(2500)
                    holding = false
                }
            }
        }
    }

    LaunchedEffect(active, holding, scale) {
        if (holding || active < 0) return@LaunchedEffect
        if (listState.layoutInfo.visibleItemsInfo.none { it.index == active }) {
            listState.scrollToItem(active)
        }
        val info = listState.layoutInfo
        val item = info.visibleItemsInfo.firstOrNull { it.index == active } ?: return@LaunchedEffect
        val delta = item.offset + item.size / 2f + info.beforeContentPadding - info.viewportSize.height / 2f
        if (placed) {
            listState.animateScrollBy(delta, tween(450))
        } else {
            listState.scrollBy(delta)
            placed = true
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .fadingEdges(),
            contentPadding = PaddingValues(top = maxHeight / 2, bottom = maxHeight / 2)
        ) {
            itemsIndexed(lines, key = { index, _ -> index }) { index, line ->
                val isActive = index == active
                val distance = if (active < 0) index + 1 else abs(index - active)
                LyricRow(
                    text = line.text.ifBlank { "♪" },
                    isActive = isActive,
                    distance = distance,
                    scale = scale,
                    onClick = { vm.seekTo(line.timeMs) }
                )
            }
        }
    }
}

@Composable
private fun LyricRow(
    text: String,
    isActive: Boolean,
    distance: Int,
    scale: Float,
    onClick: () -> Unit
) {
    val alpha by animateFloatAsState(
        targetValue = when (distance) {
            0 -> 1f
            1 -> 0.55f
            2 -> 0.4f
            else -> 0.27f
        },
        animationSpec = tween(350),
        label = "lyricAlpha"
    )
    val emphasis by animateFloatAsState(
        targetValue = if (isActive) 1f else 0.78f,
        animationSpec = tween(350),
        label = "lyricScale"
    )
    val base = MaterialTheme.typography.headlineSmall.let { it.copy(fontSize = it.fontSize * scale) }.copy(
        fontWeight = FontWeight.Bold,
        lineHeight = 36.sp * scale,
        textAlign = TextAlign.Center
    )
    val style = base.copy(color = Color.White)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                this.alpha = alpha
                scaleX = emphasis
                scaleY = emphasis
                transformOrigin = TransformOrigin.Center
            }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(vertical = 10.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, style = style, textAlign = TextAlign.Center)
    }
}

private fun Modifier.fadingEdges(): Modifier =
    this
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            drawRect(
                brush = Brush.verticalGradient(
                    0f to Color.Transparent,
                    0.1f to Color.Black,
                    0.9f to Color.Black,
                    1f to Color.Transparent
                ),
                blendMode = BlendMode.DstIn
            )
        }
