package com.sonora.player.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.LinearGradientShader
import androidx.compose.ui.graphics.Shader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.LrcParser
import com.sonora.player.data.LyricLine
import com.sonora.player.data.LyricsState
import com.sonora.player.data.Track
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlin.math.abs

private val LyricInk = Color(0xFF0B0A10)
private val LyricSoft = Color.White.copy(alpha = 0.7f)
private val Palette = listOf(Color(0xFFFF9AD5), Color(0xFFC9B6FF), Color(0xFF8FE0D0))

@Composable
fun LyricsPanel(
    vm: PlayerViewModel,
    track: Track,
    state: LyricsState,
    onImport: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searching by remember { mutableStateOf(false) }

    Box(modifier) {
        when (state) {
            LyricsState.Idle, LyricsState.Loading -> LoadingMessage()
            is LyricsState.Synced -> SyncedLyrics(vm, state.lines)
            is LyricsState.Plain -> PlainLyrics(state.text)
            LyricsState.NotFound -> EmptyMessage(
                title = "No lyrics found",
                message = "Search by title and singer, or import an .lrc file for this song.",
                onSearch = { searching = true },
                onRetry = vm::retryLyrics,
                onImport = onImport
            )
            LyricsState.Failed -> EmptyMessage(
                title = "Can't reach the lyrics service",
                message = "Check your connection, try again, or search by title and singer.",
                onSearch = { searching = true },
                onRetry = vm::retryLyrics,
                onImport = onImport
            )
        }
        if (state is LyricsState.Synced || state is LyricsState.Plain) {
            Row(Modifier.align(Alignment.TopEnd)) {
                IconButton(onClick = { searching = true }) {
                    Icon(Icons.Rounded.Search, contentDescription = "Search lyrics", tint = LyricSoft)
                }
                IconButton(onClick = onImport) {
                    Icon(Icons.Rounded.UploadFile, contentDescription = "Import .lrc", tint = LyricSoft)
                }
                IconButton(onClick = vm::retryLyrics) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Search again", tint = LyricSoft)
                }
            }
        }
    }

    if (searching) {
        LyricsSearchSheet(vm = vm, track = track, onDismiss = { searching = false })
    }
}

@Composable
private fun LoadingMessage() {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp, modifier = Modifier.size(32.dp))
        Spacer(Modifier.height(16.dp))
        Text("Finding lyrics", style = MaterialTheme.typography.bodyLarge, color = LyricSoft)
    }
}

@Composable
private fun EmptyMessage(
    title: String,
    message: String,
    onSearch: () -> Unit,
    onRetry: () -> Unit,
    onImport: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.Lyrics, contentDescription = null, tint = LyricSoft, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, color = Color.White, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = LyricSoft, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onSearch,
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = LyricInk)
        ) {
            Icon(Icons.Rounded.Search, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.size(8.dp))
            Text("Search lyrics")
        }
        TextButton(
            onClick = onRetry,
            colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
        ) {
            Text("Search again")
        }
        TextButton(
            onClick = onImport,
            colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
        ) {
            Text("Import .lrc file")
        }
    }
}

@Composable
private fun PlainLyrics(text: String) {
    Column(
        Modifier
            .fillMaxSize()
            .fadingEdges()
            .verticalScroll(rememberScrollState())
            .padding(top = 24.dp, bottom = 48.dp, start = 12.dp, end = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Medium, lineHeight = 32.sp),
            color = Color.White.copy(alpha = 0.92f),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun SyncedLyrics(vm: PlayerViewModel, lines: List<LyricLine>) {
    val position by vm.position.collectAsStateWithLifecycle()
    val active = LrcParser.indexAt(lines, position + 150)
    val listState = rememberLazyListState()
    var holding by remember { mutableStateOf(false) }
    var placed by remember { mutableStateOf(false) }

    LaunchedEffect(listState) {
        listState.interactionSource.interactions.collectLatest { interaction ->
            when (interaction) {
                is DragInteraction.Start -> holding = true
                is DragInteraction.Stop, is DragInteraction.Cancel -> {
                    delay(2500)
                    holding = false
                }
            }
        }
    }

    LaunchedEffect(active, holding) {
        if (holding || active < 0) return@LaunchedEffect
        if (placed) {
            listState.animateScrollToItem(active)
        } else {
            listState.scrollToItem(active)
            placed = true
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .fadingEdges(),
            contentPadding = PaddingValues(top = maxHeight * 0.28f, bottom = maxHeight * 0.6f)
        ) {
            itemsIndexed(lines, key = { index, _ -> index }) { index, line ->
                val isActive = index == active
                val distance = if (active < 0) index + 1 else abs(index - active)
                val progress = if (isActive) {
                    val next = lines.getOrNull(index + 1)?.timeMs ?: (line.timeMs + 6000)
                    val gap = (next - line.timeMs).coerceAtLeast(1L)
                    val estimate = (line.text.length * 90L).coerceIn(1500L, 7000L)
                    ((position - line.timeMs).toFloat() / minOf(gap, estimate)).coerceIn(0f, 1f)
                } else {
                    0f
                }
                LyricRow(
                    text = line.text.ifBlank { "♪" },
                    isActive = isActive,
                    distance = distance,
                    progress = progress,
                    onClick = { vm.seekTo(line.timeMs) }
                )
            }
        }
    }
}

@Composable
private fun LyricRow(
    text: String,
    isActive: Boolean,
    distance: Int,
    progress: Float,
    onClick: () -> Unit
) {
    val alpha by animateFloatAsState(
        targetValue = when (distance) {
            0 -> 1f
            1 -> 0.55f
            2 -> 0.4f
            else -> 0.27f
        },
        animationSpec = tween(350),
        label = "lyricAlpha"
    )
    val scale by animateFloatAsState(
        targetValue = if (isActive) 1f else 0.9f,
        animationSpec = tween(350),
        label = "lyricScale"
    )
    val sweep by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(260, easing = LinearEasing),
        label = "lyricSweep"
    )
    val base = MaterialTheme.typography.headlineSmall.copy(
        fontWeight = FontWeight.Bold,
        lineHeight = 36.sp,
        textAlign = TextAlign.Center
    )
    val style = if (isActive) {
        base.copy(brush = SweepBrush(sweep), shadow = Shadow(Palette[1].copy(alpha = 0.45f), blurRadius = 24f))
    } else {
        base.copy(color = Color.White)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                this.alpha = alpha
                scaleX = scale
                scaleY = scale
                transformOrigin = TransformOrigin.Center
            }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(vertical = 10.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, style = style, textAlign = TextAlign.Center)
    }
}

private fun paletteAt(position: Float): Color {
    val scaled = position.coerceIn(0f, 1f) * (Palette.size - 1)
    val index = scaled.toInt().coerceAtMost(Palette.size - 2)
    return lerp(Palette[index], Palette[index + 1], scaled - index)
}

private class SweepBrush(private val progress: Float) : ShaderBrush() {
    override fun createShader(size: Size): Shader {
        val filled = progress.coerceIn(0f, 1f)
        val edge = (filled + 0.08f).coerceAtMost(1f)
        val dim = 0.55f
        return LinearGradientShader(
            from = Offset.Zero,
            to = Offset(size.width, 0f),
            colors = listOf(
                paletteAt(0f),
                paletteAt(filled / 2f),
                paletteAt(filled),
                paletteAt(edge).copy(alpha = dim),
                paletteAt(1f).copy(alpha = dim)
            ),
            colorStops = listOf(0f, filled / 2f, filled, edge, 1f),
            tileMode = TileMode.Clamp
        )
    }
}

private fun Modifier.fadingEdges(): Modifier =
    this
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            drawRect(
                brush = Brush.verticalGradient(
                    0f to Color.Transparent,
                    0.1f to Color.Black,
                    0.8f to Color.Black,
                    1f to Color.Transparent
                ),
                blendMode = BlendMode.DstIn
            )
        }
