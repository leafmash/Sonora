package com.sonora.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.LyricsCandidate
import com.sonora.player.data.LyricsSearchState
import com.sonora.player.data.Track

@Composable
fun LyricsSearchSheet(
    vm: PlayerViewModel,
    track: Track,
    onDismiss: () -> Unit
) {
    val results by vm.lyricsSearch.collectAsStateWithLifecycle()
    var title by remember { mutableStateOf(track.title) }
    var artist by remember { mutableStateOf(track.artist.takeIf { it != "Unknown artist" }.orEmpty()) }
    val focus = LocalFocusManager.current
    val canSearch = title.isNotBlank() || artist.isNotBlank()

    val submit = {
        focus.clearFocus()
        vm.searchLyrics(title, artist)
    }

    LaunchedEffect(Unit) { vm.searchLyrics(title, artist) }

    ModalBottomSheet(
        onDismissRequest = {
            vm.resetLyricsSearch()
            onDismiss()
        },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .imePadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Search lyrics", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                singleLine = true,
                label = { Text("Song title") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = artist,
                onValueChange = { artist = it },
                singleLine = true,
                label = { Text("Singer") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { if (canSearch) submit() }),
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = { submit() },
                enabled = canSearch,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Search")
            }
            SearchResults(
                state = results,
                onPick = {
                    vm.applyLyrics(it)
                    onDismiss()
                }
            )
        }
    }
}

@Composable
private fun SearchResults(state: LyricsSearchState, onPick: (LyricsCandidate) -> Unit) {
    when (state) {
        LyricsSearchState.Idle -> Unit
        LyricsSearchState.Searching -> Box(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 120.dp),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        LyricsSearchState.Empty -> StatusText("No lyrics found. Check the spelling or try fewer words.")
        LyricsSearchState.Failed -> StatusText("Can't reach the lyrics service. Check your connection and try again.")
        is LyricsSearchState.Results -> LazyColumn(Modifier.heightIn(max = 340.dp)) {
            items(state.items, key = { it.id }) { item ->
                ListItem(
                    headlineContent = { Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = {
                        Text(
                            text = listOf(item.artist, item.album, formatTime(item.durationSec * 1000L))
                                .filter { it.isNotBlank() }
                                .joinToString(" · "),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    trailingContent = {
                        Text(
                            text = if (item.isSynced) "Synced" else "Text",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (item.isSynced) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPick(item) }
                )
            }
        }
    }
}

@Composable
private fun StatusText(message: String) {
    Text(
        text = message,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp)
    )
}
