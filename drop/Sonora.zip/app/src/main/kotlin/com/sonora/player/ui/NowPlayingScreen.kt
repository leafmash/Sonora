package com.sonora.player.ui

import android.graphics.drawable.BitmapDrawable
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.palette.graphics.Palette
import coil.imageLoader
import coil.request.ImageRequest
import com.sonora.player.NowPlaying
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.ArtModel
import com.sonora.player.data.Track
import com.sonora.player.ui.components.Artwork
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.media3.common.Player
import kotlin.math.abs

private val Ink = Color(0xFF0B0A10)
private val Pink = Color(0xFFFF9AD5)

@Composable
private fun rememberAccent(track: Track?): State<Color?> {
    val context = LocalContext.current
    return produceState<Color?>(initialValue = null, track?.id) {
        value = if (track == null) {
            null
        } else {
            withContext(Dispatchers.Default) {
                val request = ImageRequest.Builder(context)
                    .data(ArtModel(track.uri, track.albumId))
                    .size(200)
                    .allowHardware(false)
                    .build()
                val bitmap = (context.imageLoader.execute(request).drawable as? BitmapDrawable)?.bitmap
                bitmap?.let { source ->
                    val palette = Palette.from(source).maximumColorCount(16).generate()
                    val picked = palette.getDarkVibrantColor(0).takeIf { it != 0 }
                        ?: palette.getVibrantColor(0).takeIf { it != 0 }
                        ?: palette.getDarkMutedColor(0).takeIf { it != 0 }
                        ?: palette.getDominantColor(0).takeIf { it != 0 }
                    picked?.let { Color(it) }
                }
            }
        }
    }
}

@Composable
fun NowPlayingScreen(
    vm: PlayerViewModel,
    onCollapse: () -> Unit,
    onAddToPlaylist: (Track) -> Unit,
    onOpenEqualizer: () -> Unit
) {
    val now by vm.now.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val sleep by vm.sleepRemaining.collectAsStateWithLifecycle()
    val track = now.track
    val accent by rememberAccent(track)
    val top by animateColorAsState(
        targetValue = lerp(Ink, accent ?: Color(0xFF4A3B8C), 0.75f),
        animationSpec = tween(700),
        label = "top"
    )
    var showQueue by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    val settings by vm.settings.collectAsStateWithLifecycle()
    val lyrics by vm.lyrics.collectAsStateWithLifecycle()
    val showLyrics = settings.lyricsMode
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importLyrics(uri)
    }

    LaunchedEffect(track == null) {
        if (track == null) onCollapse()
    }
    if (track == null) return

    val favorite = track.id in favorites
    val white = Color.White
    val soft = Color.White.copy(alpha = 0.7f)

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(top, Ink)))
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total > 220f) onCollapse() },
                    onDragCancel = { total = 0f },
                    onVerticalDrag = { _, delta -> total += delta }
                )
            }
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onCollapse) {
                    Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Close", tint = white, modifier = Modifier.size(32.dp))
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "NOW PLAYING",
                        style = MaterialTheme.typography.labelSmall,
                        color = soft,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = track.album,
                        style = MaterialTheme.typography.labelLarge,
                        color = white,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = { onAddToPlaylist(track) }) {
                    Icon(Icons.Rounded.PlaylistAdd, contentDescription = "Add to playlist", tint = white)
                }
            }

            Crossfade(
                targetState = showLyrics,
                animationSpec = tween(300),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                label = "lyricsToggle"
            ) { lyricsOn ->
                if (lyricsOn) {
                    LyricsPanel(
                        vm = vm,
                        state = lyrics,
                        onImport = { importLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    BoxWithConstraints(
                        Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        val side = minOf(maxWidth, maxHeight)
                        val scale by animateFloatAsState(
                            targetValue = if (now.isPlaying) 1f else 0.88f,
                            animationSpec = spring(dampingRatio = 0.65f, stiffness = Spring.StiffnessLow),
                            label = "scale"
                        )
                        Crossfade(targetState = track, animationSpec = tween(350), label = "art") { shown ->
                            Artwork(
                                track = shown,
                                modifier = Modifier
                                    .size(side)
                                    .graphicsLayer {
                                        scaleX = scale
                                        scaleY = scale
                                    }
                                    .shadow(24.dp, RoundedCornerShape(32.dp), ambientColor = Color.Black, spotColor = Color.Black)
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = null
                                    ) { vm.updateSettings { it.copy(lyricsMode = true) } },
                                shape = RoundedCornerShape(32.dp)
                            )
                        }
                    }
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        style = MaterialTheme.typography.headlineSmall,
                        color = white,
                        maxLines = 1,
                        modifier = Modifier.basicMarquee()
                    )
                    Text(
                        text = track.artist,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Normal,
                        color = soft,
                        maxLines = 1,
                        modifier = Modifier.basicMarquee()
                    )
                }
                IconButton(onClick = { vm.toggleFavorite(track) }) {
                    Icon(
                        imageVector = if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (favorite) Pink else white,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            SeekBar(vm, now.durationMs)
            Spacer(Modifier.height(4.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = vm::toggleShuffle) {
                    Icon(
                        Icons.Rounded.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (now.shuffle) Pink else soft,
                        modifier = Modifier.size(26.dp)
                    )
                }
                IconButton(onClick = vm::previous, modifier = Modifier.size(64.dp)) {
                    Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous", tint = white, modifier = Modifier.size(42.dp))
                }
                Surface(
                    onClick = vm::togglePlay,
                    shape = CircleShape,
                    color = white,
                    modifier = Modifier.size(76.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (now.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (now.isPlaying) "Pause" else "Play",
                            tint = Ink,
                            modifier = Modifier.size(44.dp)
                        )
                    }
                }
                IconButton(onClick = vm::next, modifier = Modifier.size(64.dp)) {
                    Icon(Icons.Rounded.SkipNext, contentDescription = "Next", tint = white, modifier = Modifier.size(42.dp))
                }
                IconButton(onClick = vm::cycleRepeat) {
                    Icon(
                        imageVector = if (now.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        contentDescription = "Repeat",
                        tint = if (now.repeat == Player.REPEAT_MODE_OFF) soft else Pink,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            sleep?.let {
                Text(
                    text = "Sleep timer · ${formatTime(it)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = Pink,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    textAlign = TextAlign.Center
                )
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(onClick = { vm.updateSettings { it.copy(lyricsMode = !it.lyricsMode) } }) {
                    Icon(Icons.Rounded.Lyrics, contentDescription = "Lyrics", tint = if (showLyrics) Pink else soft)
                }
                IconButton(onClick = { showSpeed = true }) {
                    Icon(Icons.Rounded.Speed, contentDescription = "Speed", tint = if (abs(now.speed - 1f) > 0.01f) Pink else soft)
                }
                IconButton(onClick = { showSleep = true }) {
                    Icon(Icons.Rounded.Bedtime, contentDescription = "Sleep timer", tint = if (sleep != null) Pink else soft)
                }
                IconButton(onClick = onOpenEqualizer) {
                    Icon(Icons.Rounded.Equalizer, contentDescription = "Equalizer", tint = soft)
                }
                IconButton(onClick = { showQueue = true }) {
                    Icon(Icons.Rounded.QueueMusic, contentDescription = "Queue", tint = soft)
                }
            }
        }
    }

    if (showQueue) QueueSheet(vm, now) { showQueue = false }
    if (showSpeed) SpeedDialog(vm, now.speed) { showSpeed = false }
    if (showSleep) SleepDialog(vm, sleep != null) { showSleep = false }
}

@Composable
private fun SeekBar(vm: PlayerViewModel, duration: Long) {
    val position by vm.position.collectAsStateWithLifecycle()
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val fraction = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f
    val shown = if (dragging) dragValue else fraction
    val label = if (dragging) (dragValue * duration).toLong() else position

    Column {
        Slider(
            value = shown,
            onValueChange = {
                dragging = true
                dragValue = it
            },
            onValueChangeFinished = {
                vm.seekTo((dragValue * duration).toLong())
                dragging = false
            },
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Color.White,
                inactiveTrackColor = Color.White.copy(alpha = 0.25f)
            )
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(formatTime(label), style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.7f))
            Text(formatTime(duration), style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.7f))
        }
    }
}

@Composable
private fun QueueSheet(vm: PlayerViewModel, now: NowPlaying, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Text(
            text = "Up next · ${now.queue.size} songs",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
        val listState = rememberLazyListState(initialFirstVisibleItemIndex = (now.queueIndex - 1).coerceAtLeast(0))
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.8f)
        ) {
            itemsIndexed(now.queue, key = { index, item -> "$index-${item.id}" }) { index, item ->
                val current = index == now.queueIndex
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { vm.playQueueIndex(index) }
                        .padding(start = 24.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Artwork(item, Modifier.size(46.dp), RoundedCornerShape(10.dp))
                    Column(
                        Modifier
                            .weight(1f)
                            .padding(horizontal = 14.dp)
                    ) {
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = item.artist,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (!current) {
                        IconButton(onClick = { vm.removeFromQueue(index) }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Remove", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SpeedDialog(vm: PlayerViewModel, current: Float, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Playback speed") },
        text = {
            Column {
                listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { speed ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                vm.setSpeed(speed)
                                onDismiss()
                            }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = abs(current - speed) < 0.01f, onClick = null)
                        Spacer(Modifier.width(14.dp))
                        Text("${speed}x", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun SleepDialog(vm: PlayerViewModel, active: Boolean, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sleep timer") },
        text = {
            Column {
                listOf(5, 10, 15, 30, 45, 60).forEach { minutes ->
                    Text(
                        text = "$minutes minutes",
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                vm.startSleepTimer(minutes)
                                onDismiss()
                            }
                            .padding(vertical = 12.dp)
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        dismissButton = {
            if (active) {
                TextButton(onClick = {
                    vm.cancelSleepTimer()
                    onDismiss()
                }) { Text("Turn off timer") }
            }
        }
    )
}
