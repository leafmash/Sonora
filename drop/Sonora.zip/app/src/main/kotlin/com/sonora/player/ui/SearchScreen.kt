package com.sonora.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.Artist
import com.sonora.player.data.Route
import com.sonora.player.data.Track
import com.sonora.player.ui.components.AlbumCard
import com.sonora.player.ui.components.Artwork
import com.sonora.player.ui.components.EmptyState
import com.sonora.player.ui.components.SectionTitle
import com.sonora.player.ui.components.TrackList

@Composable
fun SearchScreen(vm: PlayerViewModel, onAddToPlaylist: (Track) -> Unit) {
    val library by vm.library.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    val needle = query.trim().lowercase()

    val songs = remember(library, needle) {
        if (needle.isEmpty()) {
            emptyList()
        } else {
            library.tracks.filter {
                it.title.lowercase().contains(needle) ||
                    it.artist.lowercase().contains(needle) ||
                    it.album.lowercase().contains(needle)
            }
        }
    }
    val albums = remember(library, needle) {
        if (needle.isEmpty()) {
            emptyList()
        } else {
            library.albums.filter { it.name.lowercase().contains(needle) || it.artist.lowercase().contains(needle) }
        }
    }
    val artists = remember(library, needle) {
        if (needle.isEmpty()) emptyList() else library.artists.filter { it.name.lowercase().contains(needle) }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        Text(
            text = "Search",
            style = MaterialTheme.typography.headlineLarge,
            modifier = Modifier.padding(start = 20.dp, top = 12.dp, end = 20.dp)
        )
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            placeholder = { Text("Songs, albums, artists") },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Clear")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
        )

        when {
            needle.isEmpty() -> EmptyState(
                icon = Icons.Rounded.Search,
                title = "Find your music",
                message = "Search by song, album or artist."
            )
            songs.isEmpty() && albums.isEmpty() && artists.isEmpty() -> EmptyState(
                icon = Icons.Rounded.Search,
                title = "No results",
                message = "Nothing matched \"$query\"."
            )
            else -> TrackList(
                tracks = songs,
                vm = vm,
                onAddToPlaylist = onAddToPlaylist,
                header = {
                    if (artists.isNotEmpty()) {
                        item { SectionTitle("Artists") }
                        item {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 20.dp),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                items(artists, key = { it.name }) { artist ->
                                    ArtistBubble(artist) { vm.open(Route.ArtistRoute(artist.name)) }
                                }
                            }
                        }
                    }
                    if (albums.isNotEmpty()) {
                        item { SectionTitle("Albums") }
                        item {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 20.dp),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                items(albums, key = { it.id }) { album ->
                                    AlbumCard(
                                        album = album,
                                        onClick = { vm.open(Route.AlbumRoute(album.id)) },
                                        modifier = Modifier.width(140.dp)
                                    )
                                }
                            }
                        }
                    }
                    if (songs.isNotEmpty()) {
                        item { SectionTitle("Songs") }
                    }
                }
            )
        }
    }
}

@Composable
private fun ArtistBubble(artist: Artist, onClick: () -> Unit) {
    Column(
        Modifier
            .width(92.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Artwork(artist.tracks.first(), Modifier.size(92.dp), CircleShape)
        Text(
            text = artist.name,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}
