package com.sonora.player.ui

import android.os.Build
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sonora.player.BuildConfig
import com.sonora.player.PlayerViewModel
import com.sonora.player.data.Route
import com.sonora.player.data.ThemeMode

@Composable
fun SettingsScreen(vm: PlayerViewModel) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val library by vm.library.collectAsStateWithLifecycle()

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
    ) {
        Text(
            text = "Settings",
            style = MaterialTheme.typography.headlineLarge,
            modifier = Modifier.padding(start = 20.dp, top = 12.dp, end = 20.dp, bottom = 8.dp)
        )

        SectionLabel("Appearance")
        Row(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ThemeMode.entries.forEach { mode ->
                FilterChip(
                    selected = settings.themeMode == mode,
                    onClick = { vm.updateSettings { it.copy(themeMode = mode) } },
                    label = { Text(if (mode == ThemeMode.Amoled) "AMOLED" else mode.name) }
                )
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            SettingRow(
                title = "Dynamic colors",
                subtitle = "Match the app to your wallpaper",
                onClick = { vm.updateSettings { it.copy(dynamicColor = !it.dynamicColor) } }
            ) {
                Switch(
                    checked = settings.dynamicColor,
                    onCheckedChange = { value -> vm.updateSettings { it.copy(dynamicColor = value) } }
                )
            }
        }

        SectionLabel("Library")
        SettingRow(
            title = "Hide short clips",
            subtitle = "Skip audio shorter than 30 seconds",
            onClick = { vm.updateSettings { it.copy(hideShort = !it.hideShort) } }
        ) {
            Switch(
                checked = settings.hideShort,
                onCheckedChange = { value -> vm.updateSettings { it.copy(hideShort = value) } }
            )
        }
        SettingRow(
            title = "Equalizer",
            subtitle = "Presets, bands, bass boost",
            onClick = { vm.open(Route.EqualizerRoute) }
        )
        SettingRow(
            title = "Rescan library",
            subtitle = "${library.tracks.size} songs  ·  ${library.albums.size} albums  ·  ${library.artists.size} artists",
            onClick = vm::refresh
        )

        SectionLabel("About")
        SettingRow(
            title = "Sonora",
            subtitle = "Version ${BuildConfig.VERSION_NAME}"
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 4.dp)
    )
}

@Composable
private fun SettingRow(
    title: String,
    subtitle: String? = null,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit = {}
) {
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        trailing()
    }
}
