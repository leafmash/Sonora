package com.sonora.player.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.isSpecified

private val MarkLavender = Color(0xFFC9B6FF)
private val MarkPink = Color(0xFFFF9AD5)
private val MarkHeight = floatArrayOf(0.40f, 0.76f, 1f, 0.70f, 0.40f)

@Composable
fun SonoraMark(
    modifier: Modifier = Modifier,
    size: Dp = Dp.Unspecified,
    tint: Color? = null
) {
    Canvas(if (size.isSpecified) modifier.size(size) else modifier) {
        val stroke = this.size.minDimension * 0.15f
        val gap = (this.size.width - stroke) / 4f
        val full = this.size.height - stroke
        for (index in 0 until 5) {
            val x = stroke / 2f + gap * index
            val height = full * MarkHeight[index]
            val startY = stroke / 2f + full * (1f - MarkHeight[index]) / 2f
            val color = tint ?: if (index == 2) MarkPink else MarkLavender
            drawLine(
                color = color,
                start = Offset(x, startY),
                end = Offset(x, startY + height),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
        }
    }
}
