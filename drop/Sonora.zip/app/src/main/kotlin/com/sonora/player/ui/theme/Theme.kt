package com.sonora.player.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.core.view.WindowCompat
import com.sonora.player.data.ThemeMode

private val DarkColors = darkColorScheme(
    primary = Color(0xFFC9B6FF),
    onPrimary = Color(0xFF2D1B69),
    primaryContainer = Color(0xFF3E2F7A),
    onPrimaryContainer = Color(0xFFE7DEFF),
    secondary = Color(0xFFFFA6DA),
    onSecondary = Color(0xFF4A1238),
    secondaryContainer = Color(0xFF6A2552),
    onSecondaryContainer = Color(0xFFFFD9EE),
    tertiary = Color(0xFF8FE0D0),
    onTertiary = Color(0xFF00382F),
    background = Color(0xFF0E0C14),
    onBackground = Color(0xFFECE6F5),
    surface = Color(0xFF0E0C14),
    onSurface = Color(0xFFECE6F5),
    surfaceVariant = Color(0xFF2B2837),
    onSurfaceVariant = Color(0xFFC9C4D6),
    surfaceContainerLowest = Color(0xFF0A0910),
    surfaceContainerLow = Color(0xFF14121C),
    surfaceContainer = Color(0xFF191722),
    surfaceContainerHigh = Color(0xFF211E2C),
    surfaceContainerHighest = Color(0xFF2A2737),
    outline = Color(0xFF938EA3),
    outlineVariant = Color(0xFF3A3649),
    error = Color(0xFFFFB4AB)
)

private val AmoledColors = DarkColors.copy(
    background = Color.Black,
    surface = Color.Black,
    surfaceContainerLowest = Color.Black,
    surfaceContainerLow = Color(0xFF0A0A0D),
    surfaceContainer = Color(0xFF111116),
    surfaceContainerHigh = Color(0xFF17171D),
    surfaceContainerHighest = Color(0xFF1E1E26)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF5B43B8),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE7DEFF),
    onPrimaryContainer = Color(0xFF1E0F55),
    secondary = Color(0xFFB0307F),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFFD9EE),
    onSecondaryContainer = Color(0xFF3E0A2D),
    tertiary = Color(0xFF006B5D),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFFBF8FF),
    onBackground = Color(0xFF1C1A22),
    surface = Color(0xFFFBF8FF),
    onSurface = Color(0xFF1C1A22),
    surfaceVariant = Color(0xFFE7E0EC),
    onSurfaceVariant = Color(0xFF49454F),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF6F2FB),
    surfaceContainer = Color(0xFFF0ECF6),
    surfaceContainerHigh = Color(0xFFEAE6F0),
    surfaceContainerHighest = Color(0xFFE4E0EA),
    outline = Color(0xFF7A7584),
    outlineVariant = Color(0xFFCAC4D0)
)

private val BaseTypography = Typography()

private val SonoraTypography = BaseTypography.copy(
    headlineLarge = BaseTypography.headlineLarge.copy(fontWeight = FontWeight.Bold),
    headlineMedium = BaseTypography.headlineMedium.copy(fontWeight = FontWeight.Bold),
    headlineSmall = BaseTypography.headlineSmall.copy(fontWeight = FontWeight.Bold),
    titleLarge = BaseTypography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
    titleMedium = BaseTypography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
)

@Composable
fun SonoraTheme(
    mode: ThemeMode,
    dynamic: Boolean,
    content: @Composable () -> Unit
) {
    val dark = when (mode) {
        ThemeMode.System -> isSystemInDarkTheme()
        ThemeMode.Light -> false
        else -> true
    }
    val context = LocalContext.current
    val useDynamic = dynamic && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val scheme: ColorScheme = when {
        useDynamic && dark -> {
            val base = dynamicDarkColorScheme(context)
            if (mode == ThemeMode.Amoled) {
                base.copy(
                    background = Color.Black,
                    surface = Color.Black,
                    surfaceContainerLowest = Color.Black
                )
            } else {
                base
            }
        }
        useDynamic -> dynamicLightColorScheme(context)
        mode == ThemeMode.Amoled -> AmoledColors
        dark -> DarkColors
        else -> LightColors
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
    }

    MaterialTheme(colorScheme = scheme, typography = SonoraTypography, content = content)
}
